#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Analisis de mercado del corpus de ofertas de ChileTrabajos.

Genera:
  data/eval/market_report.md
  data/eval/skill_matrix.csv
  data/eval/role_demand.csv
  data/eval/cluster_summary.csv
  data/eval/salary_bands.csv
  data/eval/adjacent_market.csv (si --scan-adjacent)
  data/eval/proxy_labels.json
  data/eval/expansion_recommendation.md

Solo stdlib. No envia postulaciones ni modifica ofertas.
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import json
import math
import re
import statistics
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

TOOLS_DIR = Path(__file__).resolve().parent
ROOT = TOOLS_DIR.parent
sys.path.insert(0, str(TOOLS_DIR))

import corpus_common as cc  # noqa: E402
import synonym_engine as se  # noqa: E402

DATA = ROOT / "data"
CORPUS_DIR = DATA / "corpus" / "offers"
EVAL_DIR = DATA / "eval"
PROFILE_PATH = ROOT / "config" / "profile.json"
KNOWN_EXPIRED_PATH = EVAL_DIR / "known_expired.json"

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
)

CORE_IDS = {
    "ito", "qa_qc", "project_manager", "contract_admin", "project_engineer",
    "planning", "maintenance", "reliability", "operations", "maestranza",
    "commissioning", "mechanical_engineer", "piping", "mining", "construction",
    "industrial", "sap", "nfpa", "sec", "asme", "iso9001", "pdca", "glp",
    "pumping", "project_control", "cost_control", "procurement",
    "asset_management", "site_supervisor", "energy", "welding", "ndt", "pem",
}

KNOWN_CLIENTS = ["bhp", "codelco", "anglo", "glencore", "flsmidth", "multotec"]
DOMAIN_GAPS = {
    "civil", "water_sanitary", "hvac", "welding", "ndt", "pem", "commissioning",
    "reliability", "cost_control", "procurement", "asset_management",
    "project_control", "electrical", "instrumentation", "transmission_lines",
    "fiber_optic", "medium_voltage", "low_voltage", "product_manager",
}
HARD_TITLE_GAPS = {"civil", "water_sanitary", "hvac", "welding", "ndt", "pem", "product_manager"}

ADJACENT_TERMS = [
    {"id": "reliability", "label": "Confiabilidad / RCA", "query": "confiabilidad mantenimiento", "profile_ids": ["reliability"]},
    {"id": "maintenance_planning", "label": "Planificacion de mantenimiento", "query": "planificador de mantenimiento", "profile_ids": ["planning", "maintenance"]},
    {"id": "commissioning", "label": "Commissioning / puesta en marcha", "query": "commissioning", "profile_ids": ["commissioning"]},
    {"id": "project_controls", "label": "Project controls / PMO", "query": "project controls", "profile_ids": ["project_control"]},
    {"id": "cost_control", "label": "Control de costos", "query": "control de costos", "profile_ids": ["cost_control"]},
    {"id": "procurement", "label": "Abastecimiento tecnico", "query": "abastecimiento tecnico", "profile_ids": ["procurement"]},
    {"id": "hvac", "label": "HVAC / climatizacion", "query": "HVAC", "profile_ids": ["hvac"]},
    {"id": "energy", "label": "Eficiencia energetica", "query": "eficiencia energetica", "profile_ids": ["energy"]},
    {"id": "mechanical_design", "label": "Diseno mecanico", "query": "diseno mecanico", "profile_ids": ["mechanical_engineer"]},
    {"id": "asset_management", "label": "Asset management", "query": "asset management", "profile_ids": ["asset_management"]},
    {"id": "contract_admin", "label": "Administrador de contratos", "query": "administrador de contratos", "profile_ids": ["contract_admin"]},
    {"id": "ito_mechanical", "label": "ITO mecanico", "query": "ITO mecanico", "profile_ids": ["ito", "mechanical_engineer"]},
]

SPANISH_MONTHS = {
    "enero": 1, "febrero": 2, "marzo": 3, "abril": 4, "mayo": 5, "junio": 6,
    "julio": 7, "agosto": 8, "septiembre": 9, "setiembre": 9, "octubre": 10,
    "noviembre": 11, "diciembre": 12,
}


def now_iso() -> str:
    return dt.datetime.now().replace(microsecond=0).isoformat()


def http_get(url: str, timeout: int = 25) -> str:
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": USER_AGENT,
            "Accept": "text/html,application/xhtml+xml",
            "Accept-Language": "es-CL,es;q=0.9",
            "Accept-Encoding": "identity",
            "Connection": "close",
        },
    )
    with urllib.request.urlopen(req, timeout=timeout) as response:
        raw = response.read()
        charset = response.headers.get_content_charset() or "utf-8"
    try:
        return raw.decode(charset, "replace")
    except LookupError:
        return raw.decode("utf-8", "replace")


load_corpus = cc.load_corpus  # loader único (antes duplicado aquí)
CORPUS_DIR = cc.CORPUS_DIR


def parse_date(value: Any) -> Optional[dt.date]:
    if not value:
        return None
    text = str(value).strip().lower()
    if not text or text in ("n/d", "nd"):
        return None
    if text.startswith("hace"):
        m = re.search(r"(\d+)", text)
        if m:
            return dt.date.today() - dt.timedelta(days=int(m.group(1)))
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})", text)
    if m:
        try:
            return dt.date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except ValueError:
            return None
    m = re.search(r"(\d{1,2})\s+de\s+([a-z]+)\s+de\s+(\d{4})", text)
    if m and m.group(2) in SPANISH_MONTHS:
        try:
            return dt.date(int(m.group(3)), SPANISH_MONTHS[m.group(2)], int(m.group(1)))
        except ValueError:
            return None
    return None


def freshness_score(value: Any) -> float:
    date = parse_date(value)
    if not date:
        return 0.5
    days = max(0, (dt.date.today() - date).days)
    if days <= 7:
        return 1.0
    if days <= 30:
        return 0.85
    if days <= 60:
        return 0.6
    if days <= 90:
        return 0.35
    return 0.15


def normalize_location(text: str) -> str:
    return se.normalize(text)


def location_score(location: str, title: str, description: str) -> float:
    loc = normalize_location(f"{location} {title}")
    if not loc or loc in ("chile", "n d", "nd"):
        return 0.8
    if any(k in loc for k in ("remoto", "teletrabajo", "home office", "hibrido")):
        return 1.0
    if any(k in loc for k in ("santiago", "region metropolitana", "providencia", "las condes", "maipu", "puente alto")):
        return 1.0
    if any(k in loc for k in ("antofagasta", "calama", "el loa", "ii region")):
        return 0.65
    if any(k in loc for k in ("fifo", "faena", "campamento")):
        return 0.75
    return 0.6


def company_score(company: str, text: str) -> float:
    blob = normalize_location(f"{company} {text}")
    if any(client in blob for client in KNOWN_CLIENTS):
        return 1.0
    if company and normalize_location(company) not in ("n d", "nd", "chile"):
        return 0.7
    return 0.5


def money_values(text: str) -> List[int]:
    if not text:
        return []
    values: List[int] = []
    for match in re.finditer(r"(?<!\d)(\d{1,3}(?:\.\d{3})+|\d{6,9})(?!\d)", text):
        raw = match.group(1)
        try:
            values.append(int(raw.replace(".", "")))
        except ValueError:
            pass
    for match in re.finditer(r"(?i)(\d+(?:[.,]\d+)?)\s*(millones?|mm|m)\b", text):
        try:
            values.append(int(float(match.group(1).replace(",", ".")) * 1_000_000))
        except ValueError:
            pass
    for match in re.finditer(r"(?i)(\d{2,3})\s*mil\b", text):
        try:
            values.append(int(match.group(1)) * 1_000)
        except ValueError:
            pass
    clean = sorted({v for v in values if 300_000 <= v <= 15_000_000})
    return clean


def is_salary_line(line: str) -> bool:
    low = line.lower()
    salary_word = any(k in low for k in ("renta", "sueldo", "remuneraci", "salario"))
    money_symbol = "$" in low or "clp" in low
    project_context = any(
        k in low for k in ("proyecto", "presupuesto", "inversion", "us$", "millones de dolares", "monto")
    )
    if project_context and not salary_word:
        return False
    return salary_word or money_symbol


def salary_from_offer(offer: Dict[str, Any]) -> Tuple[Optional[int], Optional[int], List[str]]:
    lines: List[str] = []
    salary_text = str(offer.get("salary_text", "") or "")
    if salary_text:
        lines.extend([
            x.strip() for x in salary_text.split("|")
            if x.strip() and is_salary_line(x)
        ])
    for line in str(offer.get("_body", "")).splitlines():
        if is_salary_line(line):
            lines.append(line.strip())
    lines = list(dict.fromkeys([x for x in lines if x]))[:8]
    values: List[int] = []
    for line in lines:
        values.extend(money_values(line))
    values = sorted(set(values))
    if not values:
        return None, None, lines
    return values[0], values[-1], lines


def median_or_none(values: Iterable[int]) -> Optional[int]:
    vals = list(values)
    return int(statistics.median(vals)) if vals else None


def fmt_money(value: Optional[int]) -> str:
    if value is None:
        return "N/D"
    return f"${value:,.0f}".replace(",", ".")


def fmt_pct(value: float) -> str:
    return f"{value * 100:.1f}%"


def build_profile() -> Tuple[Dict[str, Any], List[Dict[str, Any]], set]:
    profile = json.loads(PROFILE_PATH.read_text(encoding="utf-8"))
    matcher = se.ConceptMatcher()
    concepts = matcher.positives(se.profile_text(profile))
    return profile, concepts, {c["id"] for c in concepts}


def duplicate_flags(offers: List[Dict[str, Any]]) -> Dict[str, bool]:
    groups: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for offer in offers:
        title = se.normalize(offer.get("title", ""))
        company = se.normalize(offer.get("company", ""))
        key = f"{title}|{company if company not in ('n d', 'nd', '') else ''}"
        groups[key].append(offer)
    flags: Dict[str, bool] = {str(o.get("offer_id")): False for o in offers}
    for group in groups.values():
        if len(group) < 2:
            continue
        ordered = sorted(group, key=lambda o: -int(o.get("score_legacy", 0) or 0))
        for offer in ordered[1:]:
            flags[str(offer.get("offer_id"))] = True
    return flags


def analyse(offers: List[Dict[str, Any]], profile_ids: set, known_expired: set, scan: bool) -> Dict[str, Any]:
    matcher = se.ConceptMatcher()
    usable = [
        o for o in offers
        if str(o.get("fetch_status", "")) == "ok" and len(str(o.get("_body", ""))) > 150
    ]
    dup = duplicate_flags(usable)
    demand: Dict[str, Dict[str, Any]] = {}
    title_counts: Counter = Counter()
    cluster_rows: Dict[str, Dict[str, Any]] = {}

    for offer in usable:
        cluster = str(offer.get("cluster_name", "") or "Sin cluster")
        if cluster not in cluster_rows:
            cluster_rows[cluster] = {
                "cluster_name": cluster,
                "offers": 0,
                "legacy_scores": [],
                "fits": [],
                "concepts": Counter(),
            }
        cluster_rows[cluster]["offers"] += 1
        cluster_rows[cluster]["legacy_scores"].append(int(offer.get("score_legacy", 0) or 0))

        text = str(offer.get("_full", ""))
        title = str(offer.get("title", ""))
        matched = matcher.positives(text)
        title_matched = matcher.positives(title)
        for concept in matched:
            cid = concept["id"]
            if cid not in demand:
                demand[cid] = {
                    "id": cid,
                    "label": concept["label"],
                    "kind": concept["kind"],
                    "weight": concept["weight"],
                    "count": 0,
                    "title_count": 0,
                    "profile_has": cid in profile_ids,
                    "clusters": Counter(),
                }
            demand[cid]["count"] += 1
            demand[cid]["clusters"][cluster] += 1
            cluster_rows[cluster]["concepts"][cid] += 1
        for concept in title_matched:
            title_counts[concept["id"]] += 1
            if concept["id"] in demand:
                demand[concept["id"]]["title_count"] += 1

        negatives = matcher.negatives(text)
        expired = str(offer.get("offer_key", "")) in known_expired
        seniority = any(c["id"] in ("junior", "trainee", "intern") for c in negatives)
        core_hits = [
            c for c in matched
            if c["id"] in profile_ids and c["id"] in CORE_IDS
        ]
        title_hits = [c for c in title_matched if c["id"] in profile_ids]
        missing_title = [
            c for c in title_matched
            if c["id"] not in profile_ids and not c["negative"]
        ]
        core_cov = min(1.0, len(core_hits) / 4.0)
        title_cov = min(1.0, len(title_hits) / 3.0)
        loc = location_score(str(offer.get("location", "")), title, text)
        fresh = freshness_score(offer.get("published"))
        comp = company_score(str(offer.get("company", "")), text)
        fit = 0.45 * core_cov + 0.25 * title_cov + 0.15 * loc + 0.10 * fresh + 0.05 * comp
        penalties = 0.0
        penalties += 0.10 * min(3, len(negatives))
        title_gap_penalty = sum(
            0.06 if c["id"] in HARD_TITLE_GAPS else 0.03 for c in missing_title
        )
        penalties += min(0.18, title_gap_penalty)
        if seniority:
            penalties += 0.25
        if expired:
            penalties += 0.50
        if dup.get(str(offer.get("offer_id"))):
            penalties += 0.15
        fit = max(0.0, min(1.0, fit - penalties))
        cluster_rows[cluster]["fits"].append(fit)
        offer["_fit"] = fit
        offer["_core_hits"] = [c["id"] for c in core_hits]
        offer["_title_hits"] = [c["id"] for c in title_hits]
        offer["_missing_title"] = [c["id"] for c in missing_title]
        offer["_negatives"] = [c["id"] for c in negatives]
        offer["_expired"] = expired
        offer["_duplicate"] = dup.get(str(offer.get("offer_id")), False)
        offer["_seniority"] = seniority
        offer["_salary"] = salary_from_offer(offer)

    median_count = statistics.median([v["count"] for v in demand.values()]) if demand else 0
    high_threshold = max(3, int(median_count))
    for item in demand.values():
        item["share"] = item["count"] / max(1, len(usable))
        if item["count"] >= high_threshold:
            item["status"] = "Leverage" if item["profile_has"] else "Gap"
        else:
            item["status"] = "Niche" if item["profile_has"] else "Weak"
        item["top_clusters"] = item["clusters"].most_common(3)

    for cluster, row in cluster_rows.items():
        row["avg_legacy"] = round(statistics.mean(row["legacy_scores"]), 1) if row["legacy_scores"] else 0
        row["avg_fit"] = round(statistics.mean(row["fits"]), 3) if row["fits"] else 0
        row["top_concepts"] = row["concepts"].most_common(5)

    salary_rows = []
    all_mins = []
    all_maxs = []
    salary_offers = 0
    salary_samples: List[Tuple[str, str]] = []
    for offer in usable:
        smin, smax, lines = offer.get("_salary", (None, None, []))
        if smin is None:
            continue
        salary_offers += 1
        all_mins.append(smin)
        all_maxs.append(smax)
        if lines and len(salary_samples) < 10:
            salary_samples.append((str(offer.get("title", "")), lines[0][:180]))
    overall_band = {
        "scope": "overall",
        "label": "Todas las ofertas",
        "count": salary_offers,
        "min": min(all_mins) if all_mins else None,
        "median": median_or_none([(a + b) // 2 for a, b in zip(all_mins, all_maxs)]) if all_mins else None,
        "max": max(all_maxs) if all_maxs else None,
        "share": round(salary_offers / max(1, len(usable)), 3),
    }
    salary_rows.append(overall_band)
    for cluster, row in sorted(cluster_rows.items(), key=lambda kv: -kv[1]["offers"]):
        mins = []
        maxs = []
        for offer in usable:
            if str(offer.get("cluster_name", "")) != cluster:
                continue
            smin, smax, _ = offer.get("_salary", (None, None, []))
            if smin is not None:
                mins.append(smin)
                maxs.append(smax)
        if mins:
            salary_rows.append({
                "scope": "cluster",
                "label": cluster,
                "count": len(mins),
                "min": min(mins),
                "median": median_or_none([(a + b) // 2 for a, b in zip(mins, maxs)]),
                "max": max(maxs),
                "share": round(len(mins) / max(1, row["offers"]), 3),
            })

    labels: Dict[str, Dict[str, Any]] = {}
    for offer in usable:
        fit = float(offer.get("_fit", 0))
        negatives = list(offer.get("_negatives", []))
        hard = bool(offer.get("_expired") or offer.get("_duplicate") or offer.get("_seniority"))
        domain_gap = any(cid in HARD_TITLE_GAPS for cid in offer.get("_missing_title", []))
        if hard or domain_gap or len(negatives) >= 2 or fit < 0.35:
            proxy = "negative"
        elif fit >= 0.62 and len(negatives) <= 1:
            proxy = "positive"
        else:
            proxy = "unlabeled"
        reasons = []
        if offer.get("_expired"):
            reasons.append("expirada conocida")
        if offer.get("_duplicate"):
            reasons.append("duplicada por titulo/empresa")
        if offer.get("_seniority"):
            reasons.append("nivel junior/practicante")
        if negatives:
            reasons.append("requiere: " + ", ".join(negatives))
        if offer.get("_core_hits"):
            reasons.append("cobertura core: " + ", ".join(offer["_core_hits"][:6]))
        if offer.get("_title_hits"):
            reasons.append("titulo coincide: " + ", ".join(offer["_title_hits"][:4]))
        if offer.get("_missing_title"):
            reasons.append("brecha de titulo: " + ", ".join(offer["_missing_title"][:4]))
        labels[str(offer.get("offer_id"))] = {
            "offer_key": offer.get("offer_key"),
            "title": offer.get("title"),
            "cluster": offer.get("cluster_name"),
            "market_fit": round(fit, 3),
            "proxy_label": proxy,
            "reasons": reasons,
            "flags": {
                "expired": bool(offer.get("_expired")),
                "duplicate": bool(offer.get("_duplicate")),
                "seniority_mismatch": bool(offer.get("_seniority")),
                "negative_claims": negatives,
                "title_gap": list(offer.get("_missing_title", [])),
                "salary_published": offer.get("_salary", (None, None, []))[0] is not None,
            },
        }

    adjacent = scan_adjacent() if scan else []

    return {
        "offers": offers,
        "usable": usable,
        "demand": sorted(demand.values(), key=lambda x: (-x["count"], x["id"])),
        "clusters": cluster_rows,
        "salary_rows": salary_rows,
        "salary_samples": salary_samples,
        "salary_offers": salary_offers,
        "labels": labels,
        "adjacent": adjacent,
        "known_expired": known_expired,
    }


def scan_adjacent() -> List[Dict[str, Any]]:
    results: List[Dict[str, Any]] = []
    matcher = se.ConceptMatcher()
    profile = json.loads(PROFILE_PATH.read_text(encoding="utf-8"))
    profile_ids = {c["id"] for c in matcher.positives(se.profile_text(profile))}
    for index, term in enumerate(ADJACENT_TERMS, 1):
        query = urllib.parse.quote_plus(term["query"])
        url = f"https://www.chiletrabajos.cl/encuentra-un-empleo/?2={query}&filterSearch=Buscar"
        count = None
        error = ""
        try:
            page = http_get(url, timeout=25)
            links = re.findall(r'href="(https://www\.chiletrabajos\.cl/trabajo/[^"]+)"', page)
            ids = set()
            for link in links:
                if "/postular/" in link:
                    continue
                numbers = re.findall(r"\d{6,}", link)
                if numbers:
                    ids.add(numbers[-1])
            count = len(ids)
        except (urllib.error.HTTPError, urllib.error.URLError, OSError) as exc:
            error = str(exc)[:200]
        profile_fit = any(cid in profile_ids for cid in term.get("profile_ids", []))
        capped = count is not None and count >= 30
        if profile_fit and (count or 0) >= 8:
            recommendation = "Ampliar"
        elif profile_fit and (count or 0) >= 3:
            recommendation = "Probar"
        elif not profile_fit and (count or 0) >= 8:
            recommendation = "Gap: no ampliar sin evidencia de perfil"
        else:
            recommendation = "Descartar por ahora"
        results.append({
            "id": term["id"],
            "label": term["label"],
            "query": term["query"],
            "count": count,
            "capped": capped,
            "profile_fit": profile_fit,
            "recommendation": recommendation,
            "error": error,
        })
        print(f"[adjacent {index}/{len(ADJACENT_TERMS)}] {term['label']}: {count} ({recommendation})")
        time.sleep(0.8)
    return results


def write_csv(path: Path, rows: List[Dict[str, Any]], fields: List[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def markdown_table(headers: List[str], rows: List[List[Any]]) -> str:
    lines = ["| " + " | ".join(headers) + " |", "|" + "|".join(["---"] * len(headers)) + "|"]
    for row in rows:
        lines.append("| " + " | ".join(str(cell) for cell in row) + " |")
    return "\n".join(lines)


def build_report(result: Dict[str, Any]) -> str:
    usable = result["usable"]
    demand = result["demand"]
    clusters = result["clusters"]
    labels = result["labels"]
    salary_rows = result["salary_rows"]
    total = len(result["offers"])
    positive = sum(1 for v in labels.values() if v["proxy_label"] == "positive")
    negative = sum(1 for v in labels.values() if v["proxy_label"] == "negative")
    unlabeled = len(labels) - positive - negative

    top_fit = sorted(
        [o for o in usable if labels.get(str(o.get("offer_id")), {}).get("proxy_label") == "positive"],
        key=lambda o: -float(o.get("_fit", 0)),
    )[:15]
    leverage = [d for d in demand if d["status"] == "Leverage"][:12]
    gaps = [d for d in demand if d["status"] == "Gap"][:12]
    roles = [d for d in demand if d["kind"] == "role"][:12]
    skills = [d for d in demand if d["kind"] in ("skill", "cert")][:15]

    lines: List[str] = []
    lines.append("# Informe de mercado - Apply Copilot")
    lines.append("")
    lines.append(f"Generado: {now_iso()}  ")
    lines.append(f"Corpus: `{CORPUS_DIR}`  ")
    lines.append("Metodo: lectura de descripciones publicas + motor de sinonimos + proxies. Sin etiquetas humanas.")
    lines.append("")
    lines.append("## Resumen ejecutivo")
    lines.append("")
    lines.append(f"- Ofertas en el corpus: **{total}**; con descripcion usable: **{len(usable)}**.")
    lines.append(f"- Clusters representados: **{len(clusters)}**.")
    lines.append(f"- Proxies: **{positive}** positivas, **{negative}** negativas, **{unlabeled}** sin etiqueta.")
    lines.append(f"- Renta publicada: **{result['salary_offers']}** ofertas ({fmt_pct(result['salary_offers'] / max(1, len(usable)))}). Solo lectura; nunca se autocompleta.")
    if leverage:
        lines.append("- Mayor palanca: " + ", ".join(f"{d['label']} ({d['count']})" for d in leverage[:5]) + ".")
    if gaps:
        lines.append("- Mayores gaps: " + ", ".join(f"{d['label']} ({d['count']})" for d in gaps[:5]) + ".")
    lines.append("")
    lines.append("> El `market_fit` es un proxy, no una probabilidad de contratacion. Sirve para ordenar y detectar gaps, no para afirmar exito.")
    lines.append("")

    lines.append("## Top 15 por market_fit")
    lines.append("")
    table_rows = []
    for offer in top_fit:
        table_rows.append([
            offer.get("offer_id"),
            str(offer.get("title", ""))[:55],
            str(offer.get("cluster_name", ""))[:28],
            int(offer.get("score_legacy", 0) or 0),
            f"{float(offer.get('_fit', 0)):.3f}",
            labels.get(str(offer.get("offer_id")), {}).get("proxy_label", ""),
        ])
    lines.append(markdown_table(
        ["ID", "Titulo", "Cluster", "Legacy", "Fit", "Proxy"],
        table_rows,
    ))
    lines.append("")
    lines.append("Se excluyen de esta tabla las ofertas con proxy `negative` (brecha de titulo, claims que el perfil no sostiene, expiradas, duplicadas o junior).")
    lines.append("")

    lines.append("## Demanda por rol")
    lines.append("")
    lines.append(markdown_table(
        ["Rol", "Ofertas", "%", "Titulo", "Perfil", "Estado"],
        [[d["label"], d["count"], fmt_pct(d["share"]), d["title_count"],
          "Si" if d["profile_has"] else "No", d["status"]] for d in roles],
    ))
    lines.append("")

    lines.append("## Demanda por skill / certificacion")
    lines.append("")
    lines.append(markdown_table(
        ["Skill", "Ofertas", "%", "Perfil", "Estado"],
        [[d["label"], d["count"], fmt_pct(d["share"]),
          "Si" if d["profile_has"] else "No", d["status"]] for d in skills],
    ))
    lines.append("")

    lines.append("## Clusters")
    lines.append("")
    cluster_table = []
    for name, row in sorted(clusters.items(), key=lambda kv: -kv[1]["offers"]):
        top = ", ".join(str(cid) for cid, _ in row["top_concepts"][:4])
        cluster_table.append([name, row["offers"], f"{row['avg_legacy']:.1f}", f"{row['avg_fit']:.3f}", top])
    lines.append(markdown_table(
        ["Cluster", "Ofertas", "Legacy avg", "Fit avg", "Conceptos top"],
        cluster_table,
    ))
    lines.append("")

    lines.append("## Renta publicada")
    lines.append("")
    if result["salary_offers"]:
        lines.append(markdown_table(
            ["Alcance", "Grupo", "Ofertas", "Min", "Mediana", "Max", "% del grupo"],
            [[r["scope"], r["label"], r["count"], fmt_money(r["min"]),
              fmt_money(r["median"]), fmt_money(r["max"]), fmt_pct(r["share"])]
             for r in salary_rows],
        ))
        lines.append("")
        lines.append("Muestras de lineas de renta publicada (texto original, sin normalizar):")
        lines.append("")
        for title, line in result["salary_samples"][:8]:
            lines.append(f"- {title[:60]}: `{line}`")
    else:
        lines.append("No se detectaron rentas publicadas en el corpus. No se infiere ni se inventa una banda.")
    lines.append("")

    lines.append("## Gaps y palancas")
    lines.append("")
    lines.append("**Leverage** = alta demanda + perfil lo tiene. **Gap** = alta demanda + perfil no lo tiene.")
    lines.append("")
    lines.append(markdown_table(
        ["Concepto", "Tipo", "Ofertas", "Perfil", "Estado"],
        [[d["label"], d["kind"], d["count"], "Si" if d["profile_has"] else "No", d["status"]]
         for d in demand if d["status"] in ("Leverage", "Gap")][:30],
    ))
    lines.append("")

    lines.append("## Expansion")
    lines.append("")
    if result["adjacent"]:
        lines.append("Busqueda adyacente en ChileTrabajos (conteo de avisos unicos; no es el corpus):")
        lines.append("")
        lines.append(markdown_table(
            ["Mercado", "Query", "Avisos", "Fit perfil", "Recomendacion"],
            [[r["label"], r["query"],
              (f">={r['count']}" if r.get("capped") else r["count"]) if r["count"] is not None else "error",
              "Si" if r["profile_fit"] else "No", r["recommendation"]] for r in result["adjacent"]],
        ))
        lines.append("")
    else:
        lines.append("No se ejecuto el escaneo adyacente. Usa `--scan-adjacent` para medir nuevos mercados.")
        lines.append("")

    lines.append("## Metodologia y limites")
    lines.append("")
    lines.append("- El corpus se construyo solo con ofertas `PENDING` de ChileTrabajos con score legacy >= 70.")
    lines.append("- Las descripciones son publicas; no se abrio el formulario de postulacion.")
    lines.append("- La demanda se mide por presencia de conceptos, no por intencion de contratacion.")
    lines.append("- El `market_fit` combina cobertura core, titulo, ubicacion, frescura y empresa, con penalizaciones.")
    lines.append("- Las etiquetas son proxies objetivos; no reemplazan validacion humana ni conversion real.")
    lines.append("- La renta publicada se parsea con regex y puede contener ruido; se reporta como referencia, nunca para autocompletar.")
    lines.append("")
    return "\n".join(lines)


def build_expansion(result: Dict[str, Any]) -> str:
    adjacent = result["adjacent"]
    lines = ["# Recomendacion de expansion", ""]
    if not adjacent:
        lines.append("Sin escaneo adyacente. Ejecuta `python tools/market_analysis.py --scan-adjacent`.")
        return "\n".join(lines)
    lines.append("Criterio: un mercado se amplia si el perfil ya tiene evidencia y hay al menos 8 avisos; se prueba si hay 3-7; se descarta si no hay fit o demanda.")
    lines.append("")
    lines.append(markdown_table(
        ["Mercado", "Avisos", "Fit", "Decision", "Comentario"],
        [[r["label"],
          (f">={r['count']}" if r.get("capped") else r["count"]) if r["count"] is not None else "error",
          "Si" if r["profile_fit"] else "No", r["recommendation"],
          r["error"] or "Datos observados en busqueda publica"] for r in adjacent],
    ))
    lines.append("")
    expand = [r for r in adjacent if r["recommendation"] == "Ampliar"]
    test = [r for r in adjacent if r["recommendation"] == "Probar"]
    gap = [r for r in adjacent if r["recommendation"].startswith("Gap")]
    lines.append("## Decision")
    lines.append("")
    if expand:
        lines.append("- **Ampliar ahora**: " + ", ".join(r["label"] for r in expand) + ".")
    if test:
        lines.append("- **Probar en el proximo lote**: " + ", ".join(r["label"] for r in test) + ".")
    if gap:
        lines.append("- **No ampliar sin cerrar gap**: " + ", ".join(r["label"] for r in gap) + ".")
    if not expand and not test and not gap:
        lines.append("- No hay evidencia suficiente para ampliar. Mantener ChileTrabajos y el foco actual.")
    lines.append("")
    lines.append("La decision final debe cruzar esta senal con la conversion real (`opened/filled/submitted/skipped`), no solo con el conteo de avisos.")
    return "\n".join(lines)


def main(argv: Optional[List[str]] = None) -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    parser = argparse.ArgumentParser(description="Analisis de mercado Apply Copilot")
    parser.add_argument("--scan-adjacent", action="store_true", help="Mide terminos adyacentes en ChileTrabajos")
    parser.add_argument("--min-fit", type=float, default=0.0, help="Filtro minimo de market_fit para el informe")
    args = parser.parse_args(argv)

    EVAL_DIR.mkdir(parents=True, exist_ok=True)
    corpus = load_corpus()
    if not corpus:
        print(f"ERROR: corpus vacio en {CORPUS_DIR}. Ejecuta build_corpus.py primero.", file=sys.stderr)
        return 2

    known_expired = set()
    if KNOWN_EXPIRED_PATH.exists():
        try:
            payload = json.loads(KNOWN_EXPIRED_PATH.read_text(encoding="utf-8"))
            known_expired = {str(x) for x in payload.get("ids", [])}
        except (ValueError, OSError):
            pass

    profile, profile_concepts, profile_ids = build_profile()
    result = analyse(corpus, profile_ids, known_expired, args.scan_adjacent)

    demand = result["demand"]
    skill_rows = [{
        "concept_id": d["id"], "label": d["label"], "kind": d["kind"],
        "weight": d["weight"], "demand_count": d["count"],
        "demand_share": d["share"], "title_count": d["title_count"],
        "profile_has": d["profile_has"], "status": d["status"],
        "top_clusters": "; ".join(f"{name}:{count}" for name, count in d["top_clusters"]),
    } for d in demand]
    write_csv(
        EVAL_DIR / "skill_matrix.csv", skill_rows,
        ["concept_id", "label", "kind", "weight", "demand_count", "demand_share",
         "title_count", "profile_has", "status", "top_clusters"],
    )
    write_csv(
        EVAL_DIR / "role_demand.csv",
        [r for r in skill_rows if r["kind"] == "role"],
        ["concept_id", "label", "demand_count", "demand_share", "title_count",
         "profile_has", "status", "top_clusters"],
    )
    cluster_rows = [{
        "cluster_name": name,
        "offers": row["offers"],
        "share": round(row["offers"] / max(1, len(result["usable"])), 3),
        "avg_legacy": row["avg_legacy"],
        "avg_fit": row["avg_fit"],
        "top_concepts": "; ".join(f"{cid}:{count}" for cid, count in row["top_concepts"]),
    } for name, row in result["clusters"].items()]
    write_csv(
        EVAL_DIR / "cluster_summary.csv", cluster_rows,
        ["cluster_name", "offers", "share", "avg_legacy", "avg_fit", "top_concepts"],
    )
    write_csv(
        EVAL_DIR / "salary_bands.csv", result["salary_rows"],
        ["scope", "label", "count", "min", "median", "max", "share"],
    )
    (EVAL_DIR / "proxy_labels.json").write_text(
        json.dumps({
            "generated_at": now_iso(),
            "method": "proxy-v1: market_fit + flags objetivos (expirada, duplicada, seniority, claims negativos)",
            "counts": {
                "offers": len(result["usable"]),
                "positive": sum(1 for v in result["labels"].values() if v["proxy_label"] == "positive"),
                "negative": sum(1 for v in result["labels"].values() if v["proxy_label"] == "negative"),
                "unlabeled": sum(1 for v in result["labels"].values() if v["proxy_label"] == "unlabeled"),
            },
            "labels": result["labels"],
        }, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    (EVAL_DIR / "market_report.md").write_text(build_report(result), encoding="utf-8")
    if result["adjacent"]:
        write_csv(
            EVAL_DIR / "adjacent_market.csv",
            result["adjacent"],
            ["id", "label", "query", "count", "capped", "profile_fit", "recommendation", "error"],
        )
        (EVAL_DIR / "adjacent_market.json").write_text(
            json.dumps(result["adjacent"], ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    (EVAL_DIR / "expansion_recommendation.md").write_text(
        build_expansion(result), encoding="utf-8"
    )

    print(f"Ofertas corpus: {len(result['offers'])}")
    print(f"Ofertas usables: {len(result['usable'])}")
    print(f"Conceptos con demanda: {len(demand)}")
    print(f"Renta publicada: {result['salary_offers']}")
    print(f"Reporte: {EVAL_DIR / 'market_report.md'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
