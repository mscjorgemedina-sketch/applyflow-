#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Helpers compartidos para leer el corpus de ofertas y la base legacy.

Única fuente de verdad para:
    - parse_frontmatter: separa "---\\n yml \\n---" del cuerpo de un .md
    - load_corpus: lista de ofertas del corpus (metadata + body + _path)
    - load_db: filas de data/jobs_database.json (con offer_id desde la key)

Consumidores: search_offers.py, match_engine.py, market_analysis.py.
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

TOOLS_DIR = Path(__file__).resolve().parent
ROOT = TOOLS_DIR.parent
DATA = ROOT / "data"
CORPUS_DIR = DATA / "corpus" / "offers"
DB_PATH = DATA / "jobs_database.json"


def parse_frontmatter(text: str) -> Tuple[Dict[str, Any], str]:
    match = re.match(r"^---\s*\n(.*?)\n---\s*\n(.*)$", text, re.S)
    if not match:
        return {}, text
    meta: Dict[str, Any] = {}
    for line in match.group(1).splitlines():
        if ":" not in line:
            continue
        key, raw = line.split(":", 1)
        key = key.strip()
        raw = raw.strip()
        try:
            meta[key] = json.loads(raw)
        except (ValueError, TypeError):
            meta[key] = raw.strip('"')
    return meta, match.group(2)


def load_corpus() -> List[Dict[str, Any]]:
    offers: List[Dict[str, Any]] = []
    if not CORPUS_DIR.exists():
        return offers
    for path in sorted(CORPUS_DIR.glob("*.md")):
        try:
            meta, body = parse_frontmatter(path.read_text(encoding="utf-8"))
        except OSError:
            continue
        if not meta.get("offer_id"):
            continue
        meta["_path"] = str(path)
        meta["_body"] = body
        meta["_full"] = " ".join(
            str(meta.get(k, "")) for k in ("title", "company", "location", "cluster_name")
        ) + "\n" + body
        offers.append(meta)
    return offers


def load_db() -> List[Dict[str, Any]]:
    if not DB_PATH.exists():
        return []
    db = json.loads(DB_PATH.read_text(encoding="utf-8"))
    if isinstance(db, dict):
        rows: List[Dict[str, Any]] = []
        for key, row in db.items():
            if isinstance(row, dict):
                row.setdefault("offer_id", key)  # la key del jobdb es el id real
                rows.append(row)
    else:
        rows = list(db)
    for row in rows:
        row["_full"] = " ".join(
            str(row.get(k, "")) for k in ("titulo", "empresa", "ubicacion", "snippet", "cluster_name")
        )
    return rows
