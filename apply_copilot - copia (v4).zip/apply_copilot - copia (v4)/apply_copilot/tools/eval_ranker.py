#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Evalua el ranking v2 contra el score legacy usando proxies.

No hay etiquetas humanas. Las etiquetas positivas/negativas vienen de
data/eval/proxy_labels.json y son proxies objetivos, no verdad de terreno.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import math
import statistics
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
EVAL_DIR = DATA / "eval"
QUEUE_PATH = DATA / "apply_queue.json"
PROXY_PATH = EVAL_DIR / "proxy_labels.json"


def now_iso() -> str:
    return dt.datetime.now().replace(microsecond=0).isoformat()


def dcg(gains: List[int], k: int) -> float:
    total = 0.0
    for index, gain in enumerate(gains[:k], 1):
        total += (2 ** gain - 1) / math.log2(index + 1)
    return total


def ndcg_at_k(rows: List[Dict[str, Any]], score_key: str, k: int) -> float:
    ordered = sorted(rows, key=lambda r: -float(r.get(score_key, 0) or 0))
    gains = [1 if r["_label"] == "positive" else 0 for r in ordered]
    ideal = sorted(gains, reverse=True)
    ideal_dcg = dcg(ideal, k)
    return dcg(gains, k) / ideal_dcg if ideal_dcg else 0.0


def precision_at_k(rows: List[Dict[str, Any]], score_key: str, k: int) -> float:
    ordered = sorted(rows, key=lambda r: -float(r.get(score_key, 0) or 0))[:k]
    return sum(1 for r in ordered if r["_label"] == "positive") / max(1, len(ordered))


def recall_at_k(rows: List[Dict[str, Any]], score_key: str, k: int) -> float:
    positives = sum(1 for r in rows if r["_label"] == "positive")
    ordered = sorted(rows, key=lambda r: -float(r.get(score_key, 0) or 0))[:k]
    return sum(1 for r in ordered if r["_label"] == "positive") / max(1, positives)


def average_precision(rows: List[Dict[str, Any]], score_key: str) -> float:
    ordered = sorted(rows, key=lambda r: -float(r.get(score_key, 0) or 0))
    positives = sum(1 for r in ordered if r["_label"] == "positive")
    if not positives:
        return 0.0
    hits = 0
    total = 0.0
    for index, row in enumerate(ordered, 1):
        if row["_label"] == "positive":
            hits += 1
            total += hits / index
    return total / positives


def auc(rows: List[Dict[str, Any]], score_key: str) -> float:
    positives = [float(r.get(score_key, 0) or 0) for r in rows if r["_label"] == "positive"]
    negatives = [float(r.get(score_key, 0) or 0) for r in rows if r["_label"] == "negative"]
    if not positives or not negatives:
        return 0.0
    wins = 0.0
    for p in positives:
        for n in negatives:
            if p > n:
                wins += 1.0
            elif p == n:
                wins += 0.5
    return wins / (len(positives) * len(negatives))


def average_rank(values: List[float]) -> List[float]:
    order = sorted(range(len(values)), key=lambda i: values[i])
    ranks = [0.0] * len(values)
    index = 0
    while index < len(order):
        end = index
        while end + 1 < len(order) and values[order[end + 1]] == values[order[index]]:
            end += 1
        avg = (index + end) / 2.0 + 1.0
        for pos in range(index, end + 1):
            ranks[order[pos]] = avg
        index = end + 1
    return ranks


def spearman(rows: List[Dict[str, Any]], score_key: str) -> float:
    scores = [float(r.get(score_key, 0) or 0) for r in rows]
    labels = [1.0 if r["_label"] == "positive" else 0.0 for r in rows]
    if len(scores) < 3:
        return 0.0
    rank_scores = average_rank(scores)
    rank_labels = average_rank(labels)
    mean_s = statistics.mean(rank_scores)
    mean_l = statistics.mean(rank_labels)
    numerator = sum((s - mean_s) * (l - mean_l) for s, l in zip(rank_scores, rank_labels))
    denom_s = math.sqrt(sum((s - mean_s) ** 2 for s in rank_scores))
    denom_l = math.sqrt(sum((l - mean_l) ** 2 for l in rank_labels))
    return numerator / (denom_s * denom_l) if denom_s and denom_l else 0.0


def metrics(rows: List[Dict[str, Any]], score_key: str, k: int) -> Dict[str, float]:
    return {
        f"precision@{k}": precision_at_k(rows, score_key, k),
        f"recall@{k}": recall_at_k(rows, score_key, k),
        f"ndcg@{k}": ndcg_at_k(rows, score_key, k),
        "average_precision": average_precision(rows, score_key),
        "auc": auc(rows, score_key),
        "spearman": spearman(rows, score_key),
    }


def build_report(payload: Dict[str, Any]) -> str:
    lines = ["# Comparacion de ranking", ""]
    lines.append(f"Generado: {now_iso()}  ")
    lines.append("Etiquetas: proxies objetivos (`positive` / `negative`), no etiquetas humanas.  ")
    lines.append("Las metricas son indicativas: el `market_fit` comparte senales con el motor v2.")
    lines.append("")
    lines.append("## Muestra")
    lines.append("")
    lines.append(f"- Ofertas evaluadas: **{payload['counts']['evaluated']}**")
    lines.append(f"- Positivas: **{payload['counts']['positive']}**")
    lines.append(f"- Negativas: **{payload['counts']['negative']}**")
    lines.append(f"- Sin etiqueta: **{payload['counts']['unlabeled']}**")
    lines.append("")
    lines.append("## Metricas")
    lines.append("")
    header = ["Metrica", "Legacy", "V2", "Market fit"]
    body = []
    for key in payload["metrics"]["legacy"]:
        body.append([
            key,
            f"{payload['metrics']['legacy'][key]:.3f}",
            f"{payload['metrics']['v2'][key]:.3f}",
            f"{payload['metrics']['market_fit'][key]:.3f}",
        ])
    lines.append("| " + " | ".join(header) + " |")
    lines.append("|" + "|".join(["---"] * len(header)) + "|")
    for row in body:
        lines.append("| " + " | ".join(row) + " |")
    lines.append("")
    lines.append("## Lectura")
    lines.append("")
    deltas = payload["deltas"]
    for key, value in deltas.items():
        direction = "mejora" if value > 0 else ("empeora" if value < 0 else "igual")
        lines.append(f"- `{key}`: v2 - legacy = **{value:+.3f}** ({direction}).")
    lines.append("")
    lines.append("## Limites")
    lines.append("")
    lines.append("- No existe `applied_registry.json` ni historial de envios; no hay etiqueta positiva real.")
    lines.append("- Las etiquetas negativas incluyen expiradas, duplicadas, junior y claims que el perfil no puede sostener.")
    lines.append("- Si el corpus esta sesgado por las busquedas de `job_hunter.py`, la comparacion tambien lo esta.")
    lines.append("- La decision debe complementarse con conversion real (`opened/filled/submitted/skipped`) cuando exista.")
    lines.append("")
    return "\n".join(lines)


def main(argv: Optional[List[str]] = None) -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    parser = argparse.ArgumentParser(description="Evaluacion del ranking v2")
    parser.add_argument("--k", type=int, default=10)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)

    if not QUEUE_PATH.exists():
        print(f"ERROR: no existe {QUEUE_PATH}. Ejecuta match_engine.py rank primero.", file=sys.stderr)
        return 2
    if not PROXY_PATH.exists():
        print(f"ERROR: no existe {PROXY_PATH}. Ejecuta market_analysis.py primero.", file=sys.stderr)
        return 2

    queue = json.loads(QUEUE_PATH.read_text(encoding="utf-8"))
    proxy = json.loads(PROXY_PATH.read_text(encoding="utf-8"))
    labels = proxy.get("labels", {})
    rows = []
    for row in queue.get("offers", []):
        label = labels.get(str(row.get("offer_id")), {}).get("proxy_label", "unlabeled")
        if label not in ("positive", "negative"):
            continue
        enriched = dict(row)
        enriched["_label"] = label
        rows.append(enriched)

    if len(rows) < 3:
        print("ERROR: muy pocas ofertas etiquetadas para evaluar.", file=sys.stderr)
        return 1

    counts = {
        "evaluated": len(rows),
        "positive": sum(1 for r in rows if r["_label"] == "positive"),
        "negative": sum(1 for r in rows if r["_label"] == "negative"),
        "unlabeled": len(labels) - len(rows),
    }
    legacy = metrics(rows, "score_legacy", args.k)
    v2 = metrics(rows, "score_v2", args.k)
    market_fit = metrics(rows, "market_fit", args.k)
    deltas = {key: round(v2[key] - legacy[key], 3) for key in v2}

    payload = {
        "generated_at": now_iso(),
        "k": args.k,
        "counts": counts,
        "metrics": {"legacy": legacy, "v2": v2, "market_fit": market_fit},
        "deltas": deltas,
    }
    (EVAL_DIR / "ranker_comparison.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (EVAL_DIR / "ranker_comparison.md").write_text(
        build_report(payload), encoding="utf-8"
    )

    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 0

    print(f"Evaluadas: {len(rows)} (positivas={counts['positive']}, negativas={counts['negative']})")
    print("")
    print(f"{'Metrica':<22} {'Legacy':>8} {'V2':>8} {'MarketFit':>10} {'Delta':>8}")
    for key in legacy:
        print(f"{key:<22} {legacy[key]:>8.3f} {v2[key]:>8.3f} {market_fit[key]:>10.3f} {deltas[key]:>+8.3f}")
    print("")
    print(f"Reporte: {EVAL_DIR / 'ranker_comparison.md'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
