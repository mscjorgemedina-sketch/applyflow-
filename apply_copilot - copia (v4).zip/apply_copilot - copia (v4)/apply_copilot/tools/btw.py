#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""btw v3 — guardián del loop de mejora continua (solo stdlib).

Un tick = purga de caches + selfcheck completo (10 checks) + registro en
data/btw_history.jsonl + (opcional) reparos mecánicos sobre los fallos.

Comandos:
    python tools/btw.py tick [--reparar] [--etiqueta TEXTO]
    python tools/btw.py history [-n N]
    python tools/btw.py similar <offer_id> [-n N]
    python tools/btw.py repair
"""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

TOOLS = Path(__file__).resolve().parent
ROOT = TOOLS.parent
DATA = ROOT / "data"
HIST = DATA / "btw_history.jsonl"
CFG = DATA / "btw_config.json"
CLI = ROOT / "apply_copilot.py"
CLI_RESTORE = Path(
    r"C:\Users\USUARIO1\Downloads\apply_copilot - copia (v5)\apply_copilot\apply_copilot.py"
)

sys.path.insert(0, str(TOOLS))
import selfcheck as sc  # noqa: E402


def read_cfg() -> Dict[str, Any]:
    cfg = sc.load_json(CFG)
    return cfg if isinstance(cfg, dict) else {}


def registry_fills() -> int:
    reg = sc.load_json(sc.REGISTRY) or {}
    return sum(
        1 for v in reg.values() if isinstance(v, dict) and v.get("status") == "filled"
    )


def tabs_est() -> int:
    cfg = read_cfg()
    base = int(cfg.get("baseline_tabs") or 0)
    start = int(cfg.get("fills_at_start") or 0)
    closed = int(cfg.get("closed_since_start") or 0)
    return base + max(0, registry_fills() - start) - max(0, closed)


def purge_caches() -> int:
    n = 0
    for d in list(ROOT.rglob("__pycache__")):
        try:
            shutil.rmtree(d, ignore_errors=True)
            n += 1
        except OSError:
            pass
    return n


# (auto-arreglable, diagnóstico)
DIAG: Dict[str, Tuple[bool, str]] = {
    "objetivo >=100": (False, "proponer /ir30 -NoBuscar (requiere usuario)"),
    "estado /progress": (True, "sync ya corre dentro del check"),
    "cero submit": (False, "ALERTA: auditar origen; nunca auto-arreglar"),
    "datos sensibles": (False, "revisar site_answers.json a mano"),
    "ranking v2": (True, "rank recalculado en el check"),
    "eval vs legacy": (False, "rebuild corpus (build_corpus) y re-eval"),
    "cli restaurada": (True, "restaurar apply_copilot.py desde copia (v5)"),
    "receiver v5": (True, "levantar tools/receiver.py en background"),
    "presupuesto 2MB": (False, "podar archivos pesados (ver detail)"),
    "pestañas <=100": (False, "no abrir lotes; cerrar rellenadas"),
}


def restore_cli() -> bool:
    if CLI.exists():
        return False  # existe pero falla -> reparo NO mecánico
    try:
        shutil.copyfile(CLI_RESTORE, CLI)
        return CLI.exists()
    except OSError:
        return False


def start_receiver() -> Tuple[bool, str]:
    try:
        with urllib.request.urlopen("http://127.0.0.1:8766/health", timeout=2):
            return True, "ya estaba arriba"
    except (OSError, urllib.error.URLError):
        pass
    try:
        flags = (
            getattr(subprocess, "DETACHED_PROCESS", 0)
            | getattr(subprocess, "CREATE_NO_WINDOW", 0)
        )
        proc = subprocess.Popen(
            [sys.executable, "tools/receiver.py"],
            cwd=str(ROOT),
            creationflags=flags,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        time.sleep(1.2)
        with urllib.request.urlopen("http://127.0.0.1:8766/health", timeout=3):
            return True, f"levantado pid={proc.pid}"
    except Exception as exc:  # noqa: BLE001
        return False, f"no se pudo: {exc}"


def run_checks() -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for name, fn in sc.CHECKS:
        t0 = time.time()
        try:
            ok, detalle = fn()
        except Exception as exc:  # noqa: BLE001
            ok, detalle = False, f"excepción: {exc}"
        out.append(
            {
                "name": name,
                "ok": bool(ok),
                "ms": int((time.time() - t0) * 1000),
                "detalle": str(detalle)[:200],
            }
        )
    return out


def reparaciones(resultados: List[Dict[str, Any]]) -> List[str]:
    hechos: List[str] = []
    por_nombre = {r["name"]: r for r in resultados}
    cli = por_nombre.get("cli restaurada")
    if cli and not cli["ok"] and restore_cli():
        hechos.append("cli restaurada desde copia (v5)")
    recv = por_nombre.get("receiver v5")
    if recv and not recv["ok"]:
        bien, det = start_receiver()
        if bien:
            hechos.append(f"receiver {det}")
    return hechos


def re_verificar(resultados: List[Dict[str, Any]]) -> None:
    """Re-corre solo los checks que siguen fallando tras las reparaciones."""
    names_fn = dict(sc.CHECKS)
    for r in resultados:
        if r["ok"]:
            continue
        fn = names_fn.get(r["name"])
        if not fn:
            continue
        try:
            ok, det = fn()
        except Exception as exc:  # noqa: BLE001
            ok, det = False, f"excepción: {exc}"
        if ok:
            r["ok"] = True
            r["detalle"] = str(det)[:200]


def cuenta_ticks() -> int:
    if not HIST.exists():
        return 0
    try:
        return sum(1 for _ in HIST.open("r", encoding="utf-8"))
    except OSError:
        return 0


def append_hist(reg: Dict[str, Any]) -> None:
    HIST.parent.mkdir(parents=True, exist_ok=True)
    with HIST.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(reg, ensure_ascii=False) + "\n")


def cmd_tick(etiqueta: str, reparar: bool) -> int:
    t0 = time.time()
    caches = purge_caches()
    resultados = run_checks()
    hechos: List[str] = []
    if reparar:
        hechos = reparaciones(resultados)
        if hechos:
            re_verificar(resultados)
    passed = sum(1 for r in resultados if r["ok"])
    total_ms = int((time.time() - t0) * 1000)
    code_bytes = sc.repo_code_bytes()[0]
    tabs = tabs_est()
    reg = {
        "ts": datetime.now().isoformat(timespec="seconds"),
        "tick": cuenta_ticks() + 1,
        "passed": passed,
        "total": len(resultados),
        "ms": total_ms,
        "code_bytes": code_bytes,
        "tabs_est": tabs,
        "fills": registry_fills(),
        "etiqueta": etiqueta,
        "reparos": hechos,
        "fallos": [r["name"] for r in resultados if not r["ok"]],
    }
    append_hist(reg)

    estado = "✓" if passed == len(resultados) else "✖"
    print(f"BTW tick {reg['tick']} · {reg['ts'][11:16]} · {passed}/{len(resultados)} {estado} · {total_ms / 1000:.1f}s · código {code_bytes // 1024}KB · pestañas~{tabs}")
    fallos = [r for r in resultados if not r["ok"]]
    for r in fallos[:3]:
        auto, diag = DIAG.get(r["name"], (False, "revisar a mano"))
        print(f"  ✖ {r['name']}: {r['detalle'][:110]}")
        print(f"     ({'AUTO' if auto else 'REQUIERE-USUARIO'}) {diag}")
    if caches:
        print(f"  caches purgados: {caches} (__pycache__)")
    if hechos:
        print(f"  reparado: {'; '.join(hechos)}")
    if etiqueta:
        print(f"  etiqueta: {etiqueta}")
    return 0 if passed == len(resultados) else 1


def cmd_history(n: int) -> int:
    if not HIST.exists():
        print("sin history todavía")
        return 0
    lines = HIST.read_text(encoding="utf-8").strip().splitlines()
    regs: List[Dict[str, Any]] = []
    for ln in lines[-max(n, 1):]:
        try:
            regs.append(json.loads(ln))
        except ValueError:
            continue
    if not regs:
        print("sin history legible")
        return 0
    for reg in regs:
        barra = "█" * int(reg.get("passed", 0)) + "░" * (
            int(reg.get("total", 10)) - int(reg.get("passed", 0))
        )
        print(
            f"tick {reg.get('tick', '?'):>3} · {str(reg.get('ts', ''))[11:16]} · "
            f"{reg.get('passed')}/{reg.get('total')} {barra} · {int(reg.get('ms', 0)) / 1000:.1f}s · "
            f"código {int(reg.get('code_bytes', 0)) // 1024}KB · tabs~{reg.get('tabs_est')}"
            + (f" · {reg.get('etiqueta')}" if reg.get("etiqueta") else "")
        )
    if len(regs) >= 2:
        primero, ultimo = regs[0], regs[-1]
        dms = int(ultimo.get("ms", 0)) - int(primero.get("ms", 0))
        flecha = ("▲ mejora" if dms < 0 else ("▼ empeora" if dms > 0 else "= igual"))
        print(f"tendencia: {primero.get('ms', 0)}ms → {ultimo.get('ms', 0)}ms ({flecha})")
    return 0


def cmd_similar(offer_id: str, n: int) -> int:
    """Acceso a 1 línea al pulido de 'ofertas similares' (search_offers)."""
    import search_offers as so  # noqa: PLC0415 (import tardío, barato)
    out = so.similar(offer_id, limit=n)
    if out.get("error"):
        print(f"✖ {out['error']}: {offer_id}")
        return 1
    print(f"similares a {out['title'][:58]} · {out['count']} candidatos [{out['source']}]")
    for r in out["results"][:n]:
        print(f"  {r['score']:>6.1f}  {r['title'][:56]}")
        print(f"          {r['why'][:84]} | {r['company']} | {r['location']}")
    return 0


def cmd_repair() -> int:
    resultados = run_checks()
    hechos = reparaciones(resultados)
    if hechos:
        re_verificar(resultados)
    passed = sum(1 for r in resultados if r["ok"])
    print(f"reparaciones: {'; '.join(hechos) if hechos else 'nada mecánico pendiente'}")
    print(f"checks: {passed}/{len(resultados)}")
    for r in resultados:
        if not r["ok"]:
            auto, diag = DIAG.get(r["name"], (False, "revisar a mano"))
            print(f"  ✖ {r['name']}: {diag}")
    return 0


def main(argv: Optional[List[str]] = None) -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    parser = argparse.ArgumentParser(description="btw v3 — guardián del loop")
    sub = parser.add_subparsers(dest="cmd", required=True)
    t = sub.add_parser("tick")
    t.add_argument("--reparar", action="store_true")
    t.add_argument("--etiqueta", default="")
    h = sub.add_parser("history")
    h.add_argument("-n", type=int, default=5)
    s = sub.add_parser("similar")
    s.add_argument("offer_id")
    s.add_argument("-n", "--limit", dest="limit", type=int, default=8)
    sub.add_parser("repair")
    args = parser.parse_args(argv)
    if args.cmd == "tick":
        return cmd_tick(args.etiqueta, args.reparar)
    if args.cmd == "history":
        return cmd_history(args.n)
    if args.cmd == "similar":
        return cmd_similar(args.offer_id, args.limit)
    return cmd_repair()


if __name__ == "__main__":
    raise SystemExit(main())
