#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Modo entrenamiento breve: crea perfiles/<nombre>/profile.json con lo mínimo
para que ApplyFlow pueda responder los formularios.

Solo se ejecuta si falta el perfil o si el usuario pide --entrenar.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict


def ask(label: str, default: str = "") -> str:
    suffix = f" [{default}]" if default else ""
    value = input(f"{label}{suffix}: ").strip()
    return value or default


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description="Modo entrenamiento: perfil del postulante.")
    p.add_argument("--perfil", required=True)
    p.add_argument("--dir", type=Path, required=True)
    args = p.parse_args(argv)

    folder: Path = args.dir
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / "profile.json"

    if target.exists():
        print(f"Ya existe {target}.")
        if ask("¿Usar este perfil tal cual? (S/n)", "S").lower().startswith("s"):
            return 0

    print("\n=== Modo entrenamiento (breve) ===")
    print("Responde solo lo que falte. Enter acepta el valor sugerido.\n")

    full_name = ask("Nombre completo")
    email = ask("Email")
    phone = ask("Teléfono")
    city = ask("Ciudad", "Santiago")
    years = ask("Años de experiencia", "8")
    current_role = ask("Cargo actual")
    employer = ask("Empresa actual")
    education = ask("Formación principal (título + institución)")
    skills = ask("Skills separadas por coma")
    availability = ask("Disponibilidad", "Inmediata")

    profile: Dict[str, Any] = {
        "schema_version": "1.0",
        "full_name": full_name,
        "headline": f"{education.split(',')[0] if education else 'Profesional'} | {current_role}".strip(" |"),
        "contact": {"email": email, "phone": phone},
        "location": {"city": city, "country": "Chile"},
        "links": {"linkedin": ""},
        "years_experience": int(years) if str(years).isdigit() else 0,
        "current_role": current_role,
        "current_employer": employer,
        "availability": availability,
        "education": [{"degree": education, "institution": ""}] if education else [],
        "summary": "",
        "skills": [s.strip() for s in skills.split(",") if s.strip()],
        "languages": [],
        "not_in_profile_claims": [],
        "templates": {
            "motivation": (
                "Me interesa la vacante de {cargo} porque calza con mi experiencia "
                "y mi formación. Puedo aportar rigor técnico, orden y cumplimiento."
            ),
            "strengths": skills,
        },
        "answer_rules": [
            "Nunca declarar experiencia que no esté en este perfil.",
            "Sueldo: usar la estimación de mercado generada por el sistema.",
            "LinkedIn y RUT: dejar en blanco; los completa el usuario.",
        ],
    }

    target.write_text(json.dumps(profile, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\n✔ Perfil guardado en {target}")
    print("  Ahora coloca tu CV en PDF en esa misma carpeta y vuelve a ejecutar el comando 2.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
