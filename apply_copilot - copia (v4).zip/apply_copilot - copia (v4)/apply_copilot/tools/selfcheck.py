#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Self-check del pipeline ApplyFlow v5.

10 validaciones rápidas (solo stdlib) que comprueban el estado real del
sistema después de una corrida y que el sistema está listo para otra:

    1 objetivo    >=100 rellenadas en el registro (la verdad del autofill)
    2 estado      el puente /progress (apply_state) refleja los mismos fills
    3 sin_submit  la extensión y el orquestador no contienen clics de envío
    4 sensibles   site_answers sin contraseñas/LinkedIn/datos bancarios
    5 ranking     match_engine v2 produce una cola coherente
    6 eval        el ranking v2 supera al legacy en precision@10
    7 cli         apply_copilot.py doctor/list responden bien
    8 receiver    el receptor v5 contesta en 127.0.0.1:8766
    9 presupuesto código (py/js/md/ps1, sin data/) <= 2 MB
   10 pestañas    estimado de pestañas abiertas <= 100 (guardián)

Uso:
    python tools/selfcheck.py [--silencioso]
Salida: tabla con tiempo por check y código de salida 0 (ok) / 1 (fallos).
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import re
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Callable, List, Optional, Tuple

TOOLS_DIR = Path(__file__).resolve().parent
ROOT = TOOLS_DIR.parent            # carpeta apply_copilot/
REPO = ROOT.parent                 # raíz del repo (orquestador.py, extension_v2/)
DATA = ROOT / "data"

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

LAST_RUN = DATA / "last_run.json"
REGISTRY = DATA / "fill_registry.json"
STATE = DATA / "apply_state.json"
EVENTS = DATA / "apply_events.jsonl"
SITE_ANSWERS = DATA / "site_answers.json"
SETTINGS = ROOT / "config" / "settings.json"
QUEUE = DATA / "apply_queue.json"

EXT_FILES = [
    REPO / "extension_v2" / "content" / "fill.js",
    REPO / "extension_v2" / "content" / "auto.js",
    REPO / "extension_v2" / "content" / "redirect.js",
    REPO / "extension_v2" / "background.js",
    REPO / "orquestador.py",
]
FORBIDDEN_TEXT = ("password", "linkedin", "banco", "bancari", "iban", "ruth")


def run_cmd(args: List[str], timeout: int = 180) -> Tuple[int, str]:
    try:
        r = subprocess.run(args, cwd=str(ROOT), capture_output=True, timeout=timeout)
        out = (r.stdout or b"").decode("utf-8", "replace") + (r.stderr or b"").decode("utf-8", "replace")
        return r.returncode, out
    except subprocess.TimeoutExpired:
        return 124, "timeout"


def load_json(path: Path) -> Optional[dict]:
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except (ValueError, OSError):
        return None


# ----------------------------------------------------------------- 1..8 checks
def check_objetivo() -> Tuple[bool, str]:
    """El registro de autofills es la verdad; last_run solo se consulta como contexto."""
    reg = load_json(REGISTRY) or {}
    fills = sum(1 for v in reg.values() if isinstance(v, dict) and v.get("status") == "filled")
    lr = load_json(LAST_RUN) or {}
    lr_total = int(lr.get("total_filled_all_runs") or 0) or int(lr.get("filled") or 0)
    total = max(fills, lr_total)
    if total < 100:
        return False, f"registro={fills} last_run={lr_total} (<100)"
    detalle = f"{total} rellenadas en Registro de Autofill."
    if lr_total and abs(fills - lr_total) > 8:
        detalle += f" (last_run desfasado: {lr_total}; se refresca con la próxima corrida)"
    return True, detalle


def check_estado() -> Tuple[bool, str]:
    rc, out = run_cmd([sys.executable, "tools/apply_state.py", "sync"], timeout=60)
    if rc != 0:
        return False, f"apply_state sync falló: {out.strip()[:120]}"
    st = load_json(STATE)
    if not st:
        return False, "no se generó apply_state.json"
    c = st.get("counts", {})
    applied = c.get("APPLIED", 0)
    if applied != 0:
        return False, f"APPLIED={applied} sin registro del usuario"
    antes = EVENTS.stat().st_size if EVENTS.exists() else 0
    rc2, _ = run_cmd([sys.executable, "tools/apply_state.py", "sync"], timeout=60)
    despues = EVENTS.stat().st_size if EVENTS.exists() else 0
    if rc2 != 0 or despues != antes:
        return False, f"sync no es idempotente (eventos {antes}→{despues})"
    return True, f"FILLED={c.get('FILLED')}, OPENED={c.get('OPENED')}, QUEUED={c.get('QUEUED')} | sync idempotente"


def check_sin_submit() -> Tuple[bool, str]:
    revisados = 0
    clics = 0
    for f in EXT_FILES:
        if not f.exists():
            continue
        revisados += 1
        try:
            text = f.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        for m in re.finditer(r"\.click\s*\(", text):
            ctx = text[max(0, m.start() - 90): m.end() + 90].lower()
            if re.search(r"submit|postular|envi[oa]r|\bbttn\b|sendapplication", ctx):
                clics += 1
    settings = load_json(SETTINGS) or {}
    auto = (settings.get("limits") or {}).get("auto_submit", True)
    detalle = f"{revisados} archivos revisados, clics sospechosos={clics}"
    if auto or clics:
        return False, f"{detalle} | auto_submit={auto}"
    return True, detalle + " | auto_submit=false"


def check_sensibles() -> Tuple[bool, str]:
    sa = load_json(SITE_ANSWERS)
    if not sa:
        return False, "site_answers.json no existe"
    dirty = []
    for key, val in sa.items():
        k = str(key).lower()
        if any(w in k for w in FORBIDDEN_TEXT) and str(val or "").strip() not in ("", "[]", "null"):
            dirty.append(str(key))
    settings = load_json(SETTINGS) or {}
    blocked = bool((settings.get("limits") or {}).get("block_sensitive_autofill", False))
    if dirty or not blocked:
        return False, f"campos prohibidos con datos: {dirty} | block_sensitive={blocked}"
    keys = ", ".join(sorted(str(k) for k in sa)[:4]) + "..."
    return True, f"sin datos sensibles en site_answers ({keys}) | block_sensitive=true"


def check_ranking() -> Tuple[bool, str]:
    rc, out = run_cmd([sys.executable, "tools/match_engine.py", "rank", "--top", "5", "--json"], timeout=180)
    if rc != 0 or not out.startswith("{"):
        return False, f"match_engine falló: {out.strip()[:120]}"
    payload = json.loads(out)
    offers = payload.get("offers", [])
    if not offers:
        return False, "cola vacía"
    top = offers[0]
    need = ("score_v2", "action", "risk", "reasons" if "reasons" in top else "matched")
    missing = [k for k in ("score_v2", "action", "risk", "matched") if k not in top]
    if missing:
        return False, f"campos faltantes: {missing}"
    if float(top.get("score_v2") or 0) < 70:
        return False, f"top score_v2={top.get('score_v2')} <70"
    return True, f"top1: {str(top.get('title'))[:45]}… score_v2={top.get('score_v2')} ({payload.get('counts', {})})"


def check_eval() -> Tuple[bool, str]:
    rc, out = run_cmd([sys.executable, "tools/eval_ranker.py"], timeout=120)
    if rc != 0:
        return False, f"eval_ranker falló: {out.strip()[:120]}"
    m = re.search(r"precision@10\s+([0-9.]+)\s+([0-9.]+)", out)
    if not m:
        return False, "precision@10 no se encontró"
    legacy, v2 = float(m.group(1)), float(m.group(2))
    if v2 < legacy:
        return False, f"v2={v2} < legacy={legacy}"
    return True, f"precision@10 legacy={legacy} v2={v2}"


def check_cli() -> Tuple[bool, str]:
    rc, out = run_cmd([sys.executable, "apply_copilot.py", "doctor"], timeout=90)
    if "✖" in out:
        return False, f"doctor con problemas: {[l for l in out.splitlines() if '✖' in l][0][:100]}"
    rc, listout = run_cmd([sys.executable, "apply_copilot.py", "list", "--limit", "3"], timeout=60)
    rows = [l for l in listout.splitlines() if "PENDING" in l]
    if rc != 0 or not rows:
        return False, f"list sin ofertas: {listout.strip()[:120]}"
    return True, f"doctor ✔ | list: {len(rows)} ofertas visibles"


def check_receiver() -> Tuple[bool, str]:
    try:
        with urllib.request.urlopen("http://127.0.0.1:8766/health", timeout=3) as r:
            payload = json.loads(r.read().decode("utf-8"))
    except (urllib.error.URLError, OSError, ValueError) as exc:
        return False, f"receiver no responde: {exc}"
    version = str(payload.get("version", ""))
    servicio = str(payload.get("service") or payload.get("nombre") or payload.get("name") or "")
    if "v5" not in version:
        return False, f"version'{version}' no es v5"
    return True, f"receiver {version} arriba ({servicio or 'servicio detectado'})"


REPO_BYTE_CAP = 2_000_000


def repo_code_bytes() -> Tuple[int, List[str]]:
    """Bytes de CÓDIGO (py/js/md/ps1/bat/jsonc) excluyendo data, perfiles y respaldos."""
    total = 0
    heavy = []
    for pattern in ("*.py", "*.js", "*.md", "*.ps1", "*.bat", "*.jsonc"):
        for path in REPO.rglob(pattern):
            p = str(path).lower()
            if "\\data\\" in p or "\\perfiles\\" in p or "graphify-out" in p or "__pycache__" in p:
                continue
            try:
                n = path.stat().st_size
            except OSError:
                continue
            heavy.append((n, str(path)))
            total += n
    heavy.sort(reverse=True)
    return total, [f"{Path(p).name} {n // 1024}KB" for n, p in heavy[:3]]


def check_presupuesto() -> Tuple[bool, str]:
    total, top = repo_code_bytes()
    if total > REPO_BYTE_CAP:
        return False, f"código {total // 1024}KB > 2MB; podables: {', '.join(top)}"
    return True, f"código {total // 1024}KB de 2MB · más pesado: {top[0] if top else '-'}"


def check_tabs() -> Tuple[bool, str]:
    cfg = load_json(DATA / "btw_config.json") or {}
    base = int(cfg.get("baseline_tabs") or 0)
    fills_start = int(cfg.get("fills_at_start") or 0)
    closed = int(cfg.get("closed_since_start") or 0)
    reg = load_json(REGISTRY) or {}
    now = sum(1 for v in reg.values() if isinstance(v, dict) and v.get("status") == "filled")
    est = base + max(0, now - fills_start) - max(0, closed)
    warn = " (aviso ≥90: cerrar rellenadas antes del próximo lote)" if est >= 90 else ""
    if est > 100:
        return False, f"estimado {est} > 100 — no abrir más lotes"
    return True, f"estimado {est}/100 abiertas (base {base}, +{max(0, now - fills_start)} desde arranque){warn}"


CHECKS: List[Tuple[str, Callable[[], Tuple[bool, str]]]] = [
    ("objetivo >=100", check_objetivo),
    ("estado /progress", check_estado),
    ("cero submit", check_sin_submit),
    ("datos sensibles", check_sensibles),
    ("ranking v2", check_ranking),
    ("eval vs legacy", check_eval),
    ("cli restaurada", check_cli),
    ("receiver v5", check_receiver),
    ("presupuesto 2MB", check_presupuesto),
    ("pestañas <=100", check_tabs),
]


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Self-check ApplyFlow v5")
    parser.add_argument("--silencioso", action="store_true", help="Solo el resumen final")
    args = parser.parse_args(argv)

    rows = []
    ok_total = 0
    print("ApplyFlow v5 — self-check")
    print()
    for i, (name, fn) in enumerate(CHECKS, 1):
        t0 = time.perf_counter()
        try:
            ok, detail = fn()
        except Exception as exc:  # el check no debe tumbar la suite
            ok, detail = False, f"excepción: {exc}"
        ms = int((time.perf_counter() - t0) * 1000)
        if ok:
            ok_total += 1
        rows.append((i, name, ms, ok, detail))
        if not args.silencioso:
            print(f"  {'✓' if ok else '✗'}  [{i}] {name:<16} {ms:>5} ms  {detail}")

    print()
    sec = sum(r[2] for r in rows) / 1000
    print(f"Resultado: {ok_total}/{len(CHECKS)} ok — {dt.datetime.now():%Y-%m-%d %H:%M:%S} — {sec:.1f}s")
    if ok_total < len(CHECKS):
        for i, name, _, _, detail in rows:
            if not (i and name):
                print(f"  falló [{i}] {name}: {detail}")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
