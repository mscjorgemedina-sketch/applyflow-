#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Gate de aceptación de 1 comando para ApplyFlow (solo stdlib, sin red de relleno).

Ejecuta en secuencia:
    1 selfcheck completo (10 checks)
    2 salary --autotest (11)
    3 search smoke (soldador >= 5 válidos y título soldadura arriba)
    4 similar smoke (ch_ fixture: >=10 candidatos y top1 score >= 40)
    5 duplicados smoke (>= 1 grupo, el cliente con par conocido)
    6 cola v2 coherente (offers 143, priorizar >= 30)

Uso:
    python tools/acceptance.py            # corre todo, imprime PASS/FAIL, exit 0/1
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path
from typing import Any, Callable, List, Tuple

TOOLS = Path(__file__).resolve().parent
ROOT = TOOLS.parent
DATA = ROOT / "data"
QUEUE = DATA / "apply_queue.json"

FIXTURE_SIMILAR = "ch_dc701aeb075f"          # PROJECT MANAGER – PROYECTO EN OSORNO


def run(cmd: List[str], timeout: int = 300) -> Tuple[int, str]:
    proc = subprocess.run(
        cmd, cwd=str(ROOT), capture_output=True, text=True,
        encoding="utf-8", errors="replace", timeout=timeout,
    )
    return proc.returncode, (proc.stdout + proc.stderr)


def main() -> int:  # type: ignore[return]
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    stats = {"ok": 0, "total": 0, "fallos": []}

    def check(name: str, fn: Callable[[], Tuple[bool, str]]) -> None:
        stats["total"] += 1
        try:
            ok, detail = fn()
        except Exception as exc:  # noqa: BLE001
            ok, detail = False, f"excepción: {exc}"
        if ok:
            stats["ok"] += 1
            print(f"  ✓ {name}" + (f" — {detail}" if detail else ""))
        else:
            print(f"  ✖ {name} — {detail}")
            stats["fallos"].append(name)

    def t_selfcheck() -> Tuple[bool, str]:
        code, out = run([sys.executable, "tools/selfcheck.py", "--silencioso"])
        return code == 0, f"{out.strip().splitlines()[-1] if out.strip() else ''}"

    def t_salary() -> Tuple[bool, str]:
        code, out = run([sys.executable, "tools/salary.py", "--autotest"])
        return code == 0, "autotest 11/11" if code == 0 else out[-120:]

    sys.path.insert(0, str(TOOLS))

    def t_search() -> Tuple[bool, str]:
        import search_offers as so  # noqa: PLC0415
        out = so.search("soldador", limit=10)
        good = out["count"] >= 5 and any(
            "soldad" in str(r["title"]).lower() for r in out["results"][:5]
        )
        return good, f"count={out['count']} [{out['source']}]"

    def t_similar() -> Tuple[bool, str]:
        import search_offers as so  # noqa: PLC0415
        out = so.similar(FIXTURE_SIMILAR, limit=10)
        if out.get("error"):
            return False, out["error"]
        top = out["results"][0] if out["results"] else {"score": 0}
        return out["count"] >= 10 and top["score"] >= 40, f"count={out['count']} top={top['score']}"

    def t_dupe() -> Tuple[bool, str]:
        import search_offers as so  # noqa: PLC0415
        out = so.find_duplicates()
        return out["total_grupos_duplicados"] >= 1, f"{out['total_grupos_duplicados']} grupos"

    def t_queue() -> Tuple[bool, str]:
        q = json.loads(QUEUE.read_text(encoding="utf-8-sig"))
        c = q.get("counts", {})
        return c.get("offers", 0) >= 140 and c.get("priorizar", 0) >= 30, \
            f"offers={c.get('offers')} priorizar={c.get('priorizar')}"

    check("selfcheck 10", t_selfcheck)
    check("salary autotest", t_salary)
    check("search smoke", t_search)
    check("similar smoke", t_similar)
    check("duplicados smoke", t_dupe)
    check("cola v2", t_queue)

    if stats["fallos"]:
        print(f"acceptance: {len(stats['fallos'])}/{stats['total']} FALLA: {'; '.join(stats['fallos'])}")
        return 1
    print(f"acceptance: OK ({stats['ok']}/{stats['total']})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
