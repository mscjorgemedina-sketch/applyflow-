#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Busqueda de ofertas por sinonimos sobre el corpus o la base legacy."""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

TOOLS_DIR = Path(__file__).resolve().parent
ROOT = TOOLS_DIR.parent
sys.path.insert(0, str(TOOLS_DIR))

import corpus_common as cc  # noqa: E402
import synonym_engine as se  # noqa: E402

DATA = ROOT / "data"
CORPUS_DIR = cc.CORPUS_DIR
DB_PATH = cc.DB_PATH

# loaders únicos desde corpus_common (antes duplicados en 3 herramientas)
load_corpus = cc.load_corpus
load_db = cc.load_db


def jaccard(a: Set[str], b: Set[str]) -> float:
    """Intersección sobre unión de tokens (0.0 si alguno está vacío)."""
    if not a or not b:
        return 0.0
    inter = a & b
    if not inter:
        return 0.0
    return len(inter) / len(a | b)


def _locate(rows: List[Dict[str, Any]], offer_id: str) -> Optional[Dict[str, Any]]:
    want = str(offer_id).strip().lower()
    for row in rows:
        oid = str(row.get("offer_id") or row.get("id") or "").lower()
        if oid == want or oid.endswith("_" + want) or want.endswith("_" + oid):
            return row
    return None


def _title_key(title: str) -> str:
    norm = se.normalize(title)
    return re.sub(r"[^a-z0-9 ]+", " ", norm).strip()


def find_duplicates(min_jac: float = 0.85, source: str = "auto") -> Dict[str, Any]:
    """Detecta reposts/cargos duplicados (títulos casi idénticos) para saltarlos."""
    if source in ("auto", ""):
        rows = load_corpus()
        seen_oids = {str(r.get("offer_id") or r.get("id") or "") for r in rows}
        for r in load_db():
            oid = str(r.get("offer_id") or r.get("id") or "")
            if oid and oid not in seen_oids:
                seen_oids.add(oid)
                rows.append(r)
        fuente = "corpus+db"
    elif source == "corpus":
        rows, fuente = load_corpus(), "corpus"
    else:
        rows, fuente = load_db(), "jobs_database"

    items = []
    for r in rows:
        oid = str(r.get("offer_id") or r.get("id") or "")
        title = str(r.get("title") or r.get("titulo") or "")
        if oid and title:
            items.append((oid, title, _title_key(title)))
    items.sort(key=lambda x: x[2])
    grupos = []
    for oid, title, key in items:
        grupo = grupos[-1] if grupos else None
        if not grupo:
            grupos.append({"ids": [oid], "titulos": [title]})
            continue
        prev = _title_key(grupo["titulos"][0])
        jac = jaccard(set(prev.split()), set(key.split()))
        identical = jac >= min_jac
        if identical:
            grupo["ids"].append(oid)
            grupo["titulos"].append(title)
        else:
            grupos.append({"ids": [oid], "titulos": [title]})
    terceros = [g for g in grupos if len(g["ids"]) > 1]
    terceros.sort(key=lambda g: -len(g["ids"]))
    return {"fuente": fuente, "total_grupos_duplicados": len(terceros),
            "grupos": [{"ids": g["ids"], "titulos": [t[:70] for t in g["titulos"]]} for g in terceros]}


def similar(offer_id: str, limit: int = 10, source: str = "auto") -> Dict[str, Any]:
    """Ofertas parecidas a una dada.

    Score = solapamiento de conceptos + Jaccard de tokens del título
    + bonus de mismo cluster/zona/empresa. En modo auto fusiona corpus + db
    (dedup por offer_id) para poder localizar la oferta y tener más candidatos.
    """
    matcher = se.ConceptMatcher()
    use_corpus = source == "corpus" or (source == "auto" and CORPUS_DIR.exists() and any(CORPUS_DIR.glob("*.md")))
    if use_corpus:
        rows = load_corpus()
        source_used = "corpus"
    else:
        rows = load_db()
        source_used = "jobs_database"
    if source in ("auto", ""):
        corpus_ids = {str(r.get("offer_id") or r.get("id") or "") for r in rows}
        for r in load_db():
            oid = str(r.get("offer_id") or r.get("id") or "")
            if oid and oid not in corpus_ids:
                corpus_ids.add(oid)
                rows.append(r)
        source_used = "corpus+db" if use_corpus else "jobs_database(+corpus vacío)"

    target = _locate(rows, offer_id)
    if not target:
        return {"similar_to": offer_id, "source": source_used, "error": "oferta no encontrada", "count": 0, "results": []}

    title_t = str(target.get("title") or target.get("titulo") or "")
    loc_t = se.normalize(target.get("location") or target.get("ubicacion") or "")
    comp_t = se.normalize(target.get("company") or target.get("empresa") or "")
    cluster_t = str(target.get("cluster_name") or "")
    tokens_t = set(se.tokens(title_t))
    concepts_t = {c["id"] for c in matcher.positives(str(target.get("_full", "")))}

    results: List[Dict[str, Any]] = []
    for row in rows:
        oid = str(row.get("offer_id") or row.get("id") or "")
        if oid.lower() == str(target.get("offer_id") or target.get("id") or "").lower():
            continue
        title = str(row.get("title") or row.get("titulo") or "")
        why: List[str] = []
        score = 0.0
        concepts_r = {c["id"] for c in matcher.positives(str(row.get("_full", "")))}
        overlap = concepts_t & concepts_r
        if overlap:
            score += min(len(overlap), 8) * 6.0
            why.append(f"{len(overlap)} conceptos comunes")
        jac = jaccard(tokens_t, set(se.tokens(title)))
        if jac > 0.05 and jac >= 0.25:
            score += jac * 35.0
            why.append(f"títulos {int(jac * 100)}% iguales")
        cluster_r = str(row.get("cluster_name") or "")
        if cluster_t and cluster_t == cluster_r:
            score += 15.0
            why.append(f"mismo cluster ({cluster_r or '?'})")
        loc_r = se.normalize(row.get("location") or row.get("ubicacion") or "")
        if loc_t and loc_r and (loc_t in loc_r or loc_r in loc_t):
            score += 8.0
            why.append("misma zona")
        comp_r = se.normalize(row.get("company") or row.get("empresa") or "")
        if comp_t and comp_t == comp_r:
            score += 5.0
            why.append("misma empresa")
        score += int(row.get("score_legacy") or row.get("score") or 0) / 40.0
        if score < 8.0:
            continue
        results.append({
            "offer_id": oid,
            "title": title,
            "company": row.get("company") or row.get("empresa") or "",
            "location": row.get("location") or row.get("ubicacion") or "",
            "cluster": cluster_r,
            "score": round(score, 2),
            "why": "; ".join(why[:3]),
            "url": row.get("url") or "",
        })

    results.sort(key=lambda r: (-r["score"], str(r["offer_id"])))
    return {
        "similar_to": offer_id,
        "title": title_t,
        "source": source_used,
        "count": len(results),
        "results": results[:limit],
    }


def search(query: str, limit: int = 20, source: str = "auto", portal: str = "") -> Dict[str, Any]:
    matcher = se.ConceptMatcher()
    expansion = matcher.expand(query)
    query_concepts = {c["id"]: c for c in expansion["concepts"]}
    query_norm = se.normalize(query)

    if source == "corpus" or (source == "auto" and CORPUS_DIR.exists() and any(CORPUS_DIR.glob("*.md"))):
        rows = load_corpus()
        source_used = "corpus"
    else:
        rows = load_db()
        source_used = "jobs_database"
    if source in ("auto", ""):  # fusión: añade filas que solo existen en la base
        vistos = {str(r.get("offer_id") or r.get("id") or "") for r in rows}
        for r in load_db():
            oid = str(r.get("offer_id") or r.get("id") or "")
            if oid and oid not in vistos:
                vistos.add(oid)
                rows.append(r)
        source_used = "corpus+db" if source_used == "corpus" else source_used

    results = []
    for row in rows:
        if portal and portal.lower() not in str(row.get("portal", "")).lower():
            continue
        title = str(row.get("title") or row.get("titulo") or "")
        title_norm = se.normalize(title)
        text = str(row.get("_full", ""))
        concept_ids = {c["id"] for c in matcher.positives(text)}
        title_ids = {c["id"] for c in matcher.positives(title)}
        matched = [cid for cid in query_concepts if cid in concept_ids]
        # conceptos presentes en el título valen más (señal directa); los que
        # solo aparecen en el cuerpo pesan un 40% menos.
        score = 0.0
        for cid in matched:
            w = query_concepts[cid]["weight"] * (1.0 if cid in title_ids else 0.6)
            score += w * 10.0
        if query_norm and query_norm in title_norm:
            score += 25.0
        elif query_norm and query_norm in se.normalize(text):
            score += 8.0
        jac = jaccard(set(se.tokens(query)), set(se.tokens(title)))
        score += jac * 20.0
        score += int(row.get("score_legacy") or row.get("score") or 0) / 20.0
        # piso de relevancia: sin concepto matcheado ni token del query en el
        # título, la fila no es resultado del query (evita "devolver TODO").
        token_hit = set(se.tokens(query)) & set(se.tokens(title))
        if not matched and not token_hit:
            continue
        results.append({
            "offer_id": row.get("offer_id") or row.get("id"),
            "title": title,
            "company": row.get("company") or row.get("empresa") or "",
            "location": row.get("location") or row.get("ubicacion") or "",
            "cluster": row.get("cluster_name") or "",
            "score": round(score, 2),
            "score_legacy": int(row.get("score_legacy") or row.get("score") or 0),
            "matched": [query_concepts[cid]["label"] for cid in matched],
            "url": row.get("url") or "",
        })

    results.sort(key=lambda r: (-r["score"], -r["score_legacy"], str(r["offer_id"])))
    deduped = []
    seen = set()
    for row in results:
        key = str(row.get("offer_id"))
        if key in seen:
            continue
        seen.add(key)
        deduped.append(row)
    return {
        "query": query,
        "source": source_used,
        "expanded_concepts": expansion["concepts"],
        "count": len(deduped),
        "results": deduped[:limit],
    }


def main(argv: Optional[List[str]] = None) -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    parser = argparse.ArgumentParser(description="Busqueda de ofertas por sinonimos")
    parser.add_argument("query", nargs="?", default="", help="texto a buscar (obligatorio salvo con --similar)")
    parser.add_argument("--similar", dest="similar", default="", help="busca ofertas parecidas a esta offer_id")
    parser.add_argument("--duplicados", action="store_true", help="lista grupos de titles casi idénticos (reposts)")
    parser.add_argument("--umbral", type=float, default=0.85, help="jaccard mínimo para contar duplicados")
    parser.add_argument("--limit", type=int, default=20)
    parser.add_argument("--source", choices=["auto", "corpus", "db"], default="auto")
    parser.add_argument("--portal", default="")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)

    if args.similar:
        payload = similar(args.similar, args.limit, args.source)
    elif args.duplicados:
        payload = find_duplicates(min_jac=args.umbral, source=args.source)
    else:
        if not args.query.strip():
            parser.error("se necesita una consulta de texto o --similar <offer_id>")
        payload = search(args.query, args.limit, args.source, args.portal)
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 0

    if args.duplicados:
        print(f"Duplicados [{payload['fuente']}]: {payload['total_grupos_duplicados']} grupos")
        for g in payload["grupos"][:15]:
            ids_txt = " / ".join(g["ids"][:4])
            if len(g["ids"]) > 4:
                ids_txt += " +..."
            print(f"  {ids_txt} ({len(g['ids'])}): {g['titulos'][0]}")
        return 0

    if args.similar:
        if payload.get("error"):
            print(f"ERROR: {payload['error']} ({payload.get('source')})")
            return 1
        print(f"Similares a: {payload['title'][:70]}")
        print(f"Fuente: {payload['source']} | resultados: {payload['count']}")
        print("")
        for row in payload["results"]:
            print(f"{row['score']:>6.2f}  {row['title'][:70]}")
            print(f"        {row['why']} | {row['company']} | {row['location']}")
        return 0

    print(f"Query: {payload['query']}")
    print(f"Fuente: {payload['source']} | resultados: {payload['count']}")
    print("Conceptos: " + (", ".join(c["label"] for c in payload["expanded_concepts"]) or "ninguno"))
    print("")
    for row in payload["results"]:
        print(
            f"{row['score']:>6.2f}  legacy={row['score_legacy']:>3}  "
            f"{str(row['title'])[:70]}"
        )
        if row["matched"]:
            print(f"        match: {', '.join(row['matched'][:5])}")
        print(f"        {row['company']} | {row['location']} | {row['offer_id']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
