#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Motor de sinonimos y conceptos para Apply Copilot.

Solo stdlib. Normaliza texto, expande aliases y detecta conceptos presentes
en una oferta o en el perfil del candidato.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
import unicodedata
from collections import Counter
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
DEFAULT_LEXICON = DATA / "synonyms.json"

STOPWORDS = {
    "para", "como", "con", "por", "del", "las", "los", "una", "uno", "unos",
    "unas", "que", "sus", "mas", "pero", "sobre", "entre", "desde", "hasta",
    "este", "esta", "estos", "estas", "ser", "estar", "tiene", "tener",
    "requiere", "requisitos", "funciones", "empresa", "trabajo", "cargo",
    "puesto", "oferta", "empleo", "anos", "experiencia", "conocimientos",
    "deseable", "indispensable", "importante", "ademas", "segun", "cada",
    "todo", "toda", "todos", "todas", "otro", "otra", "otros", "otras",
    "nuestro", "nuestra", "cliente", "clientes", "proyecto", "proyectos",
}


def normalize(text: Any) -> str:
    """Minusculas, sin tildes, solo alfanumerico separado por espacios."""
    if text is None:
        return ""
    raw = unicodedata.normalize("NFKD", str(text))
    raw = "".join(ch for ch in raw if not unicodedata.combining(ch))
    raw = raw.lower()
    raw = re.sub(r"[^a-z0-9]+", " ", raw)
    return re.sub(r"\s+", " ", raw).strip()


def tokens(text: Any) -> List[str]:
    return [t for t in normalize(text).split() if t]


def phrase_in(alias: str, text_norm: str) -> bool:
    """Coincidencia por frase completa, no por substring."""
    if not alias:
        return False
    pattern = r"(?<!\w)" + re.escape(alias) + r"(?!\w)"
    return re.search(pattern, text_norm) is not None


def load_lexicon(path: Path = DEFAULT_LEXICON) -> Dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict) or not isinstance(data.get("concepts"), list):
        raise ValueError(f"Lexicon invalido: {path}")
    return data


class ConceptMatcher:
    def __init__(self, lexicon: Optional[Dict[str, Any]] = None):
        self.lexicon = lexicon or load_lexicon()
        self.concepts: List[Dict[str, Any]] = [
            c for c in self.lexicon["concepts"] if c.get("aliases")
        ]

    def match(self, text: Any) -> List[Dict[str, Any]]:
        """Devuelve conceptos detectados, sin duplicados, ordenados por peso."""
        text_norm = normalize(text)
        if not text_norm:
            return []
        found: Dict[str, Dict[str, Any]] = {}
        for concept in self.concepts:
            aliases = [normalize(a) for a in concept.get("aliases", []) if normalize(a)]
            negatives = [normalize(n) for n in concept.get("negative_context", []) if normalize(n)]
            if any(phrase_in(neg, text_norm) for neg in negatives):
                continue
            matched_alias = next((a for a in aliases if phrase_in(a, text_norm)), None)
            if not matched_alias:
                continue
            cid = str(concept["id"])
            if cid in found:
                continue
            found[cid] = {
                "id": cid,
                "label": concept.get("label", cid),
                "kind": concept.get("kind", "skill"),
                "weight": float(concept.get("weight", 0.5)),
                "negative": bool(concept.get("negative", False)),
                "matched_alias": matched_alias,
            }
        return sorted(found.values(), key=lambda c: (-c["weight"], c["id"]))

    def ids(self, text: Any, include_negative: bool = True) -> Set[str]:
        return {
            c["id"]
            for c in self.match(text)
            if include_negative or not c["negative"]
        }

    def positives(self, text: Any) -> List[Dict[str, Any]]:
        return [c for c in self.match(text) if not c["negative"]]

    def negatives(self, text: Any) -> List[Dict[str, Any]]:
        return [c for c in self.match(text) if c["negative"]]

    def expand(self, text: Any) -> Dict[str, Any]:
        matched = self.match(text)
        return {
            "query": text,
            "concepts": matched,
            "expanded_terms": sorted({c["label"] for c in matched}),
        }

    def coverage(self, profile_text: Any, offer_text: Any) -> Dict[str, Any]:
        profile = {c["id"]: c for c in self.positives(profile_text)}
        offer = {c["id"]: c for c in self.positives(offer_text)}
        shared = sorted(set(profile) & set(offer), key=lambda i: -profile[i]["weight"])
        missing = sorted(set(offer) - set(profile), key=lambda i: -offer[i]["weight"])
        return {
            "profile_count": len(profile),
            "offer_count": len(offer),
            "shared": [offer[i] for i in shared],
            "missing": [offer[i] for i in missing],
            "coverage": round(len(shared) / max(1, len(offer)), 3),
        }


def profile_text(profile: Dict[str, Any]) -> str:
    parts: List[str] = []
    for key in ("headline", "summary", "current_role"):
        if profile.get(key):
            parts.append(str(profile[key]))
    for key in ("skills", "clients_experience", "achievements", "not_in_profile_claims"):
        value = profile.get(key) or []
        if isinstance(value, list):
            parts.extend(str(v) for v in value)
    for edu in profile.get("education") or []:
        if isinstance(edu, dict):
            parts.append(f"{edu.get('degree', '')} {edu.get('institution', '')}")
    templates = profile.get("templates") or {}
    if isinstance(templates, dict):
        parts.extend(str(v) for v in templates.values())
    return "\n".join(parts)


def suggest_unmatched(texts: Iterable[str], top: int = 40) -> List[Tuple[str, int]]:
    matcher = ConceptMatcher()
    known: Set[str] = set()
    for concept in matcher.concepts:
        for alias in concept.get("aliases", []):
            known.update(tokens(alias))
        known.update(tokens(concept.get("label", "")))
    counter: Counter = Counter()
    for text in texts:
        for token in tokens(text):
            if len(token) < 4 or token in STOPWORDS or token in known:
                continue
            if token.isdigit():
                continue
            counter[token] += 1
    return counter.most_common(top)


def _read_corpus(path: Path) -> List[str]:
    texts: List[str] = []
    if path.is_dir():
        for file in sorted(path.rglob("*.md")):
            try:
                texts.append(file.read_text(encoding="utf-8"))
            except OSError:
                continue
    elif path.exists():
        texts.append(path.read_text(encoding="utf-8"))
    return texts


def main(argv: Optional[List[str]] = None) -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    parser = argparse.ArgumentParser(description="Motor de sinonimos de Apply Copilot")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_expand = sub.add_parser("expand", help="Expande un texto a conceptos")
    p_expand.add_argument("text")

    p_match = sub.add_parser("match", help="Muestra conceptos detectados")
    p_match.add_argument("text")

    p_profile = sub.add_parser("profile", help="Conceptos detectados en el perfil")
    p_profile.add_argument("--profile", default=str(ROOT / "config" / "profile.json"))

    p_suggest = sub.add_parser("suggest", help="Sugiere terminos no cubiertos")
    p_suggest.add_argument("--corpus", default=str(DATA / "corpus" / "offers"))
    p_suggest.add_argument("--top", type=int, default=40)

    sub.add_parser("check", help="Valida el lexicon")

    args = parser.parse_args(argv)
    matcher = ConceptMatcher()

    if args.cmd in ("expand", "match"):
        result = matcher.expand(args.text)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0

    if args.cmd == "profile":
        profile = json.loads(Path(args.profile).read_text(encoding="utf-8"))
        concepts = matcher.match(profile_text(profile))
        print(json.dumps(
            {"count": len(concepts), "concepts": concepts},
            ensure_ascii=False, indent=2,
        ))
        return 0

    if args.cmd == "suggest":
        texts = _read_corpus(Path(args.corpus))
        if not texts:
            db = DATA / "jobs_database.json"
            if db.exists():
                data = json.loads(db.read_text(encoding="utf-8"))
                rows = data.values() if isinstance(data, dict) else data
                texts = [f"{r.get('titulo', '')} {r.get('snippet', '')}" for r in rows]
        suggestions = suggest_unmatched(texts, args.top)
        print(json.dumps(
            [{"term": term, "count": count} for term, count in suggestions],
            ensure_ascii=False, indent=2,
        ))
        return 0

    if args.cmd == "check":
        errors: List[str] = []
        seen: Dict[str, str] = {}
        for concept in matcher.concepts:
            cid = str(concept.get("id", ""))
            if not re.fullmatch(r"[a-z0-9_]+", cid):
                errors.append(f"id invalido: {cid!r}")
            for alias in concept.get("aliases", []):
                norm = normalize(alias)
                if not norm:
                    errors.append(f"{cid}: alias vacio")
                    continue
                if alias != norm:
                    errors.append(f"{cid}: alias no normalizado: {alias!r} -> {norm!r}")
                if norm in seen and seen[norm] != cid:
                    errors.append(f"alias duplicado {norm!r}: {seen[norm]} y {cid}")
                seen[norm] = cid
        result = {
            "concepts": len(matcher.concepts),
            "aliases": len(seen),
            "errors": errors,
        }
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 1 if errors else 0

    return 2


if __name__ == "__main__":
    raise SystemExit(main())
