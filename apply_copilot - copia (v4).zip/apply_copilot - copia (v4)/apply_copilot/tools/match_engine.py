#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Motor de ranking v2 para ofertas de ChileTrabajos.

Combina cobertura de conceptos del perfil, titulo, skills, descripcion,
ubicacion, frescura y empresa. Aplica penalizaciones por requisitos que el
perfil no puede reclamar, ofertas expiradas, duplicadas o junior.

Genera data/apply_queue.json y data/eval/ranking_v2.csv.
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import json
import re
import statistics
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

TOOLS_DIR = Path(__file__).resolve().parent
ROOT = TOOLS_DIR.parent
sys.path.insert(0, str(TOOLS_DIR))

import corpus_common as cc  # noqa: E402
import synonym_engine as se  # noqa: E402

DATA = ROOT / "data"
CORPUS_DIR = cc.CORPUS_DIR
EVAL_DIR = DATA / "eval"
PROFILE_PATH = ROOT / "config" / "profile.json"
QUEUE_PATH = DATA / "apply_queue.json"
PROXY_PATH = EVAL_DIR / "proxy_labels.json"
KNOWN_EXPIRED_PATH = EVAL_DIR / "known_expired.json"

CORE_IDS = {
    "ito", "qa_qc", "project_manager", "contract_admin", "project_engineer",
    "planning", "maintenance", "reliability", "operations", "maestranza",
    "commissioning", "mechanical_engineer", "piping", "mining", "construction",
    "industrial", "sap", "nfpa", "sec", "asme", "iso9001", "pdca", "glp",
    "pumping", "project_control", "cost_control", "procurement",
    "asset_management", "site_supervisor", "energy", "welding", "ndt", "pem",
}
KNOWN_CLIENTS = ["bhp", "codelco", "anglo", "glencore", "flsmidth", "multotec"]
DOMAIN_GAPS = {
    "civil", "water_sanitary", "hvac", "welding", "ndt", "pem", "commissioning",
    "reliability", "cost_control", "procurement", "asset_management",
    "project_control", "electrical", "instrumentation", "transmission_lines",
    "fiber_optic", "medium_voltage", "low_voltage", "product_manager",
}
HARD_TITLE_PENALTY = {
    "civil": 10.0, "water_sanitary": 8.0, "hvac": 12.0, "welding": 8.0,
    "ndt": 8.0, "pem": 8.0, "product_manager": 12.0,
}
SPANISH_MONTHS = {
    "enero": 1, "febrero": 2, "marzo": 3, "abril": 4, "mayo": 5, "junio": 6,
    "julio": 7, "agosto": 8, "septiembre": 9, "setiembre": 9, "octubre": 10,
    "noviembre": 11, "diciembre": 12,
}


def now_iso() -> str:
    return dt.datetime.now().replace(microsecond=0).isoformat()


load_corpus = cc.load_corpus  # loader único (antes duplicado aquí)


def parse_date(value: Any) -> Optional[dt.date]:
    if not value:
        return None
    text = str(value).strip().lower()
    if not text or text in ("n/d", "nd"):
        return None
    if text.startswith("hace"):
        m = re.search(r"(\d+)", text)
        return dt.date.today() - dt.timedelta(days=int(m.group(1))) if m else None
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})", text)
    if m:
        try:
            return dt.date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except ValueError:
            return None
    m = re.search(r"(\d{1,2})\s+de\s+([a-z]+)\s+de\s+(\d{4})", text)
    if m and m.group(2) in SPANISH_MONTHS:
        try:
            return dt.date(int(m.group(3)), SPANISH_MONTHS[m.group(2)], int(m.group(1)))
        except ValueError:
            return None
    return None


def freshness_score(value: Any) -> float:
    date = parse_date(value)
    if not date:
        return 0.5
    days = max(0, (dt.date.today() - date).days)
    if days <= 7:
        return 1.0
    if days <= 30:
        return 0.85
    if days <= 60:
        return 0.6
    if days <= 90:
        return 0.35
    return 0.15


def location_score(location: str, title: str) -> float:
    loc = se.normalize(f"{location} {title}")
    if not loc or loc in ("chile", "n d", "nd"):
        return 0.8
    if any(k in loc for k in ("remoto", "teletrabajo", "home office", "hibrido")):
        return 1.0
    if any(k in loc for k in ("santiago", "region metropolitana", "providencia", "las condes", "maipu", "puente alto")):
        return 1.0
    if any(k in loc for k in ("antofagasta", "calama", "el loa", "ii region")):
        return 0.65
    if any(k in loc for k in ("fifo", "faena", "campamento")):
        return 0.75
    return 0.6


def company_score(company: str, text: str) -> float:
    blob = se.normalize(f"{company} {text}")
    if any(client in blob for client in KNOWN_CLIENTS):
        return 1.0
    if company and se.normalize(company) not in ("n d", "nd", "chile"):
        return 0.7
    return 0.5


def _title_tokens(title: str) -> set:
    """Tokens del título sin números ('7-21', '18.902') para comparar reposts."""
    text = re.sub(r"[^a-z0-9 ]+", " ", se.normalize(title)).strip()
    return {t for t in text.split() if not t.isdigit()}


def _jaccard(a: set, b: set) -> float:
    if not a or not b:
        return 0.0
    inter = a & b
    return len(inter) / len(a | b) if inter else 0.0


def duplicate_flags(offers: List[Dict[str, Any]]) -> Dict[str, bool]:
    """True en los segundos y siguientes de cada grupo de reposts.

    Pasa 1: título + empresa exactos (comportamiento original).
    Pasa 2: títulos casi idénticos entre portales o con numeración de ref
    distinta ('7-21 X' vs 'X', '18.902 X' vs 'X'): jaccard>=0.80 sin números,
    misma empresa (o ambas vacías); queda flaggeada la de score menor.
    """
    flags: Dict[str, bool] = {}
    groups: Dict[str, List[Dict[str, Any]]] = {}
    for offer in offers:
        oid = str(offer.get("offer_id"))
        flags[oid] = False
        title = se.normalize(offer.get("title", ""))
        company = se.normalize(offer.get("company", ""))
        key = f"{title}|{company if company not in ('n d', 'nd', '') else ''}"
        groups.setdefault(key, []).append(offer)
    for group in groups.values():
        if len(group) < 2:
            continue
        ordered = sorted(group, key=lambda o: -int(o.get("score_legacy", 0) or 0))
        for offer in ordered[1:]:
            flags[str(offer.get("offer_id"))] = True

    # Pasa 2: casi-variantes.
    pending = [(str(o.get("offer_id")), o) for o in offers if not flags[str(o.get("offer_id"))]]
    tokens = {oid: _title_tokens(o.get("title", "")) for oid, o in pending}
    comp = {oid: se.normalize(o.get("company", "")) for oid, o in pending}
    score = {oid: int(o.get("score_legacy", 0) or 0) for oid, o in pending}
    order_oids = [oid for oid, _ in pending]
    for i, oid_a in enumerate(order_oids):
        if flags[oid_a]:
            continue
        for oid_b in order_oids[i + 1:]:
            if flags[oid_b]:
                continue
            tok_a, tok_b = tokens.get(oid_a) or set(), tokens.get(oid_b) or set()
            if not tok_a or not tok_b:
                continue
            if _jaccard(tok_a, tok_b) < 0.80:
                continue
            ca, cb = comp.get(oid_a, ""), comp.get(oid_b, "")
            if ca and cb and ca != cb:
                continue
            # el repost es el de score menor; empate: flaggea b (orden estable)
            loser = oid_b if score.get(oid_b, 0) <= score.get(oid_a, 0) else oid_a
            flags[loser] = True
    return flags


def clamp(value: float, low: float = 0.0, high: float = 100.0) -> float:
    return max(low, min(high, value))


def score_offer(
    offer: Dict[str, Any],
    matcher: se.ConceptMatcher,
    profile_ids: set,
    known_expired: set,
    duplicates: Dict[str, bool],
    proxy_labels: Dict[str, Any],
) -> Dict[str, Any]:
    title = str(offer.get("title", ""))
    text = str(offer.get("_full", ""))
    title_concepts = matcher.positives(title)
    all_concepts = matcher.positives(text)
    negatives = matcher.negatives(text)

    core_hits = [c for c in all_concepts if c["id"] in profile_ids and c["id"] in CORE_IDS]
    title_hits = [c for c in title_concepts if c["id"] in profile_ids]
    missing_title = [
        c for c in title_concepts
        if c["id"] not in profile_ids and not c["negative"]
    ]
    skill_hits = [
        c for c in all_concepts
        if c["id"] in profile_ids and c["kind"] in ("skill", "cert")
    ]
    desc_hits = [c for c in all_concepts if c["id"] in profile_ids]
    missing = [c for c in all_concepts if c["id"] not in profile_ids]

    core_cov = min(1.0, len(core_hits) / 4.0)
    title_cov = min(1.0, len(title_hits) / 3.0)
    skill_cov = min(1.0, len(skill_hits) / 5.0)
    desc_cov = min(1.0, len(desc_hits) / 7.0)
    loc = location_score(str(offer.get("location", "")), title)
    fresh = freshness_score(offer.get("published"))
    comp = company_score(str(offer.get("company", "")), text)

    base = 100.0 * (
        0.40 * core_cov
        + 0.25 * title_cov
        + 0.15 * skill_cov
        + 0.10 * desc_cov
        + 0.05 * loc
        + 0.03 * fresh
        + 0.02 * comp
    )

    expired = str(offer.get("offer_key", "")) in known_expired
    duplicate = duplicates.get(str(offer.get("offer_id")), False)
    junior = any(c["id"] in ("junior", "trainee", "intern") for c in negatives)
    no_description = str(offer.get("fetch_status", "")) != "ok"

    penalty = 0.0
    penalty += 8.0 * min(3, len(negatives))
    title_gap_penalty = sum(HARD_TITLE_PENALTY.get(c["id"], 4.0) for c in missing_title)
    penalty += min(24.0, title_gap_penalty)
    if junior:
        penalty += 25.0
    if expired:
        penalty += 100.0
    if duplicate:
        penalty += 15.0
    if no_description:
        penalty += 30.0
    score_v2 = clamp(base - penalty)

    hard = expired or duplicate or junior or no_description
    domain_gap = any(c["id"] in DOMAIN_GAPS for c in missing_title)
    risk = "alto" if (hard or len(negatives) >= 2 or score_v2 < 45) else (
        "medio" if (negatives or domain_gap or score_v2 < 65) else "bajo"
    )
    proxy = proxy_labels.get(str(offer.get("offer_id")), {})
    proxy_label = proxy.get("proxy_label", "unlabeled")
    eligible = score_v2 >= 70 and proxy_label == "positive" and not hard
    if eligible:
        action = "priorizar"
    elif score_v2 >= 50 and not hard:
        action = "revisar"
    else:
        action = "descartar"

    reasons = []
    if core_hits:
        reasons.append(f"core {len(core_hits)}/{min(4, len(CORE_IDS))}")
    if title_hits:
        reasons.append("titulo: " + ", ".join(c["label"] for c in title_hits[:3]))
    if missing_title:
        reasons.append("brecha titulo: " + ", ".join(c["label"] for c in missing_title[:3]))
    if skill_hits:
        reasons.append("skills: " + ", ".join(c["label"] for c in skill_hits[:3]))
    if fresh >= 0.85:
        reasons.append("publicacion reciente")
    if loc >= 0.95:
        reasons.append("Santiago/remoto")
    if comp >= 0.95:
        reasons.append("cliente/empresa conocida")
    if negatives:
        reasons.append("brecha: " + ", ".join(c["label"] for c in negatives))
    if not reasons:
        reasons.append("sin coincidencias fuertes")

    return {
        "offer_id": offer.get("offer_id"),
        "offer_key": offer.get("offer_key"),
        "title": title,
        "company": offer.get("company", ""),
        "location": offer.get("location", ""),
        "cluster_id": offer.get("cluster_id", ""),
        "cluster_name": offer.get("cluster_name", ""),
        "url": offer.get("url", ""),
        "apply_url": offer.get("apply_url", ""),
        "published": offer.get("published", ""),
        "score_v2": round(score_v2, 1),
        "score_legacy": int(offer.get("score_legacy", 0) or 0),
        "market_fit": proxy.get("market_fit", round(score_v2 / 100.0, 3)),
        "proxy_label": proxy_label,
        "eligible": eligible,
        "action": action,
        "risk": risk,
        "matched": [c["id"] for c in desc_hits],
        "missing": [c["id"] for c in missing[:10]],
        "negative_claims": [c["id"] for c in negatives],
        "title_gap": [c["id"] for c in missing_title],
        "reasons": reasons,
        "flags": {
            "expired": expired,
            "duplicate": duplicate,
            "seniority_mismatch": junior,
            "title_gap": [c["id"] for c in missing_title],
            "no_description": no_description,
            "salary_published": bool(str(offer.get("salary_text", "")).strip()),
        },
        "breakdown": {
            "core": round(core_cov, 3),
            "title": round(title_cov, 3),
            "skills": round(skill_cov, 3),
            "description": round(desc_cov, 3),
            "location": round(loc, 3),
            "freshness": round(fresh, 3),
            "company": round(comp, 3),
            "penalty": round(penalty, 1),
            "title_gap_penalty": round(min(24.0, title_gap_penalty), 1),
            "base": round(base, 1),
        },
    }


def load_proxy_labels() -> Dict[str, Any]:
    if not PROXY_PATH.exists():
        return {}
    try:
        payload = json.loads(PROXY_PATH.read_text(encoding="utf-8"))
        return payload.get("labels", {})
    except (ValueError, OSError):
        return {}


def main(argv: Optional[List[str]] = None) -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    if argv is None:
        argv = sys.argv[1:]
    if argv and argv[0] == "rank":
        argv = argv[1:]

    parser = argparse.ArgumentParser(description="Ranking v2 de ofertas")
    parser.add_argument("--top", type=int, default=30)
    parser.add_argument("--min-score", type=float, default=0.0)
    parser.add_argument("--include-expired", action="store_true")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)

    corpus = load_corpus()
    if not corpus:
        print(f"ERROR: corpus vacio en {CORPUS_DIR}. Ejecuta build_corpus.py.", file=sys.stderr)
        return 2

    profile = json.loads(PROFILE_PATH.read_text(encoding="utf-8"))
    matcher = se.ConceptMatcher()
    profile_ids = {c["id"] for c in matcher.positives(se.profile_text(profile))}
    known_expired = set()
    if KNOWN_EXPIRED_PATH.exists():
        try:
            known_expired = {str(x) for x in json.loads(KNOWN_EXPIRED_PATH.read_text(encoding="utf-8")).get("ids", [])}
        except (ValueError, OSError):
            pass
    duplicates = duplicate_flags(corpus)
    proxy_labels = load_proxy_labels()

    rows = [
        score_offer(o, matcher, profile_ids, known_expired, duplicates, proxy_labels)
        for o in corpus
    ]
    if not args.include_expired:
        rows = [r for r in rows if not r["flags"]["expired"]]
    rows = [r for r in rows if r["score_v2"] >= args.min_score]
    rows.sort(key=lambda r: (-r["score_v2"], -r["score_legacy"], str(r["offer_id"])))
    for index, row in enumerate(rows, 1):
        row["rank"] = index

    counts = {
        "offers": len(rows),
        "priorizar": sum(1 for r in rows if r["action"] == "priorizar"),
        "revisar": sum(1 for r in rows if r["action"] == "revisar"),
        "descartar": sum(1 for r in rows if r["action"] == "descartar"),
        "eligible": sum(1 for r in rows if r["eligible"]),
        "risk_alto": sum(1 for r in rows if r["risk"] == "alto"),
    }
    queue = {
        "generated_at": now_iso(),
        "engine": "v2",
        "method": "cobertura core/titulo/skills/descripcion + ubicacion/frescura/empresa - penalizaciones",
        "profile": {
            "headline": profile.get("headline", ""),
            "location": profile.get("location", {}),
            "core_ids": sorted(profile_ids & CORE_IDS),
        },
        "counts": counts,
        "offers": rows,
    }
    QUEUE_PATH.write_text(json.dumps(queue, ensure_ascii=False, indent=2), encoding="utf-8")

    EVAL_DIR.mkdir(parents=True, exist_ok=True)
    with (EVAL_DIR / "ranking_v2.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "rank", "offer_id", "title", "company", "location", "cluster_name",
                "score_v2", "score_legacy", "market_fit", "proxy_label", "eligible",
                "action", "risk", "matched", "missing", "negative_claims",
                "title_gap", "url",
            ],
            extrasaction="ignore",
        )
        writer.writeheader()
        for row in rows:
            writer.writerow({
                **row,
                "matched": ";".join(row["matched"]),
                "missing": ";".join(row["missing"]),
                "negative_claims": ";".join(row["negative_claims"]),
                "title_gap": ";".join(row["title_gap"]),
            })

    if args.json:
        print(json.dumps({"counts": counts, "offers": rows[: args.top]}, ensure_ascii=False, indent=2))
        return 0

    print(f"Ranking v2: {len(rows)} ofertas | priorizar={counts['priorizar']} revisar={counts['revisar']} descartar={counts['descartar']} | eligible={counts['eligible']}")
    print("")
    print(f"{'#':>3}  {'Score':>5}  {'Legacy':>6}  {'Riesgo':<6}  {'Proxy':<10}  Titulo")
    for row in rows[: args.top]:
        print(
            f"{row['rank']:>3}  {row['score_v2']:>5.1f}  {row['score_legacy']:>6}  "
            f"{row['risk']:<6}  {row['proxy_label']:<10}  {row['title'][:65]}"
        )
    print("")
    print(f"Cola: {QUEUE_PATH}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
