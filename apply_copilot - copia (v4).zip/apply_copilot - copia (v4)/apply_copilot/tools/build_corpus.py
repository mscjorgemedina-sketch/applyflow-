#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Construye el corpus de ofertas de ChileTrabajos.

Lee data/jobs_database.json, selecciona ofertas por score y descarga la
descripcion publica (nunca el formulario de postulacion). Escribe un .md por
oferta en data/corpus/offers/.
"""
from __future__ import annotations

import argparse
import datetime as dt
import html
import json
import random
import re
import socket
import sys
import time
import urllib.error
import urllib.request
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Optional

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
DB_PATH = DATA / "jobs_database.json"
CORPUS_DIR = DATA / "corpus" / "offers"
KNOWN_EXPIRED = DATA / "eval" / "known_expired.json"

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
)


def now_iso() -> str:
    return dt.datetime.now().replace(microsecond=0).isoformat()


def http_get(url: str, timeout: int = 25) -> str:
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": USER_AGENT,
            "Accept": "text/html,application/xhtml+xml",
            "Accept-Language": "es-CL,es;q=0.9,en;q=0.8",
            "Accept-Encoding": "identity",
            "Connection": "close",
        },
    )
    with urllib.request.urlopen(req, timeout=timeout) as response:
        raw = response.read()
        charset = response.headers.get_content_charset() or "utf-8"
    try:
        return raw.decode(charset, "replace")
    except LookupError:
        return raw.decode("utf-8", "replace")


def strip_html(fragment: str) -> str:
    if not fragment:
        return ""
    text = re.sub(r"(?is)<(script|style)\b.*?</\1>", " ", fragment)
    text = re.sub(r"(?i)<br\s*/?>", "\n", text)
    text = re.sub(r"(?i)</(p|div|li|h[1-6]|tr)>", "\n", text)
    text = re.sub(r"(?s)<[^>]+>", " ", text)
    text = html.unescape(text).replace("\xa0", " ")
    lines: List[str] = []
    for line in text.splitlines():
        line = re.sub(r"[ \t]+", " ", line).strip()
        if line:
            lines.append(line)
        elif lines and lines[-1] != "":
            lines.append("")
    return "\n".join(lines).strip()


def first_text(pattern: str, fragment: str) -> str:
    match = re.search(pattern, fragment, re.S | re.I)
    return strip_html(match.group(1)) if match else ""


def parse_offer(page: str, offer: Dict[str, Any]) -> Dict[str, Any]:
    title = first_text(
        r'<h1[^>]*class="[^"]*titulo-detalle[^"]*"[^>]*>(.*?)</h1>', page
    )
    title = title or str(offer.get("titulo", "")).strip()

    company = ""
    location = ""
    meta = re.search(
        r'<h3[^>]*class="[^"]*\bmeta\b[^"]*"[^>]*>(.*?)</h3>', page, re.S | re.I
    )
    if meta:
        anchors = re.findall(r"<a\b[^>]*>(.*?)</a>", meta.group(1), re.S | re.I)
        clean = [strip_html(a) for a in anchors]
        clean = [a for a in clean if a]
        if clean:
            company = clean[0]
        if len(clean) > 1:
            location = clean[1]

    published = first_text(
        r'<h3[^>]*class="[^"]*\bmeta\b[^"]*mt-1[^"]*"[^>]*>.*?</i>\s*([^<]+)</h3>',
        page,
    )

    start = page.find("Descripci&oacute;n oferta de trabajo")
    if start < 0:
        start = page.find("Descripción oferta de trabajo")
    description = ""
    if start >= 0:
        end = page.find('<div class="botones-desc mt-3', start)
        block = page[start : end if end > start else start + 12000]
        block = re.sub(
            r'(?is)<div class="botones-desc d-block">.*?</div>', " ", block
        )
        description = strip_html(block)
        description = re.sub(
            r"(?i)^descripci[oó]n oferta de trabajo\s*", "", description
        ).strip()

    tags: List[str] = []
    tag_block = re.search(
        r'<div class="botones-desc mt-3[^"]*">(.*?)</div>', page, re.S | re.I
    )
    if tag_block:
        tags = [
            strip_html(t).strip()
            for t in re.findall(r'fa-tag"></i>\s*([^<]+)', tag_block.group(1), re.I)
        ]
        tags = [t for t in tags if t]

    salary_lines = []
    for line in description.splitlines():
        norm_line = line.lower()
        salary_word = any(k in norm_line for k in ("renta", "sueldo", "remuneraci", "salario"))
        money_symbol = "$" in norm_line or "clp" in norm_line
        project_context = any(
            k in norm_line
            for k in ("proyecto", "presupuesto", "inversion", "us$", "millones de dolares", "monto")
        )
        if (project_context and not salary_word) or not (salary_word or money_symbol):
            continue
        salary_lines.append(line.strip())
    salary_text = " | ".join(dict.fromkeys(salary_lines))[:500]

    return {
        "title": title,
        "company": company or str(offer.get("empresa", "") or "N/D"),
        "location": location or str(offer.get("ubicacion", "") or ""),
        "published": published or str(offer.get("fecha_publicacion", "") or ""),
        "description": description,
        "tags": tags,
        "salary_text": salary_text,
    }


def offer_key(url: str, fallback: str) -> str:
    numbers = re.findall(r"\d{6,}", str(url))
    if numbers:
        return numbers[-1]
    return str(fallback)


def apply_url(url: str) -> str:
    if "/trabajo/postular/" in url:
        return url
    numbers = re.findall(r"\d{6,}", url)
    if numbers:
        return f"https://www.chiletrabajos.cl/trabajo/postular/{numbers[-1]}"
    return ""


def yaml_value(value: Any) -> str:
    if isinstance(value, (list, dict)):
        return json.dumps(value, ensure_ascii=False)
    return json.dumps(str(value), ensure_ascii=False)


def write_markdown(
    path: Path,
    offer: Dict[str, Any],
    parsed: Dict[str, Any],
    status: str,
    error: str = "",
) -> None:
    meta = {
        "offer_id": offer.get("id", ""),
        "offer_key": offer_key(str(offer.get("url", "")), str(offer.get("id", ""))),
        "portal": offer.get("portal", ""),
        "title": parsed.get("title") or offer.get("titulo", ""),
        "company": parsed.get("company") or offer.get("empresa", ""),
        "location": parsed.get("location") or offer.get("ubicacion", ""),
        "published": parsed.get("published") or offer.get("fecha_publicacion", ""),
        "score_legacy": int(offer.get("score", 0) or 0),
        "cluster_id": offer.get("cluster_id", ""),
        "cluster_name": offer.get("cluster_name", ""),
        "url": offer.get("url", ""),
        "apply_url": apply_url(str(offer.get("url", ""))),
        "tags": parsed.get("tags", []),
        "salary_text": parsed.get("salary_text", ""),
        "fetched_at": now_iso(),
        "fetch_status": status,
        "error": error,
    }
    lines = ["---"]
    for key, value in meta.items():
        lines.append(f"{key}: {yaml_value(value)}")
    lines.append("---")
    lines.append("")
    lines.append(f"# {meta['title']}")
    lines.append("")
    lines.append(f"- Empresa: {meta['company']}")
    lines.append(f"- Ubicacion: {meta['location']}")
    lines.append(f"- Publicado: {meta['published']}")
    lines.append(f"- Score legacy: {meta['score_legacy']}")
    lines.append(f"- Cluster: {meta['cluster_name']}")
    lines.append(f"- Tags: {', '.join(meta['tags']) if meta['tags'] else 'N/D'}")
    lines.append("")
    lines.append("## Descripcion")
    lines.append("")
    lines.append(parsed.get("description") or "(sin descripcion disponible)")
    lines.append("")
    if meta["salary_text"]:
        lines.append("## Renta publicada")
        lines.append("")
        lines.append(meta["salary_text"])
        lines.append("")
    path.write_text("\n".join(lines), encoding="utf-8")


def select_offers(rows: List[Dict[str, Any]], portal: str, min_score: int, max_n: int) -> List[Dict[str, Any]]:
    portal_key = portal.lower()
    candidates = [
        row
        for row in rows
        if portal_key in str(row.get("portal", "")).lower()
        and int(row.get("score", 0) or 0) >= min_score
        and str(row.get("estado", "PENDING")).upper() == "PENDING"
    ]
    by_key: Dict[str, Dict[str, Any]] = {}
    for row in candidates:
        key = offer_key(str(row.get("url", "")), str(row.get("id", "")))
        current = by_key.get(key)
        if current is None or int(row.get("score", 0) or 0) > int(current.get("score", 0) or 0):
            by_key[key] = row
    selected = list(by_key.values())
    selected.sort(key=lambda r: (-int(r.get("score", 0) or 0), str(r.get("fecha_deteccion", ""))))
    return selected[:max_n]


def main(argv: Optional[List[str]] = None) -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    parser = argparse.ArgumentParser(description="Corpus de ofertas ChileTrabajos")
    parser.add_argument("--portal", default="chiletrabajos")
    parser.add_argument("--min-score", type=int, default=70)
    parser.add_argument("--max", type=int, default=160)
    parser.add_argument("--delay", type=float, default=0.8)
    parser.add_argument("--timeout", type=int, default=25)
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--include-known-expired", action="store_true")
    args = parser.parse_args(argv)

    if not DB_PATH.exists():
        print(f"ERROR: no existe {DB_PATH}", file=sys.stderr)
        return 2

    db = json.loads(DB_PATH.read_text(encoding="utf-8"))
    rows = list(db.values()) if isinstance(db, dict) else list(db)
    selected = select_offers(rows, args.portal, args.min_score, args.max)

    known_expired: set = set()
    if KNOWN_EXPIRED.exists():
        try:
            payload = json.loads(KNOWN_EXPIRED.read_text(encoding="utf-8"))
            known_expired = set(str(x) for x in payload.get("ids", []))
        except (ValueError, OSError):
            known_expired = set()

    if args.dry_run:
        print(f"Seleccionadas: {len(selected)} (unicas por oferta)")
        for row in selected:
            print(
                f"{row.get('id')}  {row.get('score')}  "
                f"{offer_key(str(row.get('url', '')), str(row.get('id', '')))}  "
                f"{str(row.get('titulo', ''))[:65]}"
            )
        return 0

    CORPUS_DIR.mkdir(parents=True, exist_ok=True)
    fetched = skipped = failed = 0

    for index, offer in enumerate(selected, 1):
        offer_id = str(offer.get("id", ""))
        key = offer_key(str(offer.get("url", "")), offer_id)
        url = str(offer.get("url", ""))
        target = CORPUS_DIR / f"{offer_id}.md"
        if target.exists() and not args.force:
            skipped += 1
            print(f"[{index}/{len(selected)}] SKIP {offer_id} (ya existe)")
            continue
        if not args.include_known_expired and key in known_expired:
            skipped += 1
            print(f"[{index}/{len(selected)}] SKIP {offer_id} (expirada conocida {key})")
            continue
        try:
            page = http_get(url, timeout=args.timeout)
            parsed = parse_offer(page, offer)
            status = "ok" if parsed["description"] else "no_description"
            write_markdown(target, offer, parsed, status)
            fetched += 1
            print(
                f"[{index}/{len(selected)}] OK {offer_id} "
                f"({len(parsed['description'])} chars) {parsed['title'][:55]}"
            )
        except (urllib.error.HTTPError, urllib.error.URLError, socket.timeout, OSError) as exc:
            failed += 1
            parsed = {
                "title": offer.get("titulo", ""),
                "company": offer.get("empresa", ""),
                "location": offer.get("ubicacion", ""),
                "published": offer.get("fecha_publicacion", ""),
                "description": "",
                "tags": [],
                "salary_text": "",
            }
            write_markdown(target, offer, parsed, "error", str(exc)[:300])
            print(f"[{index}/{len(selected)}] FAIL {offer_id}: {exc}")
        if index < len(selected):
            time.sleep(max(0.0, args.delay + random.uniform(0.0, 0.4)))

    print("")
    print(f"Corpus: {fetched} descargadas, {skipped} omitidas, {failed} con error")
    print(f"Directorio: {CORPUS_DIR}")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
