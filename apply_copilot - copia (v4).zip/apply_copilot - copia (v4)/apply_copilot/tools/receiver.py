#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Apply Copilot — receiver local (Fase 1).

Recibe question_bundles, evidencia (capturas) y eventos desde la extensión de Chrome.
Solo biblioteca estándar. Escucha únicamente en loopback.

    python tools/receiver.py              # 127.0.0.1:8765
    curl http://127.0.0.1:8765/health     # {"ok":true,"service":"apply_copilot_receiver"}

Endpoints
    GET  /health
    GET  /api/next-id                     -> {"application_id": "app_YYYYMMDD_NNN"}
    GET  /api/context                     -> oferta preparada por apply_copilot.py (o {})
    GET  /api/approved/<id|latest>        -> approved_answers.json
    POST /api/bundle                      -> data/bundles/<id>_questions.json
    POST /api/evidence                    -> data/evidence/<id>/<paso>.png
    POST /api/event                       -> data/logs/<id>.jsonl

Seguridad (una página web cualquiera NO debe poder escribir en tu disco):
    * Host debe ser 127.0.0.1:<puerto> o localhost:<puerto>   (anti DNS-rebinding)
    * Si hay cabecera Origin, debe ser chrome-extension://...  (anti CSRF desde webs)
    * Sin CORS "*": solo se devuelve el origin de la extensión
    * IDs saneados (sin path traversal) y límite de tamaño del cuerpo
"""

from __future__ import annotations

import argparse
import base64
import binascii
import json
import logging
import re
import sys
import threading
import urllib.parse
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

sys.path.insert(0, str(Path(__file__).resolve().parent))
import ac_common as ac  # noqa: E402

log = logging.getLogger("apply_copilot.receiver")

MAX_BODY_BYTES = 32 * 1024 * 1024
MAX_EVENT_DETAIL_CHARS = 4000
LOOPBACK_HOSTS = {"127.0.0.1", "localhost"}
DATA_URL_RE = re.compile(r"^data:image/(png|jpeg|webp);base64,(.+)$", re.S)
STEP_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,39}$")
PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"
EXT_BY_MIME = {"png": "png", "jpeg": "jpg", "webp": "webp"}


def _offer_id_from_url(url: str) -> Optional[str]:
    """ID numérico de ChileTrabajos desde /trabajo/postular/<id> o desde el slug."""
    text = str(url or "")
    m = re.search(r"/trabajo/postular/(\d{4,})", text)
    if m:
        return m.group(1)
    m = re.search(r"-(\d{4,})(?:[/?#].*)?$", text)
    return m.group(1) if m else None


class ApiError(Exception):
    def __init__(self, status: int, code: str, message: str = ""):
        super().__init__(message or code)
        self.status, self.code, self.message = status, code, message or code


class ReceiverServer(ThreadingHTTPServer):
    daemon_threads = True
    # En Windows SO_REUSEADDR permitiría dos receivers en el mismo puerto; en Linux/macOS evita esperar el TIME_WAIT.
    allow_reuse_address = not sys.platform.startswith("win")

    def __init__(self, address: Tuple[str, int], paths: ac.Paths, max_body: int = MAX_BODY_BYTES):
        self.paths = paths.ensure()
        self.max_body = max_body
        self.lock = threading.Lock()
        super().__init__(address, Handler)
        port = self.server_address[1]
        self.allowed_hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}


class Handler(BaseHTTPRequestHandler):
    server: ReceiverServer
    server_version = "ApplyCopilotReceiver/1.0"
    protocol_version = "HTTP/1.1"

    # ------------------------------------------------------------------ plumbing
    def log_message(self, fmt: str, *args: Any) -> None:
        log.info("%s %s", self.address_string(), fmt % args)

    def _origin(self) -> Optional[str]:
        return self.headers.get("Origin")

    def _send(self, status: int, obj: Dict[str, Any]) -> None:
        body = json.dumps(obj, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        if self.close_connection:
            self.send_header("Connection", "close")
        origin = self._origin()
        if origin and origin.startswith("chrome-extension://"):
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
        self.end_headers()
        self.wfile.write(body)

    def _guard(self) -> None:
        host = (self.headers.get("Host") or "").lower()
        if host not in self.server.allowed_hosts:
            raise ApiError(403, "host_not_allowed", f"Host no permitido: {host!r}")
        origin = self._origin()
        if origin is not None and not origin.startswith("chrome-extension://"):
            raise ApiError(403, "origin_not_allowed", f"Origin no permitido: {origin!r}")

    def _read_json(self) -> Dict[str, Any]:
        length_h = self.headers.get("Content-Length")
        if length_h is None:
            self.close_connection = True
            raise ApiError(411, "length_required", "Falta Content-Length")
        try:
            length = int(length_h)
        except ValueError:
            self.close_connection = True
            raise ApiError(400, "bad_length", "Content-Length inválido")
        if length < 0 or length > self.server.max_body:
            self.close_connection = True  # no se lee el cuerpo
            raise ApiError(413, "payload_too_large", f"Máximo {self.server.max_body} bytes")
        raw = self.rfile.read(length)
        try:
            data = json.loads(raw.decode("utf-8-sig"))
        except (ValueError, UnicodeDecodeError) as e:
            raise ApiError(400, "invalid_json", f"JSON inválido: {e}")
        if not isinstance(data, dict):
            raise ApiError(400, "invalid_json", "Se esperaba un objeto JSON")
        return data

    def _dispatch(self, routes) -> None:
        try:
            self._guard()
            path = urllib.parse.urlsplit(self.path).path
            for pattern, fn in routes:
                m = pattern.fullmatch(path)
                if m:
                    status, obj = fn(self, *m.groups())
                    return self._send(status, obj)
            if self.command == "POST":
                length_h = self.headers.get("Content-Length")
                try:
                    length = int(length_h or 0)
                except ValueError:
                    length = 0
                if 0 < length <= self.server.max_body:
                    self.rfile.read(length)
            raise ApiError(404, "not_found", "Ruta no encontrada")
        except ApiError as e:
            if self.command == "POST":
                self.close_connection = True  # el cuerpo puede quedar sin leer: no reutilizar la conexión
            if e.status >= 500:
                log.error("%s: %s", e.code, e.message)
            else:
                log.warning("%s %s -> %s %s", self.command, self.path, e.status, e.code)
            self._send(e.status, {"ok": False, "error": e.code, "message": e.message})
        except Exception:  # error inesperado: se loguea completo, al cliente solo un código
            log.exception("Error interno en %s %s", self.command, self.path)
            self._send(500, {"ok": False, "error": "internal_error"})

    def do_OPTIONS(self) -> None:
        try:
            self._guard()
        except ApiError as e:
            return self._send(e.status, {"ok": False, "error": e.code})
        self.send_response(204)
        origin = self._origin()
        if origin and origin.startswith("chrome-extension://"):
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Max-Age", "600")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self) -> None:
        self._dispatch(GET_ROUTES)

    def do_POST(self) -> None:
        self._dispatch(POST_ROUTES)

    # ------------------------------------------------------------------ GET
    def r_health(self) -> Tuple[int, Dict[str, Any]]:
        return 200, {"ok": True, "service": ac.SERVICE_NAME, "version": "v5"}

    def r_next_id(self) -> Tuple[int, Dict[str, Any]]:
        today = datetime.now().strftime("%Y%m%d")
        counter = self.server.paths.logs / f".ids_{today}"
        with self.server.lock:
            try:
                n = int(counter.read_text(encoding="utf-8").strip() or 0)
            except (OSError, ValueError):
                n = 0
            n += 1
            ac.atomic_write_text(counter, str(n))
        return 200, {"ok": True, "application_id": f"app_{today}_{n:03d}"}

    def r_context(self) -> Tuple[int, Dict[str, Any]]:
        p = self.server.paths.current_offer
        if not p.exists():
            return 200, {"ok": True, "offer": {}}
        try:
            return 200, {"ok": True, "offer": ac.read_json(p)}
        except (ValueError, OSError):
            return 200, {"ok": True, "offer": {}}

    def r_approved(self, ident: str) -> Tuple[int, Dict[str, Any]]:
        answers = self.server.paths.answers
        if ident == "latest":
            path = ac.latest_file(answers, "*_approved.json")
        else:
            app_id = ac.safe_id(ident)
            if not app_id:
                raise ApiError(400, "invalid_id", "application_id inválido")
            path = answers / f"{app_id}_approved.json"
        if not path or not path.exists():
            raise ApiError(404, "approved_not_found", "No hay approved_answers para ese ID")
        try:
            return 200, {"ok": True, "approved": ac.read_json(path)}
        except (ValueError, OSError) as e:
            raise ApiError(500, "approved_unreadable", str(e))

    def r_prompt(self, ident: str) -> Tuple[int, Dict[str, Any]]:
        prompts = self.server.paths.prompts
        bundles = self.server.paths.bundles
        if ident == "latest":
            path = ac.latest_file(prompts, "*_qwen_prompt.md")
            if path:
                app_id = ac.app_id_from_name(path, "_qwen_prompt.md")
            else:
                bundle_path = ac.latest_file(bundles, "*_questions.json")
                if not bundle_path:
                    raise ApiError(404, "no_applications", "No hay formularios extraídos aún.")
                app_id = ac.app_id_from_name(bundle_path, "_questions.json")
        else:
            app_id = ac.safe_id(ident)
            if not app_id:
                raise ApiError(400, "invalid_id", "application_id inválido")

        path = prompts / f"{app_id}_qwen_prompt.md"
        if not path.exists():
            bundle_path = bundles / f"{app_id}_questions.json"
            if not bundle_path.exists():
                raise ApiError(404, "prompt_not_found", f"No se encontró prompt ni preguntas para {app_id}")
            try:
                import make_qwen_prompt  # noqa: E402
                b_data = ac.read_json(bundle_path)
                prof = ac.read_json(self.server.paths.profile) if self.server.paths.profile.exists() else {}
                prompt_text, _ = make_qwen_prompt.build_prompt(b_data, prof)
                ac.atomic_write_text(path, prompt_text)
            except Exception as e:
                raise ApiError(500, "prompt_generation_failed", f"No se pudo generar el prompt: {e}")

        try:
            content = path.read_text(encoding="utf-8")
        except OSError as e:
            raise ApiError(500, "prompt_unreadable", str(e))

        save_target = (self.server.paths.answers / f"{app_id}_answers_raw.json").resolve()
        suffix = (
            f"\n\n---\n"
            f"## INSTRUCCIÓN ADICIONAL PARA GUARDAR LA RESPUESTA EN CONSOLA\n"
            f"Si deseas guardar esta respuesta directamente desde PowerShell tras copiarla, ejecuta:\n"
            f"```powershell\n"
            f"Get-Clipboard | Set-Content -Path \"{save_target}\" -Encoding UTF8\n"
            f"```\n"
            f"O en la extensión Apply Copilot, pulsa directamente el botón '💾 Guardar respuesta desde portapapeles'.\n"
            f"---\n"
        )
        full_prompt = content + suffix
        return 200, {
            "ok": True,
            "application_id": app_id,
            "prompt": full_prompt,
            "path": self.server.paths.rel(path),
            "save_target": str(save_target),
            "chars": len(full_prompt),
        }

    def r_site_answers(self) -> Tuple[int, Dict[str, Any]]:
        qs = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
        raw_url = (qs.get("url") or [""])[0]
        path = self.server.paths.data / "site_answers.json"
        if not path.exists():
            raise ApiError(404, "no_site_answers", "No hay site_answers.json todavía")
        try:
            db = ac.read_json(path)
        except (ValueError, OSError) as e:
            raise ApiError(500, "site_answers_unreadable", str(e))
        sites = db.get("sites") or {}
        host = urllib.parse.urlsplit(raw_url).netloc.lower() if raw_url else ""
        entry = sites.get(host)
        if entry is None:
            for key, val in sites.items():
                if key and key.lower() in raw_url.lower():
                    entry = val
                    break
        if entry is None and raw_url.lower().startswith("file:"):
            entry = sites.get("sandbox")
        if entry is None:
            hostname = urllib.parse.urlsplit(raw_url).hostname or ""
            if hostname in ("127.0.0.1", "localhost"):
                entry = sites.get("sandbox")
        if not entry:
            raise ApiError(404, "no_answers_for_site", f"Sin respuestas guardadas para {host or 'este sitio'}")
        offer_id = _offer_id_from_url(raw_url)
        site = self._merge_offer_answers(entry, offer_id)
        return 200, {"ok": True, "site": site, "offer_id": offer_id}

    def _merge_offer_answers(self, entry: Dict[str, Any], offer_id: Optional[str]) -> Dict[str, Any]:
        """Carta y sueldo específicos de la oferta, sin tocar el resto de respuestas base."""
        if not offer_id:
            return entry
        path = self.server.paths.data / "offer_answers.json"
        try:
            db = ac.read_json(path) if path.exists() else {}
        except (ValueError, OSError):
            db = {}
        overrides = db.get(str(offer_id)) if isinstance(db, dict) else None
        if not isinstance(overrides, dict):
            return entry

        site = json.loads(json.dumps(entry))  # copia profunda
        fields = site.setdefault("fields", [])

        letter = str(overrides.get("app_letter") or "").strip()
        if letter:
            replaced = False
            for field in fields:
                matches = [str(m).lower() for m in (field.get("match") or [])]
                if any(m == "app_letter" or "carta" in m or "presentacion" in m or "motivacion" in m
                       for m in matches):
                    field["value"] = letter
                    replaced = True
                    break
            if not replaced:
                fields.insert(0, {"match": ["app_letter", "carta", "presentacion", "motivacion"],
                                  "value": letter})

        salary_display = str(overrides.get("salary_display") or "").strip()
        if salary_display:
            for field in fields:
                matches = [str(m).lower() for m in (field.get("match") or [])]
                if any(term in m for m in matches
                       for term in ("renta", "sueldo", "salario", "pretension", "salary")):
                    field["value"] = salary_display
                    break
            else:
                fields.append({"match": ["pretension de renta", "pretension", "renta",
                                         "sueldo", "salario", "salary"],
                               "exclude": ["actual", "empresa", "compania"],
                               "value": salary_display})
            site["allow_sensitive"] = True

        site["offer_id"] = offer_id
        site["offer_title"] = str(overrides.get("title") or "")
        return site

    def r_run_state(self) -> Tuple[int, Dict[str, Any]]:
        path = self.server.paths.data / "current_run.json"
        try:
            state = ac.read_json(path) if path.exists() else {}
        except (ValueError, OSError):
            state = {}
        if not isinstance(state, dict):
            state = {}
        return 200, {"ok": True, **state}

    def r_fill_registry(self) -> Tuple[int, Dict[str, Any]]:
        """GET /api/fill-registry — registro de ofertas ya rellenadas."""
        path = self.server.paths.data / "fill_registry.json"
        try:
            reg = ac.read_json(path) if path.exists() else {}
        except (ValueError, OSError):
            reg = {}
        if not isinstance(reg, dict):
            reg = {}
        filled = {
            oid: val
            for oid, val in reg.items()
            if isinstance(val, dict) and val.get("status") == "filled"
        }
        return 200, {
            "ok": True,
            "total_filled": len(filled),
            "ids": list(filled.keys()),
            "filled": filled,
        }

    # ------------------------------------------------------------------ POST
    def r_fill_report(self) -> Tuple[int, Dict[str, Any]]:
        body = self._read_json()
        offer_id = str(body.get("offer_id") or "").strip()
        status = str(body.get("status") or "").strip()
        if not re.fullmatch(r"\d{4,}", offer_id):
            raise ApiError(400, "invalid_offer_id", "offer_id inválido")
        if status not in ("filled", "no_form", "expired", "login", "error"):
            raise ApiError(400, "invalid_status", "status inválido")

        run_id = str(body.get("run_id") or "").strip()
        if not run_id:
            try:
                state = ac.read_json(self.server.paths.data / "current_run.json")
                run_id = str(state.get("run_id") or "") if isinstance(state, dict) else ""
            except (ValueError, OSError):
                run_id = ""

        report = {
            "ts": ac.now_iso(),
            "run_id": run_id,
            "offer_id": offer_id,
            "status": status,
            "filled": int(body.get("filled") or 0),
            "skipped": body.get("skipped") if isinstance(body.get("skipped"), list) else [],
            "url": str(body.get("url") or ""),
            "title": str(body.get("title") or ""),
        }
        path = self.server.paths.data / "fill_reports.jsonl"
        with self.server.lock:
            with open(path, "a", encoding="utf-8") as f:
                f.write(json.dumps(report, ensure_ascii=False) + "\n")
            if status == "filled":
                reg_path = self.server.paths.data / "fill_registry.json"
                try:
                    reg = ac.read_json(reg_path) if reg_path.exists() else {}
                except (ValueError, OSError):
                    reg = {}
                if not isinstance(reg, dict):
                    reg = {}
                reg[offer_id] = {"status": status, "ts": report["ts"],
                                 "title": report["title"], "run_id": run_id}
                ac.atomic_write_json(reg_path, reg)

        log.info("fill-report %s %s (%d campos)", offer_id, status, report["filled"])
        return 200, {"ok": True, "run_id": run_id, "offer_id": offer_id, "status": status}

    def r_bundle(self) -> Tuple[int, Dict[str, Any]]:
        bundle = self._read_json()
        app_id = ac.safe_id(bundle.get("application_id"))
        if not app_id:
            raise ApiError(400, "invalid_application_id", "application_id ausente o inválido")
        fields = bundle.get("fields")
        if not isinstance(fields, list) or not all(isinstance(f, dict) and f.get("field_id") for f in fields):
            raise ApiError(400, "invalid_bundle", "fields debe ser una lista de objetos con field_id")
        path = self.server.paths.bundles / f"{app_id}_questions.json"
        ac.atomic_write_json(path, bundle)
        log.info("bundle guardado: %s (%d campos)", path.name, len(fields))
        return 200, {"ok": True, "application_id": app_id,
                     "path": self.server.paths.rel(path), "fields": len(fields)}

    def r_raw_answers(self) -> Tuple[int, Dict[str, Any]]:
        body = self._read_json()
        raw_text = body.get("text")
        if not raw_text or not isinstance(raw_text, str) or not raw_text.strip():
            raise ApiError(400, "empty_text", "El texto de la respuesta está vacío.")

        app_id_raw = body.get("application_id")
        if not app_id_raw or app_id_raw == "latest":
            latest_b = ac.latest_file(self.server.paths.bundles, "*_questions.json")
            if not latest_b:
                raise ApiError(404, "no_application", "No se encontró ninguna postulación previa.")
            app_id = ac.app_id_from_name(latest_b, "_questions.json")
        else:
            app_id = ac.safe_id(app_id_raw)
            if not app_id:
                raise ApiError(400, "invalid_application_id", "application_id inválido")

        target = self.server.paths.answers / f"{app_id}_answers_raw.json"
        ac.atomic_write_text(target, raw_text.strip())
        log.info("raw answers guardado: %s (%d caracteres)", target.name, len(raw_text))

        event_line = json.dumps({"ts": ac.now_iso(), "event": "raw_answers_saved", "detail": {"chars": len(raw_text), "path": self.server.paths.rel(target)}}, ensure_ascii=False)
        log_path = self.server.paths.logs / f"{app_id}.jsonl"
        with self.server.lock:
            with open(log_path, "a", encoding="utf-8") as f:
                f.write(event_line + "\n")

        return 200, {
            "ok": True,
            "application_id": app_id,
            "path": self.server.paths.rel(target),
            "chars": len(raw_text),
        }

    def r_validate(self) -> Tuple[int, Dict[str, Any]]:
        body = self._read_json()
        app_id_raw = body.get("application_id") or "latest"
        if app_id_raw == "latest":
            bundle_path = ac.latest_file(self.server.paths.bundles, "*_questions.json")
            if not bundle_path:
                raise ApiError(404, "no_bundle", "No hay formularios extraídos para validar.")
            app_id = ac.app_id_from_name(bundle_path, "_questions.json")
        else:
            app_id = ac.safe_id(app_id_raw)
            if not app_id:
                raise ApiError(400, "invalid_application_id", "application_id inválido")
            bundle_path = self.server.paths.bundles / f"{app_id}_questions.json"

        answers_path = self.server.paths.answers / f"{app_id}_answers_raw.json"
        if not bundle_path.exists():
            raise ApiError(404, "bundle_not_found", f"No existe el bundle para {app_id}")
        if not answers_path.exists():
            raise ApiError(404, "answers_not_found", f"No existe la respuesta raw para {app_id}")

        try:
            import validate_answers  # noqa: E402
            bundle = ac.read_json(bundle_path)
            raw_text = answers_path.read_text(encoding="utf-8")
            raw = validate_answers.extract_json(raw_text)
            profile = ac.read_json(self.server.paths.profile) if self.server.paths.profile.exists() else {}
            approved = validate_answers.build_approved(bundle, raw, profile)
        except Exception as e:
            raise ApiError(400, "validation_failed", f"No se pudo validar la respuesta: {e}")

        out = self.server.paths.answers / f"{approved['application_id']}_approved.json"
        ac.atomic_write_json(out, approved)
        summary = approved.get("summary") or {}
        preview = [
            {
                "field_id": f.get("field_id"),
                "label": f.get("label") or f.get("question") or f.get("field_id"),
                "status": f.get("status"),
                "reason": f.get("reason", ""),
            }
            for f in approved.get("fields", [])
            if f.get("status") in {"REVIEW", "HUMAN"}
        ][:8]

        event_line = json.dumps({"ts": ac.now_iso(), "event": "answers_validated", "detail": {"path": self.server.paths.rel(out), "summary": summary}}, ensure_ascii=False)
        with self.server.lock:
            with open(self.server.paths.logs / f"{approved['application_id']}.jsonl", "a", encoding="utf-8") as f:
                f.write(event_line + "\n")

        return 200, {
            "ok": True,
            "application_id": approved["application_id"],
            "path": self.server.paths.rel(out),
            "summary": summary,
            "preview": preview,
            "approved": approved,
        }

    def r_qwen_trigger(self) -> Tuple[int, Dict[str, Any]]:
        self._read_json()
        qwen_root = self.server.paths.root.parent / "qwen_automa"
        trigger = qwen_root / "trigger" / "trigger.flag"
        if not (qwen_root / "src" / "agent.py").exists():
            raise ApiError(404, "qwen_automa_not_found", f"No encontré qwen_automa en {qwen_root}")
        try:
            trigger.parent.mkdir(parents=True, exist_ok=True)
            ac.atomic_write_text(trigger, ac.now_iso())
        except OSError as e:
            raise ApiError(500, "trigger_failed", str(e))
        return 200, {
            "ok": True,
            "trigger": str(trigger),
            "message": "Trigger creado. Qwen automata debe estar corriendo en modo loop.",
        }

    def r_evidence(self) -> Tuple[int, Dict[str, Any]]:
        body = self._read_json()
        app_id = ac.safe_id(body.get("application_id"))
        if not app_id:
            raise ApiError(400, "invalid_application_id", "application_id ausente o inválido")
        step = str(body.get("step") or "").strip().lower()
        if not STEP_RE.match(step):
            raise ApiError(400, "invalid_step", "step inválido (a-z, 0-9, _ y -)")
        m = DATA_URL_RE.match(str(body.get("data_url") or ""))
        if not m:
            raise ApiError(400, "invalid_data_url", "Se esperaba data:image/(png|jpeg|webp);base64,...")
        mime, b64 = m.groups()
        try:
            raw = base64.b64decode(b64, validate=True)
        except (binascii.Error, ValueError):
            raise ApiError(400, "invalid_base64", "Base64 inválido")
        if not raw:
            raise ApiError(400, "empty_image", "Imagen vacía")
        if mime == "png" and not raw.startswith(PNG_SIGNATURE):
            raise ApiError(400, "invalid_image", "El contenido no es un PNG")
        stem = "001_initial" if step == "initial" else step
        folder = self.server.paths.evidence / app_id
        with self.server.lock:
            target = folder / f"{stem}.{EXT_BY_MIME[mime]}"
            n = 2
            while target.exists():  # nunca se pisa evidencia previa
                target = folder / f"{stem}_{n}.{EXT_BY_MIME[mime]}"
                n += 1
            ac.atomic_write_bytes(target, raw)
        log.info("evidencia guardada: %s/%s (%d bytes)", app_id, target.name, len(raw))
        return 200, {"ok": True, "application_id": app_id,
                     "path": self.server.paths.rel(target), "bytes": len(raw)}

    def r_event(self) -> Tuple[int, Dict[str, Any]]:
        body = self._read_json()
        app_id = ac.safe_id(body.get("application_id"))
        if not app_id:
            raise ApiError(400, "invalid_application_id", "application_id ausente o inválido")
        event = str(body.get("event") or "").strip()[:60]
        if not event:
            raise ApiError(400, "invalid_event", "event vacío")
        detail = json.dumps(body.get("detail"), ensure_ascii=False)
        if len(detail) > MAX_EVENT_DETAIL_CHARS:
            detail = json.dumps({"truncated": detail[:MAX_EVENT_DETAIL_CHARS]}, ensure_ascii=False)
        line = json.dumps({"ts": ac.now_iso(), "event": event, "detail": json.loads(detail)},
                           ensure_ascii=False)
        path = self.server.paths.logs / f"{app_id}.jsonl"
        with self.server.lock:
            with open(path, "a", encoding="utf-8") as f:
                f.write(line + "\n")
        return 200, {"ok": True}


GET_ROUTES = [
    (re.compile(r"/health"), Handler.r_health),
    (re.compile(r"/api/next-id"), Handler.r_next_id),
    (re.compile(r"/api/context"), Handler.r_context),
    (re.compile(r"/api/prompt/([^/]+)"), Handler.r_prompt),
    (re.compile(r"/api/approved/([^/]+)"), Handler.r_approved),
    (re.compile(r"/api/site-answers"), Handler.r_site_answers),
    (re.compile(r"/api/run-state"), Handler.r_run_state),
    (re.compile(r"/api/fill-registry"), Handler.r_fill_registry),
]
POST_ROUTES = [
    (re.compile(r"/api/bundle"), Handler.r_bundle),
    (re.compile(r"/api/raw-answers"), Handler.r_raw_answers),
    (re.compile(r"/api/validate"), Handler.r_validate),
    (re.compile(r"/api/qwen-trigger"), Handler.r_qwen_trigger),
    (re.compile(r"/api/evidence"), Handler.r_evidence),
    (re.compile(r"/api/event"), Handler.r_event),
    (re.compile(r"/api/fill-report"), Handler.r_fill_report),
]


# ---------------------------------------------------------------------------
def setup_logging(paths: ac.Paths, to_file: bool = True, verbose: bool = False) -> None:
    root = logging.getLogger("apply_copilot")
    root.setLevel(logging.H_DEBUG if verbose else logging.INFO)
    root.handlers.clear()
    fmt = logging.Formatter("[%(asctime)s] [%(levelname)s] %(message)s", "%Y-%m-%d %H:%M:%S")
    console = logging.StreamHandler()
    console.setFormatter(fmt)
    root.addHandler(console)
    if to_file:
        paths.logs.mkdir(parents=True, exist_ok=True)
        fh = RotatingFileHandler(paths.logs / "receiver.log", maxBytes=1_000_000, backupCount=3, encoding="utf-8")
        fh.setFormatter(fmt)
        root.addHandler(fh)


def main(argv=None) -> int:
    ac.console_utf8()
    p = argparse.ArgumentParser(description="Receiver local de Apply Copilot (solo loopback).")
    p.add_argument("--host", default="127.0.0.1", help="Solo loopback: 127.0.0.1 o localhost")
    p.add_argument("--port", type=int, default=None, help=f"Puerto (por defecto settings.json o {ac.DEFAULT_PORT})")
    p.add_argument("--root", type=Path, default=None, help="Raíz del proyecto (por defecto, la de este repositorio)")
    p.add_argument("-v", "--verbose", action="store_true")
    args = p.parse_args(argv)

    if args.host not in LOOPBACK_HOSTS:
        print(f"Error: el receiver solo puede escuchar en loopback ({', '.join(sorted(LOOPBACK_HOSTS))}); "
              f"recibí {args.host!r}. Exponerlo a la red dejaría tu disco abierto.", file=sys.stderr)
        return 2

    paths = ac.get_paths(args.root).ensure()
    port = args.port if args.port is not None else int(ac.load_settings(paths)["receiver"]["port"])
    setup_logging(paths, verbose=args.verbose)
    try:
        server = ReceiverServer((args.host, port), paths)
    except OSError as e:
        print(f"Error: no pude abrir {args.host}:{port} ({e}). ¿Otro proceso usa el puerto? "
              f"Prueba: python tools/receiver.py --port {port + 1} (y cambia el puerto en la extensión).",
              file=sys.stderr)
        return 1
    log.info("Apply Copilot receiver escuchando en http://%s:%d  (datos: %s)", args.host, port, paths.data)
    log.info("Ctrl+C para detener.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        log.info("Detenido por el usuario.")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
