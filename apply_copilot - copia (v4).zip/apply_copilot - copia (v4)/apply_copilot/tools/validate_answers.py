#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Apply Copilot — validador de respuestas (Fase 5).

    python tools/validate_answers.py --latest-bundle --latest-answers
    python tools/validate_answers.py --bundle B.json --answers A.json --profile config/profile.json
    Get-Clipboard | python tools/validate_answers.py --latest-bundle --stdin      (PowerShell)
        En Windows PowerShell 5 ejecuta antes:  $OutputEncoding = [Console]::OutputEncoding = [Text.UTF8Encoding]::new()
        (si no, las tildes llegan como "?"). Más seguro: guarda la respuesta como archivo y usa --latest-answers.

El LLM propone; este código decide. Convierte la respuesta de Qwen en data/answers/<id>_approved.json con
estado AUTO / REVIEW / HUMAN por campo:

    AUTO   confianza >= 0.85, con fuente verificable          -> se rellena
    REVIEW confianza 0.65-0.85, o inferida / needs_review     -> se rellena y resalta para que la revises
    HUMAN  sensible, sin respuesta, sin fuente, inválida      -> NO se rellena

Códigos de salida: 0 ok · 2 entrada faltante o inválida · 3 application_id no coincide con el bundle.
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

sys.path.insert(0, str(Path(__file__).resolve().parent))
import ac_common as ac  # noqa: E402

RANK = {"AUTO": 0, "REVIEW": 1, "HUMAN": 2}
VALID_SOURCES = {"profile", "template", "inferred", "none"}
PLACEHOLDER_RE = re.compile(r"\[[^\]]{1,60}\]|<[^>]{1,60}>|\{[^}]{1,60}\}|\b(?:xxx+|tbd|todo|lorem ipsum|por definir|completar)\b", re.I)
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
URL_RE = re.compile(r"^https?://\S+$", re.I)
# "Años de experiencia en minería / como ITO / con SAP": experiencia ESPECÍFICA. El perfil solo declara el total.
QUALIFIED_EXPERIENCE_RE = re.compile(r"experiencia\s+(?:\w+\s+)?(?:en|como|con|trabajando)\b")
TRUE_RE = re.compile(r"^(true|si|yes|y|1|x|on|checked|verdadero)$")
FALSE_RE = re.compile(r"^(false|no|0|off|unchecked|falso)$")


class ValidationError(Exception):
    def __init__(self, code: int, message: str):
        super().__init__(message)
        self.code, self.message = code, message


# --------------------------------------------------------------------------- entrada
def extract_json(text: str) -> Dict[str, Any]:
    """Tolera ```json ... ```, texto antes/después y BOM: busca el primer objeto JSON con 'answers'."""
    text = (text or "").lstrip("\ufeff").strip()
    if not text:
        raise ValueError("la respuesta está vacía")
    decoder = json.JSONDecoder()
    first_error: Optional[str] = None
    for m in re.finditer(r"\{", text):
        try:
            obj, _ = decoder.raw_decode(text[m.start():])
        except json.JSONDecodeError as e:
            first_error = first_error or str(e)
            continue
        if isinstance(obj, dict) and isinstance(obj.get("answers"), list):
            return obj
    raise ValueError(first_error or "no encontré un objeto JSON con la lista 'answers'")


def as_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (list, tuple)):
        return "; ".join(as_text(v) for v in value)
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def as_confidence(value: Any) -> float:
    try:
        v = float(value)
    except (TypeError, ValueError):
        return 0.0
    return max(0.0, min(1.0, v)) if v == v else 0.0   # v == v descarta NaN


# --------------------------------------------------------------------------- perfil determinista
def _get(profile: Dict[str, Any], *keys: str) -> str:
    cur: Any = profile
    for k in keys:
        if not isinstance(cur, dict):
            return ""
        cur = cur.get(k)
    return as_text(cur)


def _is_years_experience(label_norm: str) -> bool:
    return bool(re.search(r"\banos?\b", label_norm)) and "experiencia" in label_norm


def _is_total_years(label_norm: str) -> bool:
    """Pregunta genérica ('Años de experiencia', 'Años de experiencia laboral/total')."""
    return _is_years_experience(label_norm) and not QUALIFIED_EXPERIENCE_RE.search(label_norm)


def profile_value(field: Dict[str, Any], profile: Dict[str, Any]) -> Tuple[str, str]:
    """(valor, ruta) si el campo se puede llenar literalmente desde el perfil; si no, ('', '')."""
    label = ac.norm(f"{field.get('question') or ''} {field.get('label') or ''} {field.get('name') or ''}")
    kind = field.get("kind")
    rules = [
        (kind == "email", ("contact", "email")),
        (kind == "phone", ("contact", "phone")),
        ("linkedin" in label, ("links", "linkedin")),
        (re.search(r"nombre completo|nombre y apellido|full name|nombres y apellidos", label), ("full_name",)),
        (re.search(r"cargo actual|puesto actual|current (role|position)", label), ("current_role",)),
        (re.search(r"empresa actual|empleador actual|current (employer|company)", label), ("current_employer",)),
        (re.search(r"\bciudad\b|\bcomuna\b|localidad|residencia", label) and kind in ("text", "select"), ("location", "city")),
        (kind == "number" and _is_total_years(label), ("years_experience",)),
    ]
    for cond, keys in rules:
        if cond:
            v = _get(profile, *keys)
            if v:
                return v, ".".join(keys)
    return "", ""


# --------------------------------------------------------------------------- reglas por campo
def _cap(current: str, new: str) -> str:
    return new if RANK[new] > RANK[current] else current


def evaluate_field(bf: Dict[str, Any], raw: Optional[Dict[str, Any]], profile: Dict[str, Any]) -> Dict[str, Any]:
    kind = bf.get("kind", "text")
    label = str(bf.get("label") or "")
    question = str(bf.get("question") or label)
    item: Dict[str, Any] = {
        "field_id": bf["field_id"], "kind": kind, "label": label, "question": question,
        "required": bool(bf.get("required")), "privacy_level": "normal",
        "answer": "", "confidence": 0.0, "source": "none", "needs_review": True,
        "auto_fill": False, "status": "HUMAN", "reason": "",
    }
    
    # 1) Sensibles: decisión local, independiente de lo que diga Qwen o la extensión
    if bf.get("privacy_level") == "sensitive" or ac.is_sensitive(label, question, bf.get("name"), bf.get("id")):
        item.update(privacy_level="sensitive", reason="Campo sensible: lo completas tú")
        return item
    
    answer = as_text(raw.get("answer")) if raw else ""
    confidence = as_confidence(raw.get("confidence")) if raw else 0.0
    source = str(raw.get("source", "")).strip().lower() if raw else "none"
    reasons: List[str] = []
    if raw is None:
        reasons.append("Qwen no respondió este campo")
    if raw is not None and source not in VALID_SOURCES:
        reasons.append(f"source inválido ('{source}'), tratado como inferred")
        source = "inferred"
    needs_review = bool(raw.get("needs_review")) if raw else True
    
    # 2) Perfil > LLM: lo literal del perfil gana
    pv, pv_key = profile_value(bf, profile)
    if pv:
        if answer and ac.norm(answer) != ac.norm(pv):
            reasons.append(f"Qwen propuso otro valor; se usó el del perfil ({pv_key})")
        answer, confidence, source, needs_review = pv, 1.0, "profile", False
        if not reasons:
            reasons.append(f"Valor literal del perfil ({pv_key})")
    
    status = "AUTO" if confidence >= ac.THRESHOLD_AUTO else "REVIEW" if confidence >= ac.THRESHOLD_FILL else "HUMAN"
    if status != "AUTO" and answer:
        reasons.append(f"confianza {confidence:.2f}")
    
    def cap(to: str, why: str) -> None:
        nonlocal status
        status = _cap(status, to)
        reasons.append(why)
    
    # 3) Reglas de seguridad / calidad
    if answer == "":
        cap("HUMAN", "Sin respuesta" if raw is not None else "")
    else:
        if source == "none":
            cap("HUMAN", "Respuesta sin fuente en el perfil")
        elif source == "inferred":
            cap("REVIEW", "Inferida, no literal: revísala")
        if needs_review:
            cap("REVIEW", "Marcada needs_review")
        if PLACEHOLDER_RE.search(answer) or answer in ("…", "..."):
            cap("HUMAN", "Contiene un marcador pendiente (placeholder)")
        for claim in profile.get("not_in_profile_claims") or []:
            if ac.norm(claim) and ac.norm(claim) in ac.norm(answer):
                cap("REVIEW", f"Menciona '{claim}', que no está en tu perfil: verifica que no sea una afirmación falsa")
                break
    
        options = [str(o) for o in (bf.get("options") or [])]
        if kind == "email" and not EMAIL_RE.match(answer):
            cap("HUMAN", "Email con formato inválido")
        elif kind == "url" and not URL_RE.match(answer):
            cap("HUMAN", "URL inválida (debe iniciar con http:// o https://)")
        elif kind == "phone" and not (re.fullmatch(r"[+\d][\d\s().\-]*", answer) and 7 <= len(re.sub(r"\D", "", answer)) <= 15):
            cap("HUMAN", "Teléfono con formato inválido")
        elif kind == "number":
            if not re.fullmatch(r"-?\d+([.,]\d+)?", answer):
                cap("HUMAN", "Número inválido")
            else:
                limit = _get(profile, "years_experience")
                lbl = ac.norm(f"{question} {label}")
                if limit and _is_years_experience(lbl):
                    if float(answer.replace(",", ".")) > float(limit):
                        cap("HUMAN", f"Declara más años ({answer}) que tu perfil ({limit})")
                    elif not _is_total_years(lbl):
                        cap("REVIEW", "Experiencia específica: tu perfil solo declara el total; verifica que el número sea real")
        elif kind == "date":
            try:
                dt.date.fromisoformat(answer)
            except ValueError:
                cap("HUMAN", "Fecha inválida (usa AAAA-MM-DD)")
        elif kind == "checkbox":
            a = ac.norm(answer)
            if TRUE_RE.match(a):
                answer = "true"
            elif FALSE_RE.match(a):
                answer = "false"
            else:
                cap("HUMAN", "Valor de checkbox inválido (usa true/false)")
        elif kind in ("select", "radio"):
            if not options:
                cap("REVIEW", "El formulario no listó opciones: no se puede verificar")
            elif bf.get("multiple"):
                parts = [p.strip() for p in answer.split(";") if p.strip()]
                canon = [next((o for o in options if ac.norm(o) == ac.norm(p)), None) for p in parts]
                if parts and all(canon):
                    answer = "; ".join(canon)  # type: ignore[arg-type]
                else:
                    cap("HUMAN", "Alguna respuesta no coincide con las opciones")
            else:
                match = next((o for o in options if ac.norm(o) == ac.norm(answer)), None)
                if match:
                    answer = match   # texto exacto de la opción
                else:
                    cap("HUMAN", "La respuesta no coincide con ninguna opción del formulario")
    
    item.update(answer=answer, confidence=round(confidence, 2), source=source, status=status,
                needs_review=status != "AUTO", auto_fill=status in ("AUTO", "REVIEW"),
                reason="; ".join(dict.fromkeys(r for r in reasons if r)))
    return item
    
    
# --------------------------------------------------------------------------- documento completo
def build_approved(bundle: Dict[str, Any], raw: Dict[str, Any], profile: Dict[str, Any]) -> Dict[str, Any]:
    app_id = bundle["application_id"]
    warnings: List[str] = [str(w) for w in (raw.get("warnings") or []) if isinstance(w, (str, int, float))]
    raw_id = raw.get("application_id")
    if raw_id is None:
        warnings.append("La respuesta no incluía application_id; se asumió el del bundle")
    elif str(raw_id) != app_id:
        raise ValidationError(3, f"El application_id de la respuesta ({raw_id!r}) no coincide con el del bundle ({app_id!r}). "
                                  "Probablemente es la respuesta de otro formulario; no se genera nada.")
    
    known = {f["field_id"] for f in bundle["fields"]}
    answers: Dict[str, Dict[str, Any]] = {}
    for a in raw["answers"]:
        if not isinstance(a, dict) or "field_id" not in a:
            warnings.append("Se ignoró una entrada de answers sin field_id")
            continue
        fid = str(a["field_id"])
        if fid not in known:
            warnings.append(f"Se ignoró field_id desconocido: {fid}")
        elif fid in answers:
            warnings.append(f"field_id duplicado ({fid}): se usó la primera respuesta")
        else:
            answers[fid] = a
    
    fields = [evaluate_field(bf, answers.get(bf["field_id"]), profile) for bf in bundle["fields"]]
    counts = {s: sum(1 for f in fields if f["status"] == s) for s in ("AUTO", "REVIEW", "HUMAN")}
    return {
        "schema_version": ac.SCHEMA_VERSION,
        "application_id": app_id,
        "offer_id": bundle.get("offer_id"),
        "portal": bundle.get("portal"),
        "generated_at": ac.now_iso(),
        "policy": {
            "auto_fill_threshold": ac.THRESHOLD_FILL, "auto_status_threshold": ac.THRESHOLD_AUTO,
            "sensitive_autofill": False, "human_must_review_before_submit": True,
        },
        "summary": {"total": len(fields), **counts},
        "fields": fields,
        "human_required_fields": [f["field_id"] for f in fields if f["status"] == "HUMAN"],
        "warnings": warnings,
    }
    
    
# --------------------------------------------------------------------------- CLI
def main(argv=None) -> int:
    ac.console_utf8()
    p = argparse.ArgumentParser(description="Valida las respuestas de Qwen y genera approved_answers.json.")
    p.add_argument("--bundle", type=Path, help="Ruta al *_questions.json")
    p.add_argument("--latest-bundle", action="store_true", help="Usa el bundle más reciente (por defecto)")
    p.add_argument("--answers", type=Path, help="Ruta a la respuesta cruda de Qwen")
    p.add_argument("--latest-answers", action="store_true", help="Usa el *_answers_raw.json más reciente")
    p.add_argument("--stdin", action="store_true", help="Lee la respuesta de Qwen desde la entrada estándar")
    p.add_argument("--profile", type=Path, help="Ruta a profile.json")
    p.add_argument("--out", type=Path, help="Ruta de salida")
    p.add_argument("--root", type=Path, help="Raíz del proyecto")
    args = p.parse_args(argv)
    
    try:
        paths = ac.get_paths(args.root).ensure()
        bundle_path = args.bundle or ac.latest_file(paths.bundles, "*_questions.json")
        if not bundle_path or not Path(bundle_path).exists():
            raise ValidationError(2, "No hay question_bundle. Extrae primero con la extensión.")
        try:
            bundle = ac.read_json(Path(bundle_path))
        except ValueError as e:
            raise ValidationError(2, f"Bundle ilegible: {e}")
        if not isinstance(bundle, dict) or not ac.safe_id(bundle.get("application_id")) or not isinstance(bundle.get("fields"), list):
            raise ValidationError(2, "El bundle no tiene application_id válido o lista de campos.")
        app_id = bundle["application_id"]
    
        expected_raw = paths.answers / f"{app_id}_answers_raw.json"
        if args.stdin:
            raw_text = sys.stdin.buffer.read().decode("utf-8-sig", errors="replace")
            ac.atomic_write_text(expected_raw, raw_text)   # se conserva la respuesta cruda para trazabilidad
        else:
            answers_path = args.answers or (ac.latest_file(paths.answers, "*_answers_raw.json") if args.latest_answers else expected_raw)
            if not answers_path or not Path(answers_path).exists():
                raise ValidationError(2, f"No encuentro la respuesta de Qwen. Guárdala como {paths.rel(expected_raw)} (o usa --stdin / --answers).")
            raw_text = Path(answers_path).read_text(encoding="utf-8-sig", errors="replace")
        try:
            raw = extract_json(raw_text)
        except ValueError as e:
            raise ValidationError(2, f"La respuesta de Qwen no contiene JSON válido: {e}")
    
        profile_path = args.profile or paths.profile
        try:
            profile = ac.read_json(profile_path) if Path(profile_path).exists() else {}
        except ValueError as e:
            raise ValidationError(2, f"profile.json ilegible: {e}")
    
        approved = build_approved(bundle, raw, profile)
    except ValidationError as e:
        print(f"Error: {e.message}", file=sys.stderr)
        return e.code
    
    out = args.out or paths.answers / f"{app_id}_approved.json"
    ac.atomic_write_json(out, approved)
    
    s = approved["summary"]
    print(f"✔ {paths.rel(out)}")
    print(f"  Campos: {s['total']} | AUTO: {s['AUTO']} | REVIEW: {s['REVIEW']} | HUMAN: {s['HUMAN']}")
    human = [f for f in approved["fields"] if f["status"] == "HUMAN"]
    if human:
        print("  Requieren que los completes tú:")
        for f in human:
            print(f"   - {f['question'] or f['label']} ({f['field_id']}): {f['reason']}")
    review = [f for f in approved["fields"] if f["status"] == "REVIEW"]
    if review:
        print(f"  Se rellenarán pero revísalos ({len(review)}): " + ", ".join(f["question"] or f["label"] for f in review))
    for w in approved["warnings"]:
        print(f"  ⚠ {w}")
    print("  Siguiente paso: en la extensión, '2. Cargar respuestas' y luego '3. Rellenar'.")
    return 0
    
    
if __name__ == "__main__":
    sys.exit(main())
