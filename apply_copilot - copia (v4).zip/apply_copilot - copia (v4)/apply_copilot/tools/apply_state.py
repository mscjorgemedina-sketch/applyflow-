#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Puente de estado para /progress de Apply Copilot.

Deriva data/apply_state.json y data/apply_events.jsonl desde lo que la
corrida real deja en data/:
- apply_plan.json      (ofertas del plan, con num_id)
- fill_registry.json   (autofill confirmado por la extensión, receiver v5)
- fill_reports.jsonl   (reportes por pestaña)
- last_run.json        (pestañas abiertas sin reporte / no abiertas)
- applied_registry.json(lo que el usuario marca: python apply_copilot.py mark)
- state_marks.json     (marcas locales del agente: READY/EXPIRED/...)
- jobs_database.json   (solo con --all-history: base histórica + cola v2)

Estados: RANKED, QUEUED, OPENED, FILLED, READY, APPLIED, EXPIRED.
APPLIED significa que el usuario envió la postulación manualmente; el sistema
nunca hace submit.

Uso:
    python tools/apply_state.py sync [--all-history]
    python tools/apply_state.py summary
    python tools/apply_state.py mark <ID> READY --nota "auditoria ok"
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

TOOLS_DIR = Path(__file__).resolve().parent
ROOT = TOOLS_DIR.parent
DATA = ROOT / "data"

JOBS_PATH = DATA / "jobs_database.json"
QUEUE_PATH = DATA / "apply_queue.json"
REGISTRY_PATH = DATA / "fill_registry.json"
REPORTS_PATH = DATA / "fill_reports.jsonl"
LAST_RUN_PATH = DATA / "last_run.json"
APPLIED_PATH = DATA / "applied_registry.json"
MARKS_PATH = DATA / "state_marks.json"
STATE_PATH = DATA / "apply_state.json"
EVENTS_PATH = DATA / "apply_events.jsonl"
PLAN_PATH = DATA / "apply_plan.json"

FRESH_DAYS = 14          # ventana de ofertas activas
RANKED_MIN_SCORE = 60    # umbral para considerar clasificada en la base histórica
QUEUED_ACTIONS = ("priorizar", "revisar")
STATE_ORDER = ["APPLIED", "READY", "FILLED", "OPENED", "QUEUED", "RANKED", "EXPIRED"]
VALID_MARKS = ("READY", "FILTERED", "EXPIRED", "DISCARDED", "APPLIED")


def load_json(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except (ValueError, OSError):
        return default


def read_reports() -> Dict[str, Dict[str, Any]]:
    """Último reporte por oferta, en orden de llegada."""
    latest: Dict[str, Dict[str, Any]] = {}
    if not REPORTS_PATH.exists():
        return latest
    for line in REPORTS_PATH.read_text(encoding="utf-8", errors="replace").splitlines():
        try:
            rec = json.loads(line)
        except ValueError:
            continue
        oid = str(rec.get("offer_id") or "")
        if oid and oid != "0000":  # "0000" = reportes de pestañas de login
            latest[oid] = rec
    return latest


# --------------------------------------------------------------------------- índice
def build_index(today: dt.date) -> Dict[str, Dict[str, Any]]:
    """Ofertas candidatas a aparecer en el estado, un plan + registro + histórico."""
    index: Dict[str, Dict[str, Any]] = {}
    last_run = load_json(LAST_RUN_PATH, {}) or {}

    # plan del orquestador (num_id = ID numérico de ChileTrabajos)
    for row in load_json(PLAN_PATH, []) or []:
        if not isinstance(row, dict):
            continue
        num = str(row.get("num_id") or "")
        if not num:
            continue
        index[num] = {
            "titulo": row.get("titulo", ""),
            "url": row.get("apply_url") or row.get("url") or "",
            "score": int(row.get("score") or 0),
            "fecha": str(row.get("fecha") or "")[:10],
            "cluster_name": row.get("cluster_name") or "",
            "ultima_vez": "",
            "source": "apply_plan",
            "run_id": last_run.get("run_id", ""),
        }

    # rellenadas fuera del plan (por ejemplo, la prueba de 3 pestañas)
    registry = load_json(REGISTRY_PATH, {}) or {}
    for oid, rec in registry.items():
        if oid in index or not isinstance(rec, dict):
            continue
        index[str(oid)] = {
            "titulo": str(rec.get("title") or "").replace(" | Chiletrabajos", ""),
            "url": f"https://www.chiletrabajos.cl/trabajo/postular/{oid}",
            "score": 0,
            "fecha": "",
            "cluster_name": "",
            "ultima_vez": "",
            "source": "fill_registry",
            "run_id": rec.get("run_id", ""),
        }
    return index


def build_history_ids(today: dt.date) -> Dict[str, Dict[str, Any]]:
    """Base histórica (job_hunter) para --all-history: ofertas recientes score>=60."""
    out: Dict[str, Dict[str, Any]] = {}
    for oid, offer in (load_json(JOBS_PATH, {}) or {}).items():
        if not isinstance(offer, dict):
            continue
        score = int(offer.get("score") or 0)
        if score < RANKED_MIN_SCORE:
            continue
        last_seen = str(offer.get("ultima_vez") or "")[:10]
        try:
            fresh = (today - dt.date.fromisoformat(last_seen)).days <= FRESH_DAYS
        except ValueError:
            fresh = False
        if not fresh:
            continue
        out[str(oid)] = {
            "titulo": offer.get("titulo", ""),
            "url": offer.get("url") or "",
            "score": score,
            "fecha": str(offer.get("fecha_publicacion") or "")[:10],
            "cluster_name": offer.get("cluster_name") or "",
            "ultima_vez": last_seen,
            "source": "jobs_database",
            "run_id": "",
        }
    return out


def build_queue_rows() -> Dict[str, Dict[str, Any]]:
    rows: Dict[str, Dict[str, Any]] = {}
    for row in (load_json(QUEUE_PATH, {}) or {}).get("offers", []):
        key = str(row.get("offer_key") or "")   # ID numérico
        alias = str(row.get("offer_id") or "")  # ID del corpus (ch_*)
        if key:
            rows.setdefault(key, row)
        if alias:
            rows.setdefault(alias, row)
    return rows


# --------------------------------------------------------------------------- derivación
def derive_state(
    oid: str,
    offer: Dict[str, Any],
    registry: Dict[str, Any],
    latest: Dict[str, Dict[str, Any]],
    last_run: Dict[str, Any],
    applied_rows: Dict[str, Dict[str, Any]],
    marks: Dict[str, Any],
    queue: Dict[str, Dict[str, Any]],
    today: dt.date,
) -> tuple:
    detail: Dict[str, Any] = {"source": offer.get("source", "")}
    age: Optional[int] = None
    for campo in ("fecha", "ultima_vez"):
        raw = str(offer.get(campo) or "")[:10]
        if raw:
            try:
                age = (today - dt.date.fromisoformat(raw)).days
                break
            except ValueError:
                pass

    # 1) marcas locales (READY/EXPIRED/DISCARDED...)
    if oid in marks:
        row = marks[oid] or {}
        state = str(row.get("state") or "").upper()
        if row.get("nota"):
            detail["nota"] = row["nota"]
        return state, detail

    # 2) registro de postulación (el usuario la envió)
    if applied_rows.get(oid):
        rec = applied_rows[oid] or {}
        estado = str(rec.get("estado") or "").upper()
        if rec.get("fecha_postulacion"):
            detail["sent_date"] = rec["fecha_postulacion"]
        if rec.get("notas"):
            detail["nota"] = rec["notas"]
        detail["estado_raw"] = estado
        return ("APPLIED" if estado in ("APPLIED", "INTERVIEW") else "EXPIRED"), detail

    # 3) autofill confirmado por la extensión
    if registry.get(oid, {}).get("status") == "filled":
        detail["run_id"] = registry[oid].get("run_id", "")
        return "FILLED", detail

    # 4) reportes de pestañas
    if oid in latest:
        rec = latest[oid]
        status = str(rec.get("status") or "")
        detail["run_id"] = rec.get("run_id", "")
        detail["filled_fields"] = int(rec.get("filled") or 0)
        detail["skipped"] = rec.get("skipped", [])
        if status == "expired":
            return "EXPIRED", detail
        if status in ("opened", "no_form", "error"):
            detail["reason"] = status
            return "OPENED", detail
        if status == "filled":
            detail["run_id"] = rec.get("run_id", "")
            return "FILLED", detail

    # 5) pestaña abierta sin reporte / planeada sin abrir (última corrida)
    unreported = {str(x) for x in last_run.get("unreported_ids", [])}
    not_opened = {str(x) for x in last_run.get("not_opened_ids", [])}
    if oid in unreported:
        detail["reason"] = "pestaña abierta sin confirmar"
        return "OPENED", detail
    if oid in not_opened:
        detail["reason"] = "planeada, pestaña no abierta"
        return "QUEUED", detail

    # 6) en cola del ranking v2 (solo modo histórico la consulta)
    qrow = queue.get(oid)
    if qrow and qrow.get("action") in QUEUED_ACTIONS and (age is None or age <= FRESH_DAYS):
        detail["score_v2"] = qrow.get("score_v2")
        return "QUEUED", detail

    # 7) clasificada por score, o desactualizada por fecha
    if age is not None and age > FRESH_DAYS:
        detail["age_days"] = age
        return "EXPIRED", detail
    if int(offer.get("score") or 0) >= RANKED_MIN_SCORE:
        return "RANKED", detail
    if offer.get("source") == "apply_plan":
        return "QUEUED", detail
    if offer.get("source") == "fill_registry":
        detail["reason"] = "entrada sin estado conocido todavía"
        return "OPENED", detail
    return None, detail


# --------------------------------------------------------------------------- estado
def build_state(today: dt.date, include_history: bool) -> Dict[str, Any]:
    last_run = load_json(LAST_RUN_PATH, {}) or {}
    registry = load_json(REGISTRY_PATH, {}) or {}
    latest = read_reports()
    applied_rows = load_json(APPLIED_PATH, {}) or {}
    marks = load_json(MARKS_PATH, {}) or {}
    queue = build_queue_rows() if include_history else {}

    index = build_index(today)
    if include_history:
        for oid, offer in build_history_ids(today).items():
            index.setdefault(oid, offer)

    offers_out: List[Dict[str, Any]] = []
    for oid, offer in index.items():
        state, detail = derive_state(oid, offer, registry, latest, last_run,
                                     applied_rows, marks, queue, today)
        if not state:
            continue
        offers_out.append({
            "offer_id": oid,
            "title": offer.get("titulo", ""),
            "url": offer.get("url", ""),
            "score": int(offer.get("score") or 0),
            "score_v2": queue.get(oid, {}).get("score_v2"),
            "run_id": detail.get("run_id", ""),
            "state": state,
            "detail": detail,
        })

    counts = {s: 0 for s in STATE_ORDER}
    for row in offers_out:
        counts[row["state"]] = counts.get(row["state"], 0) + 1
    rank = {s: i for i, s in enumerate(STATE_ORDER)}
    offers_out.sort(key=lambda r: (rank.get(r["state"], 99), -r["score"], -int(r["score_v2"] or 0)))

    return {
        "updated_at": dt.datetime.now().replace(microsecond=0).isoformat(),
        "goal": 100,
        "counts": counts,
        "pending_human_review": counts.get("FILLED", 0),
        "enviadas_aplicadas": counts.get("APPLIED", 0),
        "runs": load_json(LAST_RUN_PATH, {}) or {},
        "offers": offers_out,
    }


def append_events(state: Dict[str, Any], previous: Dict[str, Any]) -> int:
    """Registra solo transiciones respecto al archivo de estado previo."""
    if not state.get("offers"):
        return 0
    prev_states = {str(o.get("offer_id")): o.get("state") for o in previous.get("offers", [])}

    events: List[str] = []
    for row in state["offers"]:
        oid = str(row["offer_id"])
        new_state = row["state"]
        if prev_states.get(oid) == new_state:
            continue
        event = {
            "ts": state["updated_at"],
            "offer_id": oid,
            "event": new_state,
            "from": prev_states.get(oid),
            "title": row.get("title", ""),
        }
        if row["detail"].get("run_id"):
            event["run_id"] = row["detail"]["run_id"]
        if row["detail"].get("nota"):
            event["nota"] = row["detail"]["nota"]
        events.append(json.dumps(event, ensure_ascii=False) + "\n")

    if not events:
        return 0
    with EVENTS_PATH.open("a", encoding="utf-8") as fh:
        fh.writelines(events)
    return len(events)


# --------------------------------------------------------------------------- comandos
def cmd_sync(args) -> int:
    today = dt.date.today()
    previous = load_json(STATE_PATH, {}) or {}
    state = build_state(today, include_history=args.all_history)
    tmp = STATE_PATH.with_suffix(".tmp.json")
    tmp.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(STATE_PATH)
    added = append_events(state, previous)
    counts = state["counts"]
    print(f"Estado: {count_line(counts)}")
    filled = counts.get("FILLED", 0) + counts.get("READY", 0)
    print(f"Rellenadas (FILLED+READY): {filled} | objetivo: {state['goal']} "
          f"| cumplido: {'SI' if filled >= state['goal'] else 'NO'}")
    print(f"Enviadas por el usuario (APPLIED): {counts.get('APPLIED', 0)}")
    print(f"Archivo: {STATE_PATH} | Eventos: {EVENTS_PATH} (+{added} nuevos)")
    return 0


def cmd_summary(args) -> int:
    state = load_json(STATE_PATH, {}) or {}
    if not state or not state.get("offers"):
        print("Todavía no hay estado del pipeline. Primero corre: python tools/apply_state.py sync")
        return 0
    counts = state.get("counts", {})
    print(f"Estado al {state.get('updated_at', '?')}")
    print(f"  {count_line(counts)}")
    filled = counts.get("FILLED", 0) + counts.get("READY", 0)
    goal = int(state.get("goal") or 0)
    print(f"  Objetivo >= {goal} rellenadas: "
          f"{'CUMPLIDO' if filled >= goal and goal else 'NO'} ({filled})")
    print(f"  Pendientes de revisión humana (FILLED sin auditar/enviar): "
          f"{state.get('pending_human_review', counts.get('FILLED', 0))}")
    print(f"  Enviadas por el usuario: {state.get('enviadas_aplicadas', 0)}")

    daily: Dict[str, int] = {}
    if EVENTS_PATH.exists():
        for line in EVENTS_PATH.read_text(encoding="utf-8", errors="replace").splitlines():
            try:
                ev = json.loads(line)
            except ValueError:
                continue
            if ev.get("event") == "APPLIED":
                day = str(ev.get("ts") or ev.get("sent_date") or "")[:10]
                if day:
                    daily[day] = daily.get(day, 0) + 1
    if daily:
        print("  Envíos por día:")
        for day in sorted(daily):
            print(f"    {day}: {daily[day]}")

    if APPLIED_PATH.exists():
        applied = load_json(APPLIED_PATH, {}) or {}
        if applied:
            print("  Registros del usuario (apply_copilot.py mark):")
            for oid, rec in applied.items():
                print(f"    {oid}: {rec.get('estado', '')} "
                      f"{('[' + rec.get('notas', '') + ']') if rec.get('notas') else ''}")
    return 0


def cmd_mark(args) -> int:
    state = str(args.state).upper()
    if state not in VALID_MARKS:
        print(f"Estado inválido '{args.state}'. Usa: {', '.join(VALID_MARKS)}", file=sys.stderr)
        return 2
    marks = load_json(MARKS_PATH, {}) or {}
    marks[str(args.offer_id)] = {"state": state, "nota": args.nota,
                                 "ts": dt.datetime.now().replace(microsecond=0).isoformat()}
    tmp = MARKS_PATH.with_suffix(".tmp.json")
    tmp.write_text(json.dumps(marks, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(MARKS_PATH)
    print(f"✔ Marca local: {args.offer_id} → {state}")
    print("  Materializa con: python tools/apply_state.py sync")
    if state == "APPLIED":
        print("  Consejo: para APPLIED definitivo usa python apply_copilot.py mark "
              f"{args.offer_id} APPLIED (graba la fecha en job_hunter).")
    return 0


def count_line(counts: Dict[str, int]) -> str:
    return " | ".join(f"{s}={counts.get(s, 0)}" for s in STATE_ORDER)


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Estado del pipeline de postulación")
    sub = parser.add_subparsers(dest="cmd", required=True)

    sync = sub.add_parser("sync", help="Reconstruye apply_state.json y eventos")
    sync.add_argument("--all-history", action="store_true",
                      help="Incluye la base histórica y la cola v2 (RANKED/EXPIRED por oferta)")
    sync.set_defaults(fn=cmd_sync)

    sum_ = sub.add_parser("summary", help="Resumen tipo /progress")
    sum_.set_defaults(fn=cmd_summary)

    m = sub.add_parser("mark", help="Marca local READY/EXPIRED/DISCARDED/FILTERED/APPLIED")
    m.add_argument("offer_id")
    m.add_argument("state")
    m.add_argument("--nota", default="")
    m.set_defaults(fn=cmd_mark)

    args = parser.parse_args(argv)
    return args.fn(args)


if __name__ == "__main__":
    raise SystemExit(main())
