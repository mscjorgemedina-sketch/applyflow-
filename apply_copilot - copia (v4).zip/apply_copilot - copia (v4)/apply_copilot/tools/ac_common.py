#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Utilidades compartidas por receiver, generador de prompt, validador y orquestador.
Solo biblioteca estándar.

IMPORTANTE: SENSITIVE_TERMS debe coincidir con la constante del mismo nombre en
extension/content/extract.js (tests/test_common.py lo verifica).
"""

from __future__ import annotations

import datetime as dt
import json
import os
import re
import tempfile
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

SCHEMA_VERSION = "1.0"
SERVICE_NAME = "apply_copilot_receiver"
DEFAULT_PORT = 8765

# Umbrales de decisión (plan §Fase 4)
THRESHOLD_AUTO = 0.85   # >= y no sensible -> AUTO
THRESHOLD_FILL = 0.65   # >= -> REVIEW ; < -> HUMAN

# Un ID válido empieza con alfanumérico: así ni "." ni ".." ni rutas pasan.
SAFE_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,119}$")

# Términos sin tildes y en minúsculas. "stem*" = prefijo; sin "*" = palabra completa o frase.
SENSITIVE_TERMS: List[str] = [
    # identificación y credenciales
    "rut", "run", "dni", "cedula", "pasaporte", "token", "secret*", "clave",
    "contrasena*", "password*", "passwd*",
    # datos personales sensibles
    "edad", "nacimiento*", "salud", "discapacidad*", "antecedente*", "penal*", "poligraf*",
    # dinero
    "renta", "sueld*", "salari*", "remuneracion*", "pretension*", "ingreso*",
    "bancari*", "iban", "swift", "numero de cuenta", "tarjeta de credito",
    # aceptaciones legales y declaraciones
    "acept*", "declaro*", "declaracion jurada", "jurament*", "consentimiento*", "autorizo*",
    "terminos", "terminos y condiciones", "politica de privacidad", "politicas de privacidad",
    "bases legales", "bases del proceso", "bases del concurso", "bases de postulacion",
    "bases y condiciones",
]


def norm(text: Any) -> str:
    """Minúsculas y sin tildes ('Pretensión' -> 'pretension')."""
    decomposed = unicodedata.normalize("NFKD", str(text or ""))
    return "".join(c for c in decomposed if not unicodedata.combining(c)).lower()


def _compile_term(term: str) -> "re.Pattern[str]":
    t = norm(term)
    if t.endswith("*"):
        return re.compile(r"(?<![a-z0-9])" + re.escape(t[:-1]))
    return re.compile(r"(?<![a-z0-9])" + re.escape(t) + r"(?![a-z0-9])")


_SENSITIVE_RES = [(t, _compile_term(t)) for t in SENSITIVE_TERMS]


def sensitive_hits(*texts: Any) -> List[str]:
    """Términos sensibles encontrados en cualquiera de los textos."""
    haystack = " ".join(norm(t) for t in texts if t)
    return [term for term, rx in _SENSITIVE_RES if rx.search(haystack)]


def is_sensitive(*texts: Any) -> bool:
    return bool(sensitive_hits(*texts))


def safe_id(value: Any) -> Optional[str]:
    """Devuelve el ID si es seguro como nombre de archivo/carpeta; si no, None."""
    value = str(value or "").strip()
    return value if SAFE_ID_RE.match(value) else None


def now_iso() -> str:
    return dt.datetime.now().replace(microsecond=0).isoformat()


# --------------------------------------------------------------------------- rutas
@dataclass(frozen=True)
class Paths:
    root: Path
    config: Path
    data: Path
    bundles: Path
    answers: Path
    evidence: Path
    prompts: Path
    logs: Path
    profile: Path
    settings: Path
    current_offer: Path

    def ensure(self) -> "Paths":
        for p in (self.bundles, self.answers, self.evidence, self.prompts, self.logs):
            p.mkdir(parents=True, exist_ok=True)
        return self

    def rel(self, path: Path) -> str:
        try:
            return Path(path).resolve().relative_to(self.root.resolve()).as_posix()
        except ValueError:
            return str(path)


def get_paths(root: Optional[Path] = None) -> Paths:
    """Raíz del proyecto: argumento > variable AC_ROOT > carpeta padre de tools/."""
    if root is None:
        env = os.environ.get("AC_ROOT")
        root = Path(env) if env else Path(__file__).resolve().parent.parent
    root = Path(root)
    data = root / "data"
    return Paths(
        root=root, config=root / "config", data=data,
        bundles=data / "bundles", answers=data / "answers", evidence=data / "evidence",
        prompts=data / "prompts", logs=data / "logs",
        profile=root / "config" / "profile.json",
        settings=root / "config" / "settings.json",
        current_offer=data / "current_offer.json",
    )


DEFAULT_SETTINGS: Dict[str, Any] = {
    "job_hunter_dir": "",
    "receiver": {"host": "127.0.0.1", "port": DEFAULT_PORT},
    "limits": {  # reserv도 para el modo lote (Fase 8, no implementado en el MVP)
        "max_applications_per_day": 10,
        "max_per_portal_per_day": 4,
        "delay_between_applications_seconds": [45, 120],
        "require_human_approval": True,
        "auto_submit": False,
        "min_score_for_batch": 70,
        "block_sensitive_autofill": True,
    },
}


def load_settings(paths: Paths) -> Dict[str, Any]:
    settings = json.loads(json.dumps(DEFAULT_SETTINGS))
    if paths.settings.exists():
        try:
            user = read_json(paths.settings)
        except (ValueError, OSError):
            return settings
        for k, v in user.items():
            if isinstance(v, dict) and isinstance(settings.get(k), dict):
                settings[k].update(v)
            else:
                settings[k] = v
    return settings


# --------------------------------------------------------------------------- E/S de archivos
def read_json(path: Path) -> Any:
    with open(path, "r", encoding="utf-8-sig") as f:  # utf-8-sig tolera el BOM de PowerShell
        return json.load(f)


def atomic_write_bytes(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=path.name + ".", suffix=".tmp")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def atomic_write_json(path: Path, obj: Any) -> None:
    atomic_write_bytes(path, json.dumps(obj, ensure_ascii=False, indent=2).encode("utf-8"))


def atomic_write_text(path: Path, text: str) -> None:
    atomic_write_bytes(path, text.encode("utf-8"))


def latest_file(directory: Path, pattern: str) -> Optional[Path]:
    files: Iterable[Path] = [p for p in Path(directory).glob(pattern) if p.is_file()]
    return max(files, key=lambda p: p.stat().st_mtime, default=None)


def app_id_from_name(path: Path, suffix: str) -> str:
    """'app_x_questions.json' -> 'app_x'."""
    name = Path(path).name
    return name[: -len(suffix)] if name.endswith(suffix) else Path(path).stem


def console_utf8() -> None:
    """Consola de Windows: evita UnicodeEncodeError con tildes y emojis."""
    import sys
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
