#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Estimación de pretensión de renta para ApplyFlow.

- Si hay una API key configurada, hace UNA llamada en lote al LLM.
- Si no hay key o la llamada falla, usa una tabla de mercado local (Chile 2026).
- Devuelve {offer_id: {"clp": int, "nota": str, "source": "llm"|"heuristica"}}.
"""

from __future__ import annotations

import json
import os
import re
import sys
import unicodedata
import urllib.request
from typing import Any, Dict, List, Optional, Tuple

BASE_BY_CLUSTER = {
    "C1_GESTION": 3_400_000,
    "C2_ITO": 3_000_000,
    "C3_MECANICA": 3_000_000,
    "C4_PIPING": 3_100_000,
    "C5_AGUA": 2_600_000,
}

CITY_MULT = {
    "santiago": 1.00,
    "antofagasta": 1.12,
    "calama": 1.15,
    "iquique": 1.05,
    "concepcion": 0.96,
    "valparaiso": 0.96,
    "vina del mar": 0.96,
    "rancagua": 0.95,
    "la serena": 0.94,
    "copiapo": 1.02,
    "talca": 0.92,
    "temuco": 0.90,
    "puerto montt": 0.90,
    "osorno": 0.90,
    "arica": 0.95,
}

CITIES = list(CITY_MULT) + ["vina del mar"]

TITLE_ADJ = [
    ("gerente", 1.25),
    ("jefe", 1.12),
    ("supervisor", 1.08),
    ("senior", 1.10),
    ("project manager", 1.10),
    ("planificador", 0.95),
    ("inspector", 1.00),
]

MIN_CLP = 1_500_000
MAX_CLP = 6_000_000

# Clusters de versiones anteriores → clusters actuales.
LEGACY_CLUSTER = {
    "C3_OPERACIONES": "C3_MECANICA",
    "C4_MANTENIMIENTO": "C3_MECANICA",
    "C5_ESPECIALISTA": "C4_PIPING",
}


def _norm(text: Any) -> str:
    decomposed = unicodedata.normalize("NFKD", str(text or ""))
    return "".join(c for c in decomposed if not unicodedata.combining(c)).lower().strip()


def city_from(title: str, location: str, default: str = "Santiago") -> str:
    haystack = _norm(f"{title} {location}")
    for city in CITIES:
        if re.search(r"(?<![a-z])" + re.escape(city) + r"(?![a-z])", haystack):
            return city
    return default


def format_clp(value: int) -> str:
    return "$" + f"{int(value):,}".replace(",", ".")


def _round_clp(value: float) -> int:
    value = max(MIN_CLP, min(MAX_CLP, value))
    return int(round(value / 50_000.0) * 50_000)


def _heuristic_one(offer: Dict[str, Any], profile: Dict[str, Any]) -> Dict[str, Any]:
    cluster = str(offer.get("cluster_id") or "C1_GESTION")
    cluster = LEGACY_CLUSTER.get(cluster, cluster)
    base = BASE_BY_CLUSTER.get(cluster, 3_000_000)
    title = _norm(offer.get("titulo") or "")
    city = city_from(offer.get("titulo") or "", offer.get("ubicacion") or "",
                     default=(profile.get("location") or {}).get("city") or "Santiago")

    factor = CITY_MULT.get(_norm(city), 1.0)
    for term, adj in TITLE_ADJ:
        if term in title:
            factor *= adj
            break

    years = int(profile.get("years_experience") or 0)
    factor *= 1 + min(max(years - 5, 0), 10) * 0.02

    clp = _round_clp(base * factor)
    return {
        "clp": clp,
        "nota": f"Tabla de mercado Chile 2026 · {city} · {cluster}",
        "source": "heuristica",
    }


def _llm_config() -> Optional[Tuple[str, str, str]]:
    """Devuelve (url, api_key, modelo) si hay configuración."""
    custom_key = os.environ.get("LLM_API_KEY")
    custom_url = os.environ.get("LLM_BASE_URL")
    if custom_key and custom_url:
        base = custom_url.rstrip("/")
        url = base if base.endswith("/chat/completions") else base + "/chat/completions"
        return url, custom_key, os.environ.get("LLM_MODEL", "gpt-4o-mini")

    if os.environ.get("OPENAI_API_KEY"):
        return ("https://api.openai.com/v1/chat/completions",
                os.environ["OPENAI_API_KEY"],
                os.environ.get("OPENAI_MODEL", "gpt-4o-mini"))

    if os.environ.get("OPENROUTER_API_KEY"):
        return ("https://openrouter.ai/api/v1/chat/completions",
                os.environ["OPENROUTER_API_KEY"],
                os.environ.get("OPENROUTER_MODEL", "openai/gpt-4o-mini"))

    return None


def _extract_json(text: str) -> Dict[str, Any]:
    text = (text or "").strip()
    text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.I)
    text = re.sub(r"\s*```$", "", text)
    start, end = text.find("{"), text.rfind("}")
    if start >= 0 and end > start:
        text = text[start:end + 1]
    return json.loads(text)


def _llm_estimate(offers: List[Dict[str, Any]], profile: Dict[str, Any]) -> Optional[Dict[str, Dict[str, Any]]]:
    cfg = _llm_config()
    if not cfg:
        return None
    url, key, model = cfg

    payload_offers = [
        {
            "id": str(o.get("num_id") or o.get("id")),
            "titulo": o.get("titulo", ""),
            "ciudad": city_from(o.get("titulo", ""), o.get("ubicacion", ""),
                                default=(profile.get("location") or {}).get("city") or "Santiago"),
            "cluster": o.get("cluster_name") or o.get("cluster_id", ""),
        }
        for o in offers
    ]

    prompt = (
        "Eres un analista de remuneraciones del mercado laboral chileno (2026). "
        "Estima una pretensión de renta mensual bruta competitiva en CLP para cada oferta, "
        "considerando cargo, ciudad, cluster y el perfil del postulante. "
        "Usa rangos realistas de mercado chileno; no inventes cargos. "
        "Devuelve SOLO un JSON válido con esta forma: "
        '{"<id>": {"clp": 3200000, "nota": "breve justificación"}}.\n\n'
        f"PERFIL: {json.dumps({
            'titulo': profile.get('headline') or profile.get('title'),
            'ciudad': (profile.get('location') or {}).get('city'),
            'experiencia_anos': profile.get('years_experience'),
            'cargo_actual': profile.get('current_role'),
            'formacion': profile.get('education'),
            'skills': profile.get('skills'),
        }, ensure_ascii=False)}\n\n"
        f"OFERTAS: {json.dumps(payload_offers, ensure_ascii=False)}"
    )

    body = json.dumps({
        "model": model,
        "temperature": 0.2,
        "messages": [
            {"role": "system", "content": "Responde únicamente con JSON válido, sin markdown."},
            {"role": "user", "content": prompt},
        ],
        "response_format": {"type": "json_object"},
    }).encode("utf-8")

    req = urllib.request.Request(url, data=body, method="POST")
    req.add_header("Content-Type", "application/json")
    req.add_header("Authorization", f"Bearer {key}")
    if "openrouter.ai" in url:
        req.add_header("HTTP-Referer", "http://127.0.0.1")
        req.add_header("X-Title", "ApplyFlow")

    try:
        with urllib.request.urlopen(req, timeout=90) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        content = data["choices"][0]["message"]["content"]
        raw = _extract_json(content)
    except Exception as exc:  # noqa: BLE001 - cualquier fallo cae a heurística
        print(f"⚠ LLM no disponible ({exc}); uso tabla de mercado local.")
        return None

    result: Dict[str, Dict[str, Any]] = {}
    for oid, item in (raw or {}).items():
        if not isinstance(item, dict):
            continue
        try:
            clp = int(float(item.get("clp")))
        except (TypeError, ValueError):
            continue
        if clp <= 0:
            continue
        result[str(oid)] = {
            "clp": max(MIN_CLP, min(MAX_CLP, clp)),
            "nota": str(item.get("nota") or "Estimación LLM"),
            "source": "llm",
        }
    return result or None


def estimate(offers: List[Dict[str, Any]], profile: Dict[str, Any],
             use_llm: bool = True) -> Dict[str, Dict[str, Any]]:
    """Estima el sueldo de todas las ofertas. Una llamada LLM; fallback local por oferta."""
    result: Dict[str, Dict[str, Any]] = {}
    if use_llm:
        llm = _llm_estimate(offers, profile)
        if llm:
            result.update(llm)
            print(f"💰 Sueldo: LLM estimó {len(llm)}/{len(offers)} ofertas.")
        else:
            print("💰 Sueldo: estimación local (sin LLM configurado).")
    else:
        print("💰 Sueldo: estimación local (--sin-llm).")

    for offer in offers:
        oid = str(offer.get("num_id") or offer.get("id"))
        if oid not in result:
            result[oid] = _heuristic_one(offer, profile)
    return result


def _autotest() -> int:
    """Auto-test determinista del estimador (sin red, sin LLM)."""
    failures: List[str] = []
    stats = {"ok": 0, "total": 0}

    def check(nombre: str, cond: bool, detalle: str = "") -> None:
        stats["total"] += 1
        if cond:
            stats["ok"] += 1
            print("  ✓ " + nombre)
        else:
            print("  ✖ " + nombre + (f" ({detalle})" if detalle else ""))
            failures.append(nombre)

    ex_ok = None
    try:
        check("_norm básico", _norm("Santiago  Centro") == "santiago  centro")
        check("city Antofagasta separado de Santiago", city_from("Jefe Oficina Técnica Mejillones", "Mejillones / Antofagasta") == "antofagasta")
        check("round 50k", _round_clp(2_660_000) == 2_650_000, f"={_round_clp(2_660_000):,}".replace(",", "."))
        check("clamp min", _round_clp(1_000_000) == MIN_CLP, f"={format_clp(_round_clp(1_000_000))}")
        check("clamp max", _round_clp(7_000_000) == MAX_CLP, f"={format_clp(_round_clp(7_000_000))}")

        h1 = _heuristic_one({"cluster_id": "C2_ITO", "titulo": "Supervisor Mecánico",
                             "ubicacion": "Antofagasta"}, {"years_experience": 8})
        esperado = int(round(3_000_000 * 1.12 * 1.08 * 1.06 / 50_000.0) * 50_000)
        check("tabla supervisor/Antofagasta/8 años", h1["clp"] == esperado,
              f"esperado {format_clp(esperado)}, real {format_clp(h1['clp'])}")
        check("nota tabla = heuristica", h1["source"] == "heuristica")

        h2 = _heuristic_one({"cluster_id": "C4_MANTENIMIENTO", "titulo": "Operador",
                             "ubicacion": ""}, {"years_experience": 5})
        check("cluster legacy C4_MANTENIMIENTO→C3_MECANICA", h2["clp"] == 3_000_000,
              f"={format_clp(h2['clp'])}")

        est = estimate(
            [
                {"num_id": "48000", "cluster_id": "C5_AGUA", "titulo": "Operador Planta",
                 "ubicacion": "Concepción"},
                {"num_id": "48001", "cluster_id": "C1_GESTION", "titulo": "Jefe de Proyectos",
                 "ubicacion": "Santiago"},
            ],
            {"years_experience": 6, "location": {"city": "Santiago"}},
            use_llm=False,
        )
        check("estimate sin LLM cubre ambas ofertas",
              all(o in est for o in ("48000", "48001")) and all(
                  est[o]["source"] == "heuristica" for o in ("48000", "48001")))

        check("extract_json fenced", _extract_json("```json\n{\"a\": 1}\n```") == {"a": 1})
        cfg = _llm_config()
        check("_llm_config tipo coherente", cfg is None or (isinstance(cfg, tuple) and len(cfg) == 3),
              "sin key" if cfg is None else "key configurada")
    except Exception as exc:  # noqa: BLE001
        failures.append(f"excepción: {exc}")

    if failures:
        print(f"autotest sueldo: {len(failures)}/{stats['total']} fallos: {'; '.join(failures)}")
        return 1
    print(f"autotest sueldo: OK ({stats['ok']}/{stats['total']})")
    return 0


def main(argv: Optional[List[str]] = None) -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    args = list(sys.argv[1:] if argv is None else argv)
    if not args or args[0] == "--autotest":
        return _autotest()
    print("uso: python tools/salary.py --autotest")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
