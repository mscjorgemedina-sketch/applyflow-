#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
=============================================================================
JOB HUNTER PRO v2
=============================================================================
Busca ofertas en ChileTrabajos, Trabajando, Indeed y Laborum, las puntúa
según el perfil, las guarda en un histórico y genera un dashboard HTML.

Uso:
    python job_hunter.py                  # búsqueda completa
    python job_hunter.py --quick          # 1 consulta por cluster
    python job_hunter.py --sources ChileTrabajos,Indeed
    python job_hunter.py --debug-html     # guarda el HTML crudo de cada portal
    python job_hunter.py --mark <id> APPLIED --nota "enviado CV"

Requisito opcional (portales dinámicos):
    pip install playwright && python -m playwright install chromium
"""

from __future__ import annotations

import argparse
import asyncio
import datetime as dt
import hashlib
import html
import http.cookiejar
import json
import logging
import os
import random
import re
import sys
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

try:  # Playwright es opcional: sin él solo se usan los portales HTTP simples
    from playwright.async_api import async_playwright
    HAS_PLAYWRIGHT = True
except ImportError:  # pragma: no cover
    async_playwright = None
    HAS_PLAYWRIGHT = False

log = logging.getLogger("job_hunter")

# ---------------------------------------------------------------------------
# CONFIGURACIÓN
# ---------------------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:127.0) Gecko/20100101 Firefox/127.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15",
]

CANDIDATE_PROFILE = {  # solo referencia; el perfil real se lee de perfiles/<nombre>/profile.json
    "name": "Tu Nombre Completo",
    "title": "Tu titular profesional",
    "education": "Tu educación",
}

# Las primeras keywords de cada cluster son las que se usan en --quick.
CLUSTERS: Dict[str, Dict[str, Any]] = {
    "C1_GESTION": {"name": "Gestión de Proyectos & Contratos",
                   "keywords": ["Project Manager", "Administrador de Contratos", "Contract Manager",
                                "Ingeniero de Proyectos", "Jefe de Proyectos", "Coordinador de Proyectos",
                                "Control de Proyectos", "Oficina Técnica", "Administrador de Obra",
                                "Jefe de Oficina Técnica", "Planificador de Proyectos",
                                "Ingeniero de Planificación"]},
    "C2_ITO": {"name": "ITO & Aseguramiento de Calidad",
               "keywords": ["ITO", "Inspector Técnico de Obra", "Inspector Técnico", "QA/QC",
                            "Aseguramiento de Calidad", "Inspector de Calidad", "Comisionamiento",
                            "Supervisor de Calidad", "Punch List", "Inspector de Obra",
                            "Supervisor QA/QC", "Auditor de Calidad"]},
    "C3_MECANICA": {"name": "Mecánica, Maestranza & Mantenimiento",
                    "keywords": ["Ingeniero Mecánico", "Jefe de Maestranza", "Jefe de Mantenimiento",
                                 "Planificador de Mantenimiento", "Supervisor de Mantenimiento",
                                 "Ingeniero de Mantenimiento", "Confiabilidad", "SAP PM",
                                 "Jefe de Producción", "Jefe de Planta", "Supervisor de Producción",
                                 "Mecánico de Mantenimiento"]},
    "C4_PIPING": {"name": "Piping, Montaje & Estructuras",
                  "keywords": ["Piping", "Ingeniero de Tuberías", "Diseñador de Piping",
                               "Supervisor de Piping", "Montaje Mecánico", "Estructuras",
                               "Soldadura", "ASME", "GLP", "Sistemas de Bombeo",
                               "Tuberías", "Montaje", "Bombas"]},
    "C5_AGUA": {"name": "Agua, Riles & Sanitario",
                "keywords": ["Agua Potable", "Riles", "Alcantarillado", "Sanitario", "Hidráulica",
                             "Ingeniero Hidráulico", "Planta de Agua", "PTAS", "PTAR",
                             "Sistema de Riego", "Riego", "Plantas de Tratamiento",
                             "Operador de PTAR"]},
}

# Títulos que descartan la oferta (comparación sin tildes y por palabra completa).
BLACKLIST_WORDS = [
    "ver más", "ver detalle", "ver oferta", "ver todas", "postular", "educadora", "párvulo",
    "cajero", "practicante", "trainee", "junior", "pasante", "auxiliar",
]

# Peso de cada término si aparece en el título (en el snippet vale la mitad).
KEYWORDS_SCORE_BOOST = {
    "ito": 8, "inspector": 8, "contrato": 8, "contratos": 8, "project manager": 10,
    "mecanico": 8, "sec": 5, "sap": 6, "nfpa": 5, "glp": 5, "mineria": 5,
    "energia": 4, "codelco": 4, "bhp": 4,
    "piping": 8, "tuberias": 6, "mantenimiento": 6, "planificador": 6,
    "maestranza": 6, "agua": 5, "riles": 6, "sanitario": 4, "hidraulica": 5,
    "bombeo": 5, "calidad": 4, "comisionamiento": 5,
}
BASE_SCORE = 40
MAX_BOOST = 33
MAX_SCORE = 98
VALID_STATES = ("PENDING", "APPLIED", "INTERVIEW", "REJECTED", "DISCARDED")


@dataclass(frozen=True)
class Paths:
    base: Path
    data: Path
    registry: Path
    database: Path
    html: Path
    debug: Path

    @classmethod
    def from_base(cls, base: Path, html_name: str = "dashboard_interactivo.html") -> "Paths":
        data = base / "data"
        return cls(base, data, data / "applied_registry.json", data / "jobs_database.json",
                   base / html_name, data / "debug")


# ---------------------------------------------------------------------------
# MODELO
# ---------------------------------------------------------------------------
@dataclass
class JobOffer:
    id: str
    portal: str
    titulo: str
    empresa: str
    ubicacion: str
    url: str
    cluster_id: str
    cluster_name: str
    score: int
    fecha_deteccion: str
    fecha_publicacion: str
    frescura: str
    snippet: str
    estado: str = "PENDING"
    fecha_postulacion: Optional[str] = None
    notas: str = ""
    ultima_vez: str = ""
    nueva: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# ---------------------------------------------------------------------------
# UTILIDADES DE TEXTO
# ---------------------------------------------------------------------------
def norm(text: str) -> str:
    """Minúsculas y sin tildes, para comparar 'Mecánico' con 'mecanico'."""
    decomposed = unicodedata.normalize("NFKD", text or "")
    return "".join(c for c in decomposed if not unicodedata.combining(c)).lower()


def has_term(term: str, text_norm: str) -> bool:
    """Coincidencia por palabra completa ('ito' no coincide con 'bonito')."""
    return re.search(r"(?<!\w)" + re.escape(norm(term)) + r"(?!\w)", text_norm) is not None


def clean_text(raw_html: str) -> str:
    if not raw_html:
        return ""
    text = re.sub(r"<[^>]+>", " ", raw_html)
    text = html.unescape(text)
    return re.sub(r"\s+", " ", text).strip()


def clean_title(raw_html: str) -> str:
    """Primera línea de texto del ancla (el cargo), sin empresa/ubicación que vengan debajo."""
    if not raw_html:
        return ""
    text = re.sub(r"</?(?:br|p|div|h[1-6]|li)\b[^>]*>", "\n", raw_html, flags=re.I)
    text = html.unescape(re.sub(r"<[^>]+>", " ", text))
    for line in text.splitlines():
        line = re.sub(r"\s+", " ", line).strip()
        if line:
            return line
    return ""


def is_valid_title(title: str) -> bool:
    t = norm(title).strip()
    if len(t) < 6:
        return False
    return not any(has_term(bad, t) for bad in BLACKLIST_WORDS)


def canonical_url(url: str) -> str:
    """Quita parámetros de tracking y fragmentos; Indeed se reduce a /viewjob?jk=ID."""
    p = urllib.parse.urlsplit(url.strip())
    netloc = p.netloc.lower()
    if "indeed." in netloc:
        jk = urllib.parse.parse_qs(p.query).get("jk", [""])[0]
        if jk:
            return f"{p.scheme}://{netloc}/viewjob?jk={jk}"
    return urllib.parse.urlunsplit((p.scheme, netloc, p.path.rstrip("/") or "/", "", ""))


def generate_offer_id(url: str, portal: str) -> str:
    key = canonical_url(url).lower()
    return f"{portal[:2].lower()}_{hashlib.md5(key.encode('utf-8')).hexdigest()[:12]}"


# ---------------------------------------------------------------------------
# SCORING
# ---------------------------------------------------------------------------
def calculate_match_score(title: str, snippet: str, cluster_key: str) -> int:
    """0-98. Un título irrelevante queda en ~40; uno que calza con el cluster supera 65."""
    t, s = norm(title), norm(snippet)
    keywords = CLUSTERS[cluster_key]["keywords"]
    score = BASE_SCORE
    if any(has_term(k, t) for k in keywords):
        score += 25
    elif any(has_term(k, s) for k in keywords):
        score += 10
    boost = 0
    for kw, weight in KEYWORDS_SCORE_BOOST.items():
        if has_term(kw, t):
            boost += weight
        elif has_term(kw, s):
            boost += weight // 2
    score += min(boost, MAX_BOOST)
    return max(0, min(score, MAX_SCORE))


def classify(title: str, snippet: str, hint_cluster: str) -> Tuple[str, int]:
    """Cluster que mejor calza con el título (empata a favor del cluster consultado)."""
    scores = {k: calculate_match_score(title, snippet, k) for k in CLUSTERS}
    best = max(scores.values())
    if scores[hint_cluster] == best:
        return hint_cluster, best
    return next(k for k, v in scores.items() if v == best), best


# ---------------------------------------------------------------------------
# PERSISTENCIA
# ---------------------------------------------------------------------------
class JsonStore:
    """JSON en disco con escritura atómica y recuperación si el archivo está corrupto."""

    def __init__(self, filepath: Path):
        self.filepath = Path(filepath)
        self.records: Dict[str, Any] = {}
        self.load()

    def load(self) -> None:
        self.records = {}
        if not self.filepath.exists():
            return
        try:
            with open(self.filepath, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, dict):
                raise ValueError("se esperaba un objeto JSON")
            self.records = data
        except (json.JSONDecodeError, ValueError, OSError) as e:
            backup = self.filepath.with_suffix(".corrupt.json")
            log.error("No pude leer %s (%s). Respaldo en %s", self.filepath.name, e, backup.name)
            try:
                os.replace(self.filepath, backup)
            except OSError:
                pass

    def save(self) -> None:
        self.filepath.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.filepath.with_suffix(self.filepath.suffix + ".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self.records, f, indent=2, ensure_ascii=False)
        os.replace(tmp, self.filepath)


class JobRegistry(JsonStore):
    """Estado de postulación por oferta (lo que tú marcas)."""

    def get_status(self, offer_id: str) -> str:
        return self.records.get(offer_id, {}).get("estado", "PENDING")

    def set_status(self, offer_id: str, estado: str, nota: str = "",
                   today: Optional[dt.date] = None) -> None:
        estado = estado.upper()
        if estado not in VALID_STATES:
            raise ValueError(f"Estado inválido '{estado}'. Usa: {', '.join(VALID_STATES)}")
        rec = self.records.setdefault(offer_id, {})
        rec["estado"] = estado
        if estado == "APPLIED":
            rec["fecha_postulacion"] = (today or dt.date.today()).isoformat()
        if nota:
            rec["notas"] = nota
        self.save()


def merge_offers(db: JsonStore, offers: Sequence[JobOffer], today: dt.date) -> int:
    """Une las ofertas al histórico. Devuelve cuántas son nuevas."""
    new = 0
    for o in offers:
        prev = db.records.get(o.id)
        if prev:
            o.fecha_deteccion = prev.get("fecha_deteccion", o.fecha_deteccion)
            o.nueva = False
        else:
            o.nueva = True
            new += 1
        o.ultima_vez = today.isoformat()
        db.records[o.id] = o.to_dict()
    db.save()
    return new


def dashboard_rows(db: JsonStore, registry: JobRegistry, days: int, today: dt.date) -> List[Dict[str, Any]]:
    cutoff = (today - dt.timedelta(days=days)).isoformat()
    rows = []
    for oid, rec in db.records.items():
        if rec.get("ultima_vez", "") < cutoff:
            continue
        row = dict(rec)
        row["estado"] = registry.get_status(oid)
        rows.append(row)
    rows.sort(key=lambda r: (-int(r.get("score", 0)), r.get("titulo", "")))
    return rows


# ---------------------------------------------------------------------------
# PORTALES Y EXTRACCIÓN
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class Portal:
    name: str
    base_url: str
    search_url: str                 # admite {query} (url-encoded) y {slug} (con-guiones)
    link_patterns: Tuple[str, ...]  # regex que debe cumplir el link de una oferta
    needs_browser: bool = False

    def build_url(self, query: str) -> str:
        slug = re.sub(r"[^a-z0-9]+", "-", norm(query)).strip("-")
        return (self.search_url.replace("{query}", urllib.parse.quote_plus(query))
                .replace("{slug}", slug))

    def matches(self, url: str) -> bool:
        return any(re.search(p, url) for p in self.link_patterns)


# Nota: las URLs de búsqueda y patrones de Trabajando/Laborum vienen del script original y
# no pude verificarlas contra los sitios reales. Si un portal devuelve 0 ofertas, corre con
# --debug-html y ajusta search_url/link_patterns según el HTML guardado en data/debug/.
PORTALS: Dict[str, Portal] = {
    "ChileTrabajos": Portal(
        "ChileTrabajos", "https://www.chiletrabajos.cl",
        "https://www.chiletrabajos.cl/encuentra-un-empleo/?2={query}&filterSearch=Buscar",
        (r"chiletrabajos\.cl/trabajo/",)),
    "Trabajando": Portal(
        "Trabajando", "https://www.trabajando.cl",
        "https://www.trabajando.cl/trabajo-empleo/{slug}",
        (r"/oferta/", r"/trabajo-empleo/.+-\d+"), needs_browser=True),
    "Indeed": Portal(
        "Indeed", "https://cl.indeed.com",
        "https://cl.indeed.com/jobs?q={query}&l=Chile",
        (r"indeed\.com/(?:rc/clk|viewjob|pagead/clk)",), needs_browser=True),
    "Laborum": Portal(
        "Laborum", "https://www.laborum.cl",
        "https://www.laborum.cl/empleos-busqueda-{slug}.html",
        (r"laborum\.cl/empleos/.+", r"/oferta/"), needs_browser=True),
}

ANCHOR_RE = re.compile(r'<a\b[^>]*?\bhref\s*=\s*["\']([^"\']+)["\'][^>]*>(.*?)</a>', re.I | re.S)
DATE_ABS_RE = re.compile(r"\b(\d{1,2})[/-](\d{1,2})(?:[/-](\d{2,4}))?\b")
DATE_REL_RE = re.compile(r"\b(?:hace\s+)?(\d{1,3})\s+d[ií]as?\b")
DATE_MONTH_RE = re.compile(
    r"\b(\d{1,2})\s+de\s+"
    r"(enero|febrero|marzo|abril|mayo|junio|julio|agosto|septiembre|setiembre|octubre|noviembre|diciembre)"
    r"(?:\s+de\s+(\d{4}))?\b"
)
MONTHS_ES = {
    "enero": 1, "febrero": 2, "marzo": 3, "abril": 4, "mayo": 5, "junio": 6,
    "julio": 7, "agosto": 8, "septiembre": 9, "setiembre": 9, "octubre": 10,
    "noviembre": 11, "diciembre": 12,
}


def parse_publish_date(text: str, today: Optional[dt.date] = None) -> Tuple[str, str]:
    """Devuelve (fecha_publicacion, frescura) desde texto visible cercano a una oferta."""
    today = today or dt.date.today()
    text_n = norm(clean_text(text))
    if not text_n:
        return "N/D", "N/D"
    if re.search(r"\b(hoy|publicado hoy|reciente)\b", text_n):
        return today.isoformat(), "hoy"
    if re.search(r"\bayer\b", text_n):
        d = today - dt.timedelta(days=1)
        return d.isoformat(), "1 día"
    m = DATE_REL_RE.search(text_n)
    if m:
        days = int(m.group(1))
        d = today - dt.timedelta(days=days)
        return d.isoformat(), f"{days} días"
    m = DATE_MONTH_RE.search(text_n)
    if m:
        day = int(m.group(1))
        month = MONTHS_ES[m.group(2)]
        year = int(m.group(3) or today.year)
        try:
            d = dt.date(year, month, day)
            return d.isoformat(), f"{max((today - d).days, 0)} días"
        except ValueError:
            pass
    for m in DATE_ABS_RE.finditer(text_n):
        day, month = int(m.group(1)), int(m.group(2))
        year_s = m.group(3)
        year = today.year if not year_s else int(year_s)
        if year < 100:
            year += 2000
        try:
            d = dt.date(year, month, day)
            if dt.date(2020, 1, 1) <= d <= today + dt.timedelta(days=30):
                return d.isoformat(), f"{max((today - d).days, 0)} días"
        except ValueError:
            continue
    return "N/D", "N/D"


def extract_offers(portal: Portal, page_html: str, query: str, cluster_key: str,
                   max_items: int = 8, today: Optional[dt.date] = None) -> List[JobOffer]:
    """Convierte el HTML de una página de resultados en ofertas (función pura, testeable)."""
    today_s = (today or dt.date.today()).isoformat()
    found: Dict[str, JobOffer] = {}
    for match in ANCHOR_RE.finditer(page_html or ""):
        href, inner = match.groups()
        href = html.unescape(href).strip()
        if href.startswith(("#", "javascript:", "mailto:")):
            continue
        full = urllib.parse.urljoin(portal.base_url + "/", href)
        if not portal.matches(full):
            continue
        title = clean_title(inner)
        if not is_valid_title(title):
            continue
        url = canonical_url(full)
        oid = generate_offer_id(url, portal.name)
        cid, score = classify(title, "", cluster_key)
        context = inner + " " + (page_html[match.end():match.end() + 900] if page_html else "")
        published, freshness = parse_publish_date(context, today or dt.date.today())
        offer = JobOffer(
            id=oid, portal=portal.name, titulo=title, empresa="N/D", ubicacion="Chile", url=url,
            cluster_id=cid, cluster_name=CLUSTERS[cid]["name"], score=score,
            fecha_deteccion=today_s, fecha_publicacion=published, frescura=freshness,
            snippet=f"Detectada en {portal.name} (búsqueda: {query})",
        )
        prev = found.get(oid)
        if prev is None or len(title) > len(prev.titulo):  # varias anclas por oferta: gana el título más completo
            found[oid] = offer
    ranked = sorted(found.values(), key=lambda o: (-o.score, o.titulo))
    return ranked[:max_items]


# ---------------------------------------------------------------------------
# DESCARGA
# ---------------------------------------------------------------------------
_COOKIES = http.cookiejar.CookieJar()
_OPENER = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(_COOKIES))


def fetch_html(url: str, timeout: int = 15, retries: int = 2) -> str:
    """GET con reintentos. Devuelve '' si falla (y deja el motivo en el log)."""
    headers = {
        "User-Agent": random.choice(USER_AGENTS),
        "Accept": "text/html,application/xhtml+xml",
        "Accept-Language": "es-CL,es;q=0.9",
        "Referer": "https://www.google.com/",
    }
    for attempt in range(retries + 1):
        try:
            req = urllib.request.Request(url, headers=headers)
            with _OPENER.open(req, timeout=timeout) as resp:
                charset = resp.headers.get_content_charset() or "utf-8"
                return resp.read().decode(charset, errors="replace")
        except urllib.error.HTTPError as e:
            log.warning("HTTP %s en %s", e.code, url)
            if 400 <= e.code < 500 and e.code != 429:
                return ""  # reintentar un 403/404 no sirve
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            log.warning("Error de red en %s: %s", url, e)
        if attempt < retries:
            time.sleep(1.5 * (attempt + 1))
    return ""


class BrowserFetcher:
    """Un solo Chromium compartido para todas las consultas (el original abría uno por consulta)."""

    def __init__(self, wait_ms: int = 2500, nav_timeout_ms: int = 30000):
        self.wait_ms = wait_ms
        self.nav_timeout_ms = nav_timeout_ms
        self._pw = self._browser = self._ctx = None

    async def __aenter__(self) -> "BrowserFetcher":
        if not HAS_PLAYWRIGHT:
            raise RuntimeError("Playwright no está instalado (pip install playwright)")
        self._pw = await async_playwright().start()
        try:
            self._browser = await self._pw.chromium.launch(headless=True)
        except Exception:
            await self._pw.stop()
            raise
        self._ctx = await self._browser.new_context(user_agent=USER_AGENTS[0], locale="es-CL")
        return self

    async def get(self, url: str) -> str:
        page = await self._ctx.new_page()
        try:
            await page.goto(url, wait_until="domcontentloaded", timeout=self.nav_timeout_ms)
            await page.wait_for_timeout(self.wait_ms)
            return await page.content()
        except Exception as e:
            log.warning("Playwright falló en %s: %s", url, e)
            return ""
        finally:
            await page.close()

    async def __aexit__(self, *exc) -> None:
        for closer in (self._ctx, self._browser):
            try:
                if closer:
                    await closer.close()
            except Exception:
                pass
        if self._pw:
            await self._pw.stop()


# ---------------------------------------------------------------------------
# DASHBOARD
# ---------------------------------------------------------------------------
DASHBOARD_TEMPLATE = r"""<!doctype html>
<html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Job Hunter Dashboard</title>
<style>
:root{--bg:#fff;--fg:#1d2330;--mut:#667085;--line:#e4e7ec;--acc:#2f6fed;--chip:#f2f4f7}
@media (prefers-color-scheme:dark){:root{--bg:#14171f;--fg:#e8eaf0;--mut:#98a2b3;--line:#2a2f3a;--acc:#7aa2ff;--chip:#222733}}
body{font:14px system-ui,sans-serif;background:var(--bg);color:var(--fg);margin:0;padding:20px}
h1{margin:0 0 4px;font-size:20px}#meta{color:var(--mut);margin-bottom:14px}
.bar{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:12px}
input,select{padding:6px 8px;border:1px solid var(--line);border-radius:6px;background:var(--bg);color:var(--fg)}
#q{min-width:240px}
table{border-collapse:collapse;width:100%}th,td{padding:8px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}
th{cursor:pointer;color:var(--mut);font-weight:600;white-space:nowrap}
a{color:var(--acc);text-decoration:none}a:hover{text-decoration:underline}
.score{display:inline-block;min-width:34px;text-align:center;border-radius:12px;padding:2px 8px;font-weight:600;background:var(--chip)}
.s-hi{background:#12b76a;color:#fff}.s-mid{background:#f79009;color:#fff}
.new{background:var(--acc);color:#fff;border-radius:4px;padding:1px 6px;font-size:11px;margin-left:6px}
.mut{color:var(--mut)}button{cursor:pointer;border:1px solid var(--line);background:var(--chip);color:var(--fg);border-radius:6px;padding:4px 8px}
tr.done{opacity:.55}
</style></head><body>
<h1>Job Hunter Dashboard</h1>
<div id="meta"></div>
<div class="bar">
<input id="q" placeholder="Buscar cargo, portal, cluster...">
<select id="portal"></select><select id="cluster"></select><select id="estado"></select>
<label><input type="checkbox" id="soloNuevas"> Solo nuevas</label>
<span id="count" class="mut"></span>
</div>
<table><thead><tr>
<th data-k="score">Match</th><th data-k="titulo">Cargo</th><th data-k="portal">Portal</th>
<th data-k="cluster_name">Cluster</th><th data-k="fecha_deteccion">Detectada</th><th>Estado</th><th></th>
</tr></thead><tbody id="rows"></tbody></table>
<script>
const DATA=__DATA__;const META=__META__;
const ESTADOS=["PENDING","APPLIED","INTERVIEW","REJECTED","DISCARDED"];
const $=id=>document.getElementById(id);
let local={};try{local=JSON.parse(localStorage.getItem("jh_estado")||"{}")}catch(e){}
let sortKey="score",sortDir=-1;
const estadoOf=o=>local[o.id]||o.estado;
function fill(sel,vals,label){sel.textContent="";const f=document.createElement("option");f.value="";f.textContent=label;sel.appendChild(f);
 [...new Set(vals)].sort().forEach(v=>{const o=document.createElement("option");o.value=v;o.textContent=v;sel.appendChild(o)})}
function cell(tr,child){const td=document.createElement("td");if(typeof child==="string")td.textContent=child;else td.appendChild(child);tr.appendChild(td);return td}
function render(){
 const q=$("q").value.toLowerCase(),p=$("portal").value,c=$("cluster").value,e=$("estado").value,n=$("soloNuevas").checked;
 const rows=DATA.filter(o=>(!p||o.portal===p)&&(!c||o.cluster_name===c)&&(!e||estadoOf(o)===e)&&(!n||o.nueva)
  &&(!q||(o.titulo+" "+o.portal+" "+o.cluster_name+" "+o.empresa).toLowerCase().includes(q)))
  .sort((a,b)=>(a[sortKey]>b[sortKey]?1:a[sortKey]<b[sortKey]?-1:0)*sortDir);
 const tb=$("rows");tb.textContent="";
 rows.forEach(o=>{const tr=document.createElement("tr");const est=estadoOf(o);if(est!=="PENDING")tr.className="done";
  const sc=document.createElement("span");sc.className="score "+(o.score>=80?"s-hi":o.score>=65?"s-mid":"");sc.textContent=o.score;cell(tr,sc);
  const td=document.createElement("td");
  if(/^https?:\/\//.test(o.url)){const a=document.createElement("a");a.href=o.url;a.target="_blank";a.rel="noopener noreferrer";a.textContent=o.titulo;td.appendChild(a)}
  else td.textContent=o.titulo;
  if(o.nueva){const t=document.createElement("span");t.className="new";t.textContent="NUEVA";td.appendChild(t)}
  tr.appendChild(td);cell(tr,o.portal);cell(tr,o.cluster_name);cell(tr,o.fecha_deteccion);
  const sel=document.createElement("select");ESTADOS.forEach(s=>{const op=document.createElement("option");op.value=s;op.textContent=s;if(s===est)op.selected=true;sel.appendChild(op)});
  sel.onchange=()=>{local[o.id]=sel.value;try{localStorage.setItem("jh_estado",JSON.stringify(local))}catch(x){}render()};cell(tr,sel);
  const b=document.createElement("button");b.textContent="Copiar comando";
  b.onclick=()=>{const cmd="python job_hunter.py --mark "+o.id+" "+estadoOf(o);try{navigator.clipboard.writeText(cmd)}catch(x){}b.textContent="Copiado"};
  cell(tr,b);tb.appendChild(tr)});
 $("count").textContent=rows.length+" de "+DATA.length+" ofertas";
}
$("meta").textContent="Generado "+META.generado+" · "+DATA.length+" ofertas de los últimos "+META.dias+" días · "+META.nuevas+" nuevas en la última corrida";
fill($("portal"),DATA.map(o=>o.portal),"Todos los portales");fill($("cluster"),DATA.map(o=>o.cluster_name),"Todos los clusters");
fill($("estado"),ESTADOS,"Todos los estados");
["q","portal","cluster","estado","soloNuevas"].forEach(id=>$(id).addEventListener("input",render));
document.querySelectorAll("th[data-k]").forEach(th=>th.onclick=()=>{const k=th.dataset.k;sortDir=(sortKey===k)?-sortDir:-1;sortKey=k;render()});
render();
</script></body></html>
"""


def _json_for_script(obj: Any) -> str:
    # '</' dentro de un <script> cerraría la etiqueta: se escapa (también evita inyección desde títulos)
    return json.dumps(obj, ensure_ascii=False).replace("</", "<\\/").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")


def generate_interactive_dashboard(rows: Sequence[Dict[str, Any]], output_path: Path,
                                   new_count: int = 0, days: int = 30,
                                   now: Optional[dt.datetime] = None) -> None:
    meta = {"generado": (now or dt.datetime.now()).strftime("%Y-%m-%d %H:%M"), "dias": days, "nuevas": new_count}
    page = (DASHBOARD_TEMPLATE
            .replace("__DATA__", _json_for_script(list(rows)))
            .replace("__META__", _json_for_script(meta)))
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(page, encoding="utf-8")


# ---------------------------------------------------------------------------
# ORQUESTACIÓN
# ---------------------------------------------------------------------------
def _new_stats(sources: Sequence[str]) -> Dict[str, Dict[str, int]]:
    return {s: {"consultas": 0, "errores": 0, "ofertas": 0} for s in sources}


async def collect_offers(sources: Sequence[str], queries_per_cluster: int, max_per_query: int,
                         min_score: int, http_fetch, browser, delay: Tuple[float, float],
                         debug_dir: Optional[Path], stats: Dict[str, Dict[str, int]],
                         today: Optional[dt.date] = None) -> List[JobOffer]:
    unique: Dict[str, JobOffer] = {}
    for cluster_id, info in CLUSTERS.items():
        for query in info["keywords"][:queries_per_cluster]:
            print(f"🔎 {info['name']} | {query}")
            for pname in sources:
                portal, st = PORTALS[pname], stats[pname]
                url = portal.build_url(query)
                st["consultas"] += 1
                if portal.needs_browser:
                    page_html = await browser.get(url)
                else:
                    page_html = await asyncio.to_thread(http_fetch, url)
                if not page_html:
                    st["errores"] += 1
                    continue
                if debug_dir:
                    debug_dir.mkdir(parents=True, exist_ok=True)
                    slug = re.sub(r"[^a-z0-9]+", "-", norm(query)).strip("-")
                    (debug_dir / f"{pname}_{slug}.html").write_text(page_html, encoding="utf-8")
                for offer in extract_offers(portal, page_html, query, cluster_id, max_per_query, today):
                    if offer.score < min_score:
                        continue
                    if offer.id not in unique or offer.score > unique[offer.id].score:
                        unique[offer.id] = offer
                st["ofertas"] = sum(1 for o in unique.values() if o.portal == pname)
                await asyncio.sleep(random.uniform(*delay))
    return list(unique.values())


def print_summary(stats: Dict[str, Dict[str, int]]) -> None:
    print("\nPortal           Consultas  Errores  Ofertas")
    for name, s in stats.items():
        print(f"{name:<16} {s['consultas']:>9}  {s['errores']:>7}  {s['ofertas']:>7}")
        if s["consultas"] and s["errores"] == s["consultas"]:
            print(f"   ⚠ {name}: todas las consultas fallaron (bloqueo, sin red o URL cambiada). Prueba --debug-html.")
        elif s["consultas"] and s["ofertas"] == 0:
            print(f"   ⚠ {name}: respondió pero no se detectó ninguna oferta; revisa link_patterns con --debug-html.")


async def run_job_hunter(paths: Paths, sources: Sequence[str] = tuple(PORTALS),
                         queries_per_cluster: int = 2, max_per_query: int = 5, min_score: int = 55,
                         days: int = 30, delay: Tuple[float, float] = (1.0, 2.5),
                         debug_html: bool = False, http_fetch=fetch_html,
                         browser_factory=BrowserFetcher, today: Optional[dt.date] = None) -> Dict[str, Any]:
    today = today or dt.date.today()
    paths.data.mkdir(parents=True, exist_ok=True)
    registry, db = JobRegistry(paths.registry), JsonStore(paths.database)
    sources = [s for s in sources if s in PORTALS]
    stats = _new_stats(sources)
    needs_browser = any(PORTALS[s].needs_browser for s in sources)

    async def _run(browser) -> List[JobOffer]:
        return await collect_offers(sources, queries_per_cluster, max_per_query, min_score, http_fetch,
                                    browser, delay, paths.debug if debug_html else None, stats, today)

    offers: List[JobOffer] = []
    if needs_browser:
        try:
            async with browser_factory() as browser:
                offers = await _run(browser)
        except Exception as e:
            log.error("No pude iniciar el navegador (%s). Instala con: python -m playwright install chromium", e)
            http_only = [s for s in sources if not PORTALS[s].needs_browser]
            print(f"⚠ Continuando solo con: {', '.join(http_only) or 'ningún portal'}")
            sources = http_only
            stats = {s: stats[s] for s in sources}
            if sources:
                offers = await collect_offers(sources, queries_per_cluster, max_per_query, min_score,
                                              http_fetch, None, delay,
                                              paths.debug if debug_html else None, stats, today)
    else:
        offers = await _run(None)

    for o in offers:
        o.estado = registry.get_status(o.id)
    new_count = merge_offers(db, offers, today)
    rows = dashboard_rows(db, registry, days, today)
    generate_interactive_dashboard(rows, paths.html, new_count, days)

    print_summary(stats)
    print(f"\n✅ {len(offers)} ofertas esta corrida ({new_count} nuevas). Histórico: {len(db.records)}. Dashboard: {paths.html}")
    return {"offers": offers, "new": new_count, "stats": stats, "dashboard_rows": len(rows)}


# ---------------------------------------------------------------------------
# OPEN-APPLY — abre pestañas de postulación en el navegador
# ---------------------------------------------------------------------------

# Portales con soporte para construir la URL de postulación directa a partir
# de la URL almacenada. Clave: nombre del portal; valor: función (url) -> apply_url | None.
_APPLY_URL_BUILDERS: Dict[str, Any] = {}


def _chiletrabajos_apply_url(url: str) -> Optional[str]:
    """
    Extrae el ID numérico del slug y devuelve la URL de postulación.

    Ejemplo:
      https://www.chiletrabajos.cl/trabajo/project-manager-3897573
      → https://www.chiletrabajos.cl/trabajo/postular/3897573
    """
    m = re.search(r"-(\d{4,})(?:/)?$", url)
    if not m:
        # Intento alternativo: último segmento puramente numérico
        m = re.search(r"/(\d{4,})(?:/)?$", url)
    if not m:
        return None
    job_id = m.group(1)
    return f"https://www.chiletrabajos.cl/trabajo/postular/{job_id}"


_APPLY_URL_BUILDERS["ChileTrabajos"] = _chiletrabajos_apply_url


def open_apply_tabs(
    db_path: Path,
    registry_path: Path,
    *,
    min_score: int = 60,
    limit: int = 5,
    portals: Optional[Sequence[str]] = None,
    delay: float = 1.5,
    dry_run: bool = False,
    estado_filter: str = "PENDING",
    max_age_days: int = 0,
) -> int:
    """
    Lee jobs_database.json, filtra las ofertas con soporte de URL de postulación
    y abre cada una en el navegador por defecto con un pequeño retardo.

    Parámetros
    ----------
    db_path        : ruta a jobs_database.json
    registry_path  : ruta a applied_registry.json (para leer estado actualizado)
    min_score      : score mínimo para abrir (default 60)
    limit          : máximo de pestañas a abrir (default 5, seguridad)
    portals        : lista de portales a considerar; None = todos los soportados
    delay          : segundos entre tabs (default 1.5)
    dry_run        : si True, imprime las URLs sin abrirlas
    estado_filter  : solo ofertas con este estado (default "PENDING")

    Retorna el número de pestañas abiertas (o que se abrirían en dry_run).
    """
    if not db_path.exists():
        print(f"Error: no existe {db_path}. Corre primero: python job_hunter.py", file=sys.stderr)
        return 0

    try:
        with open(db_path, "r", encoding="utf-8") as f:
            db: Dict[str, Any] = json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        print(f"Error leyendo {db_path}: {e}", file=sys.stderr)
        return 0

    # Carga el registro de estado (puede no existir)
    registry_states: Dict[str, str] = {}
    if registry_path.exists():
        try:
            with open(registry_path, "r", encoding="utf-8") as f:
                reg = json.load(f)
            registry_states = {k: v.get("estado", "PENDING") for k, v in reg.items() if isinstance(v, dict)}
        except (json.JSONDecodeError, OSError):
            pass

    supported = set(_APPLY_URL_BUILDERS) if portals is None else set(portals) & set(_APPLY_URL_BUILDERS)

    # Filtra y ordena
    candidates = []
    for oid, offer in db.items():
        portal = offer.get("portal", "")
        if portal not in supported:
            continue
        estado = registry_states.get(oid) or offer.get("estado", "PENDING")
        if estado != estado_filter:
            continue
        score = int(offer.get("score", 0))
        if score < min_score:
            continue
        apply_url = _APPLY_URL_BUILDERS[portal](offer.get("url", ""))
        if not apply_url:
            log.warning("No pude construir URL de postulacion para %s (%s)", oid, offer.get("url"))
            continue
        candidates.append((score, offer.get("ultima_vez", ""), oid, offer, apply_url))

    if max_age_days > 0:
        cutoff = dt.date.today() - dt.timedelta(days=max_age_days)
        recent = []
        for row in candidates:
            date_s = str(row[3].get("fecha_publicacion") or row[3].get("fecha_deteccion") or "")[:10]
            try:
                if dt.date.fromisoformat(date_s) >= cutoff:
                    recent.append(row)
            except ValueError:
                continue
        candidates = recent

    # Fecha de publicación primero (más recientes), luego score (orden estable)
    candidates.sort(key=lambda r: -r[0])
    candidates.sort(
        key=lambda r: str(r[3].get("fecha_publicacion") or r[3].get("fecha_deteccion") or ""),
        reverse=True,
    )
    candidates = candidates[:limit]

    if not candidates:
        print(
            f"No hay ofertas {estado_filter} con score >= {min_score} en portales soportados "
            f"({', '.join(sorted(supported))}).\n"
            "Prueba: python job_hunter.py --open-apply --min-score 0"
        )
        return 0

    prefix = "[dry-run]" if dry_run else "Abriendo"
    print(f"\n{prefix} {len(candidates)} pestana(s) de postulacion:\n")
    print(f"  {'Score':>5}  {'Portal':<14}  {'ID':<18}  URL de postulacion")
    print(f"  {'─'*5}  {'─'*14}  {'─'*18}  {'─'*50}")

    opened = 0
    for score, _, oid, offer, apply_url in candidates:
        titulo = str(offer.get("titulo", ""))[:60]
        print(f"  {score:>5}  {str(offer.get('portal', '')):<14}  {oid:<18}  {apply_url}")
        print(f"         -> {titulo}")
        if not dry_run:
            try:
                webbrowser.open(apply_url)
            except Exception as e:
                print(f"    Aviso: no pude abrir {apply_url}: {e}", file=sys.stderr)
                continue
            if delay > 0 and opened < len(candidates) - 1:
                time.sleep(delay)
        opened += 1

    action = "se abririan" if dry_run else "abiertas"
    print(f"\n{opened} pestana(s) {action}.")
    if not dry_run:
        print("  Completa la postulacion en el navegador.")
        print("  Cuando termines: python job_hunter.py --mark <ID> APPLIED")
    return opened


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Job Hunter Pro: busca, puntúa y organiza ofertas de empleo.")
    p.add_argument("--quick", action="store_true", help="1 consulta por cluster (rápido)")
    p.add_argument("--queries-per-cluster", type=int, default=2,
                   help="Cuántas keywords consultar por cluster (default 2; --quick fuerza 1)")
    p.add_argument("--sources", default=",".join(PORTALS), help=f"Portales separados por coma: {', '.join(PORTALS)}")
    p.add_argument("--max-per-query", type=int, default=5)
    p.add_argument("--min-score", type=int, default=55, help="Descarta ofertas bajo este puntaje (default 55)")
    p.add_argument("--days", type=int, default=30, help="Días de histórico visibles en el dashboard")
    p.add_argument("--output", type=Path, default=None, help="Ruta del dashboard HTML")
    p.add_argument("--no-open", action="store_true", help="No abrir el dashboard al terminar")
    p.add_argument("--no-browser", action="store_true", help="Omitir portales que requieren Playwright")
    p.add_argument("--debug-html", action="store_true", help="Guardar el HTML crudo en data/debug/")
    p.add_argument("--mark", nargs=2, metavar=("ID", "ESTADO"), help=f"Cambiar estado de una oferta ({'/'.join(VALID_STATES)})")
    p.add_argument("--nota", default="", help="Nota para --mark")
    # ---- open-apply ----
    p.add_argument("--open-apply", action="store_true",
                   help="Abre pestañas del navegador en la sección 'Postular' de cada oferta PENDING")
    p.add_argument("--open-apply-limit", type=int, default=5, metavar="N",
                   help="Máximo de pestañas a abrir (default 5)")
    p.add_argument("--open-apply-min-score", type=int, default=60, metavar="SCORE",
                   help="Score mínimo para abrir (default 60)")
    p.add_argument("--open-apply-delay", type=float, default=1.5, metavar="SEG",
                   help="Segundos entre pestañas (default 1.5)")
    p.add_argument("--open-apply-max-age-days", type=int, default=0, metavar="N",
                   help="Solo ofertas publicadas en los últimos N días (0 = sin filtro)")
    p.add_argument("--open-apply-dry-run", action="store_true",
                   help="Muestra las URLs sin abrirlas")
    p.add_argument("-v", "--verbose", action="store_true")
    return p.parse_args(argv)



def main(argv: Optional[Sequence[str]] = None) -> int:
    if sys.platform.startswith("win"):
        for stream in (sys.stdout, sys.stderr):
            try:
                stream.reconfigure(encoding="utf-8", errors="replace")
            except Exception:
                pass
    args = parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.WARNING,
                        format="%(levelname)s %(message)s")
    paths = Paths.from_base(BASE_DIR)
    if args.output:
        paths = Paths(paths.base, paths.data, paths.registry, paths.database, args.output, paths.debug)

    if args.mark:
        offer_id, estado = args.mark
        registry = JobRegistry(paths.registry)
        try:
            registry.set_status(offer_id, estado, args.nota)
        except ValueError as e:
            print(f"Error: {e}", file=sys.stderr)
            return 2
        print(f"✔ {offer_id} → {estado.upper()}")
        return 0

    if args.open_apply:
        open_apply_tabs(
            db_path=paths.database,
            registry_path=paths.registry,
            min_score=args.open_apply_min_score,
            limit=args.open_apply_limit,
            delay=args.open_apply_delay,
            dry_run=args.open_apply_dry_run,
            max_age_days=args.open_apply_max_age_days,
        )
        return 0

    sources = [s.strip() for s in args.sources.split(",") if s.strip()]
    unknown = [s for s in sources if s not in PORTALS]
    if unknown:
        print(f"Error: portales desconocidos: {', '.join(unknown)}. Disponibles: {', '.join(PORTALS)}", file=sys.stderr)
        return 2
    if args.no_browser:
        sources = [s for s in sources if not PORTALS[s].needs_browser]
    if not sources:
        print("Error: no hay portales para consultar.", file=sys.stderr)
        return 2

    result = asyncio.run(run_job_hunter(
        paths, sources, queries_per_cluster=1 if args.quick else max(1, args.queries_per_cluster),
        max_per_query=args.max_per_query, min_score=args.min_score, days=args.days,
        debug_html=args.debug_html))

    total_requests = sum(s["consultas"] for s in result["stats"].values())
    total_errors = sum(s["errores"] for s in result["stats"].values())
    if total_requests and total_errors == total_requests:
        print("Error: todas las consultas fallaron; revisa tu conexión.", file=sys.stderr)
        return 1

    if not args.no_open:
        try:
            webbrowser.open(paths.html.resolve().as_uri())
            print(f"🚀 Dashboard abierto en: {paths.html}")
        except Exception as e:
            print(f"No pude abrir el dashboard automáticamente: {e}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
