---
offer_id: "ch_f24e4cd7dd0b"
offer_key: "3879326"
portal: "ChileTrabajos"
title: "JEFE DE MANTENIMIENTO 5 REGION"
company: "CONFIDENCIAL"
location: "Valparaíso"
published: "07 de Agosto de 2026"
score_legacy: "71"
cluster_id: "C3_MECANICA"
cluster_name: "Mecánica, Maestranza & Mantenimiento"
url: "https://www.chiletrabajos.cl/trabajo/jefe-de-mantenimiento-5-region-3879326"
apply_url: "https://www.chiletrabajos.cl/trabajo/postular/3879326"
tags: ["mantenimiento", "equipos", "jefe"]
salary_text: ""
fetched_at: "2026-10-21T04:15:45"
fetch_status: "ok"
error: ""
---

# JEFE DE MANTENIMIENTO 5 REGION

- Empresa: CONFIDENCIAL
- Ubicacion: Valparaíso
- Publicado: 07 de Agosto de 2026
- Score legacy: 71
- Cluster: Mecánica, Maestranza & Mantenimiento
- Tags: mantenimiento, equipos, jefe

## Descripcion

Jefe de Mantenimiento – División Minería (Empresa Confidencial)

Una importante empresa prestadora de servicios para la minería se encuentra en búsqueda de un(a) Jefe de Mantenimiento, quien será responsable de liderar la estrategia de mantenimiento de la flota y activos de la compañía, asegurando su disponibilidad, confiabilidad y continuidad operacional.

Buscamos un profesional con una mirada técnica y de gestión, capaz de liderar equipos, optimizar recursos y promover una cultura de mejora continua, seguridad y excelencia operacional.

¿Cuáles serán tus principales desafíos?

Liderar la planificación y ejecución del mantenimiento preventivo, correctivo y predictivo de la flota y activos.

Administrar y desarrollar al equipo de mantenimiento, promoviendo altos estándares técnicos y de seguridad.

Gestionar indicadores de mantenimiento, disponibilidad, confiabilidad, costos y cumplimiento de planes, impulsando acciones de mejora.

Coordinar la relación con talleres externos, proveedores y contratos asociados al mantenimiento.

Participar en la elaboración y control del presupuesto del área, optimizando recursos y costos del ciclo de vida de los activos.

Liderar investigaciones de fallas y análisis de causa raíz para implementar soluciones que eviten recurrencias.

Promover iniciativas de mejora continua, fortaleciendo la eficiencia operacional y la confiabilidad de los equipos.

Mantener una coordinación permanente con Operaciones y las distintas áreas de soporte para asegurar la continuidad del servicio.

¿Qué buscamos?

Título profesional de Ingeniería Civil Mecánica, Ingeniería Mecánica Automotriz, Ingeniería en Mantenimiento Industrial o carrera afín.

Al menos 5 años de experiencia liderando áreas de mantenimiento, idealmente en flotas de equipos móviles, servicios industriales o minería.

Experiencia en planificación de mantenimiento, análisis de indicadores, gestión presupuestaria y liderazgo de equipos.

Manejo de herramientas Office y sistemas de gestión de mantenimiento (deseable Fracttal o similares).

Valoraremos especialmente

Liderazgo técnico.

Capacidad de planificación y organización.

Orientación a resultados y mejora continua.

Resolución de problemas.

Comunicación efectiva y trabajo colaborativo.

Capacidad para desenvolverse en entornos de alta exigencia operacional.
