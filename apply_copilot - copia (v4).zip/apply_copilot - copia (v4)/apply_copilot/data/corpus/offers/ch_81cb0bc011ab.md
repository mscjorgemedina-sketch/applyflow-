---
offer_id: "ch_81cb0bc011ab"
offer_key: "3892089"
portal: "ChileTrabajos"
title: "ITO Civil - Santiago Centro"
company: "DFV Ingeniería"
location: "Santiago"
published: "01 de Septiembre de 2026"
score_legacy: "73"
cluster_id: "C2_ITO"
cluster_name: "ITO & Aseguramiento de Calidad"
url: "https://www.chiletrabajos.cl/trabajo/ito-civil-santiago-centro-3892089"
apply_url: "https://www.chiletrabajos.cl/trabajo/postular/3892089"
tags: ["proyecto", "santiago", "terminaciones"]
salary_text: ""
fetched_at: "2026-10-21T04:15:12"
fetch_status: "ok"
error: ""
---

# ITO Civil - Santiago Centro

- Empresa: DFV Ingeniería
- Ubicacion: Santiago
- Publicado: 01 de Septiembre de 2026
- Score legacy: 73
- Cluster: ITO & Aseguramiento de Calidad
- Tags: proyecto, santiago, terminaciones

## Descripcion

En DFV Ingeniería y Gestión buscamos un ITO para proyecto de edificación en altura en Santiago Centro, quien será responsable de realizar la inspección técnica y supervisión de las obras durante la etapa de terminaciones, velando por el cumplimiento de los estándares de calidad, especificaciones técnicas, planos y procedimientos constructivos definidos para el proyecto.

Modalidad: Presencial, Santiago Centro.

Jornada: Full time

Funciones:

Supervisar en terreno la correcta ejecución de las partidas de terminaciones interiores y exteriores.

Inspeccionar partidas de revestimientos, pavimentos, pinturas, cielos, tabiquería, puertas, ventanas, quincallería, muebles, artefactos sanitarios y otras terminaciones.

Verificar que los trabajos se ejecuten de acuerdo con planos, especificaciones técnicas, detalles constructivos y estándares definidos por el proyecto.

Controlar la calidad de los materiales y de las partidas ejecutadas, detectando oportunamente defectos, interferencias o incumplimientos.

Generar observaciones y realizar seguimiento hasta su correcta solución.

Revisar y controlar los procedimientos constructivos utilizados por las empresas contratistas.

Verificar la correcta preparación de superficies, instalación, fijaciones, sellos, encuentros y terminaciones.

Coordinar en terreno la ejecución de las distintas especialidades, identificando y reportando oportunamente posibles interferencias.

Supervisar diariamente el avance físico de las partidas y compararlo con la programación de obra.

Realizar inspecciones y recepciones parciales de los trabajos ejecutados.

Elaborar y controlar listas de observaciones (punch list), realizando seguimiento hasta su levantamiento.

Revisar planos, especificaciones técnicas, fichas de productos y antecedentes del proyecto.

Verificar la correcta recepción, almacenamiento y utilización de materiales de terminación.

Mantener comunicación permanente con supervisores y responsables de las empresas contratistas.

Participar en reuniones de coordinación y seguimiento de obra.

Participar en las inspecciones finales y apoyar el proceso de cierre y entrega del proyecto.

Qué buscamos en ti

Formación:

Título de Ingeniero Civil, Ingeniero Constructor, Constructor Civil o profesión afín.

Experiencia:

Al menos 8 años de experiencia profesional.

Mínimo 3 años de experiencia en proyectos de edificación.

Idealmente contar con experiencia en edificación en altura.

Experiencia comprobable en Inspección Técnica de Obras (ITO).

Conocimiento de procesos constructivos y experiencia en terreno, especialmente en etapa de terminaciones

Capacidad para interpretar planos, especificaciones técnicas y antecedentes de proyecto.

Experiencia en control de calidad, coordinación de especialidades y seguimiento de observaciones.

Lo que encontrarás:

Un entorno dinámico donde tendrás impacto directo en la operación, liderando iniciativas clave de eficiencia, transformación digital y optimización de procesos.

Si te motiva transformar la gestión de mantenimiento a través de datos, tecnología y liderazgo, este desafío es para ti.
