---
offer_id: "ch_4aa0fa1b6da9"
offer_key: "3898981"
portal: "ChileTrabajos"
title: "ITO Contract Manager / Especialista en Constratos - Servicio Inspección Técnica"
company: "DFV Ingeniería y Gestión"
location: "Santiago"
published: "15 de Septiembre de 2026"
score_legacy: "73"
cluster_id: "C1_GESTION"
cluster_name: "Gestión de Proyectos & Contratos"
url: "https://www.chiletrabajos.cl/trabajo/ito-contract-manager-especialista-en-constratos-servicio-inspeccion-tecnica-3898981"
apply_url: "https://www.chiletrabajos.cl/trabajo/postular/3898981"
tags: ["obras", "gestión", "ito"]
salary_text: ""
fetched_at: "2026-10-21T04:14:44"
fetch_status: "ok"
error: ""
---

# ITO Contract Manager / Especialista en Constratos - Servicio Inspección Técnica

- Empresa: DFV Ingeniería y Gestión
- Ubicacion: Santiago
- Publicado: 15 de Septiembre de 2026
- Score legacy: 73
- Cluster: Gestión de Proyectos & Contratos
- Tags: obras, gestión, ito

## Descripcion

En DFV Ingeniería y Gestión nos encontramos en búsqueda de un(a) ITO Contract Manager / Especialista en Contratos proyecto público en licitación Servicio de Inspección Técnica para la habilitación del Centro de Justicia de Temuco - Tribunal de Familia, Civiles 1°, 2° y 3°, Juzgado de Letras y de Familia y Juzgado de Letras del Trabajo.

El o la profesional seleccionado(a) deberá desempeñarse a tiempo completo hasta el término del contrato, con dedicación exclusiva al proyecto. Durante la etapa N° 1, hasta la entrega de terreno, deberá estar disponible para asistir a las reuniones que cite la Corporación Administrativa del Poder Judicial (CAPJ).

Objetivo del cargo: Asesorar al Mandante en la gestión estratégica y administración contractual del proyecto, estableciendo la línea base contractual y gestionando de manera proactiva los riesgos legales, técnicos y financieros asociados al contrato, entregando a la ITO y al Mandante los antecedentes necesarios para la toma oportuna de decisiones.

Funciones principales:

1. Administrar los contratos de construcción vigentes y aquellos que se suscriban para la reanudación de las obras, manteniendo un control permanente de la documentación contractual, pólizas, boletas de garantía y seguros.

2. Identificar, evaluar y gestionar los riesgos contractuales, legales, técnicos y financieros asociados al estado de las obras, proponiendo alternativas de mitigación.

3. Gestionar contractualmente la identificación, análisis y tratamiento de vicios ocultos y defectos no aparentes, proponiendo las acciones correspondientes.

4. Gestionar el proceso de revalidación de las obras existentes, incluyendo los protocolos para la aceptación o rechazo de partidas y las nuevas obligaciones contractuales del contratista.

5. Realizar el control y gestión de órdenes de cambio, obras extraordinarias y extensiones de plazo, preparando los antecedentes y fundamentos necesarios para la toma de decisiones.

6. Establecer y mantener un sistema de control que permita relacionar el estado inicial de la obra con las nuevas obligaciones contractuales, registrando daños, vicios y faenas inconclusas.

7. Preparar y fundamentar informes, minutas y presentaciones para la ITO, el Mandante (CAPJ) y las instancias correspondientes.

8. Anticipar, gestionar y preparar respuestas frente a reclamaciones del contratista, recopilando los antecedentes necesarios para la resolución de controversias.

9. Participar en las reuniones técnicas, legales y administrativas que sean requeridas para la adecuada gestión del contrato.

10. Coordinar permanentemente su gestión con el Supervisor y el ITO Residente, asegurando una supervisión y administración contractual continua.

Requisitos:

• El profesional deberá contar con título profesional de Ingeniero Constructor, Constructor Civil, Ingeniero Civil o Ingeniero Civil en Obras Civiles, obtenido en una Universidad o Instituto Profesional autorizado de acuerdo con la normativa legal vigente.

• 10 años de experiencia profesional desde titulación efectiva.

• El o la candidato(a) deberá acreditar experiencia en la gestión, administración o especialización en contratos para proyectos de construcción, incluyendo funciones asociadas a la administración contractual, control de riesgos, modificaciones de contrato, obras extraordinarias, extensiones de plazo y/o gestión de reclamaciones.

• La experiencia deberá acreditarse mediante certificados que respalden la siguiente cantidad de obras: 5 obras de edificación con superficie igual o superior a 10.000 m² y 5 o más pisos, incluidos subterraneos

• Los certificados deberán indicar nombre del proyecto, fechas de inicio y término, cargo desempeñado, superficie construida y número de pisos. (Excluyente).

• Contar con residencia en la ciudad de Temuco o tener disponibilidad para trasladarse a la zona.

Importante

• No se considerará experiencia en proyectos habitacionales, vivienda social, vivienda en extensión (villas, loteos), obras viales, arquitectura industrial, deportiva y urbanística. Tampoco se considerarán aquellos proyectos que corresponden a normalizaciones, mejoramientos, restauraciones, regularizaciones y evaluaciones.

¡Te invitamos a postular con nosotros y formar parte de un gran equipo!
