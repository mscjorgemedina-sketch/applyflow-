---
offer_id: "ch_25bfabaf38f7"
offer_key: "3913917"
portal: "ChileTrabajos"
title: "INGENIERO /A PLANIFICADOR DE MANTENIMIENTO PLANTA"
company: "CAPSTONE COPPER"
location: "Copiapó"
published: "14 de Octubre de 2026"
score_legacy: "77"
cluster_id: "C3_MECANICA"
cluster_name: "Mecánica, Maestranza & Mantenimiento"
url: "https://www.chiletrabajos.cl/trabajo/ingeniero-a-planificador-de-mantenimiento-planta-3913917"
apply_url: "https://www.chiletrabajos.cl/trabajo/postular/3913917"
tags: ["mantenimiento", "planta", "instrumentación"]
salary_text: ""
fetched_at: "2026-10-21T04:13:30"
fetch_status: "ok"
error: ""
---

# INGENIERO /A PLANIFICADOR DE MANTENIMIENTO PLANTA

- Empresa: CAPSTONE COPPER
- Ubicacion: Copiapó
- Publicado: 14 de Octubre de 2026
- Score legacy: 77
- Cluster: Mecánica, Maestranza & Mantenimiento
- Tags: mantenimiento, planta, instrumentación

## Descripcion

Nuestro cliente requiere contratar Ingeniero /A Planificador Mantenimiento Planta.

Proposito del cargo:

-Planificar el mantenimiento eléctrico y de instrumentación de la planta óxidos, asegurando alcance, recursos, materiales, servicios y documentación completa de las ordenes de trabajo en SAP PM para contribuir a la disponibilidad y confiabilidad de los equipos.

Formación académica:

-Ingeniería civil eléctrica, ingeniería ejecución eléctrica o ingeniería automatización, control e instrumentación, con experiencia equivalente.

Experiencia:

-Poseer al menos 3 años en planificación de mantenimiento eléctrico e instrumentación en plantas de oxido, chancado, lixiviación y SX-EW.

Conocimientos:

-Sap PM y MM

-Planificación y programación de mantenimiento

-Excel avanzado

-Equipos E&I, bloqueo y aislacion

-Administracion de contratos de servicios

Deseable:

-Cusos de bloqueo y aislacionismo y administración de contratos.

INTERESADOS ENVIAR CV AL CORREO POSTULACION@PROFILECONSULTING.CL
