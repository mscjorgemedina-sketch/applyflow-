---
offer_id: "ch_8efff47672fc"
offer_key: "3917593"
portal: "ChileTrabajos"
title: "Especialista Mecánico piping"
company: "JEJ INGENIERIA"
location: "Santiago"
published: "20 de Octubre de 2026"
score_legacy: "81"
cluster_id: "C4_PIPING"
cluster_name: "Piping, Montaje & Estructuras"
url: "https://www.chiletrabajos.cl/trabajo/especialista-mecanico-piping-3917593"
apply_url: "https://www.chiletrabajos.cl/trabajo/postular/3917593"
tags: ["mecánico", "ingeniería", "santiago"]
salary_text: ""
fetched_at: "2026-10-21T04:13:08"
fetch_status: "ok"
error: ""
---

# Especialista Mecánico piping

- Empresa: JEJ INGENIERIA
- Ubicacion: Santiago
- Publicado: 20 de Octubre de 2026
- Score legacy: 81
- Cluster: Piping, Montaje & Estructuras
- Tags: mecánico, ingeniería, santiago

## Descripcion

En JEJ Ingeniería nos encontramos en búsqueda de un/a Especialista Civil Mecánico Piping para incorporarse a nuestro equipo y desempeñarse en las dependencias de un importante cliente en Santiago, bajo jornada 5x2, para proyecto de 4 meses.

Requisitos:

- Ingeniería Civil Mecánica, Ingeniería ejecución mecánico

- 10 años de experiencia en obras de mediana o gran minería.

- 8 años en proyectos de Construcción, EPCM o EPC.

- Experiencia en proyectos Brown Field.

Condiciones de la vacante:

- Ubicación: Santiago.

- Modalidad híbrida: presencial de lunes a jueves en oficinas del sector y teletrabajo los viernes.

- Jornada: 5x2.

- Duración: proyecto de 4 meses, con posibilidad de extensión.

- Visitas esporádicas a faena, de acuerdo con la programación y necesidades del proyecto.

¿Te interesa ser parte de este desafío?

Si cuentas con la experiencia requerida y buscas una nueva oportunidad para aportar tus conocimientos en proyectos de ingeniería minera, ¡te invitamos a postular!
