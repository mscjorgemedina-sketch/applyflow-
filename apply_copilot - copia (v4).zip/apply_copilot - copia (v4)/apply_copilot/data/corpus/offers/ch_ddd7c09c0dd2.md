---
offer_id: "ch_ddd7c09c0dd2"
offer_key: "3917439"
portal: "ChileTrabajos"
title: "Inspector de Calidad Eléctrica e Instrumentación"
company: "Garde-Corps Ltda"
location: "Iquique"
published: "20 de Octubre de 2026"
score_legacy: "77"
cluster_id: "C2_ITO"
cluster_name: "ITO & Aseguramiento de Calidad"
url: "https://www.chiletrabajos.cl/trabajo/inspector-de-calidad-electrica-e-instrumentacion-3917439"
apply_url: "https://www.chiletrabajos.cl/trabajo/postular/3917439"
tags: ["calidad", "instrumentación", "pruebas"]
salary_text: ""
fetched_at: "2026-10-21T04:13:47"
fetch_status: "ok"
error: ""
---

# Inspector de Calidad Eléctrica e Instrumentación

- Empresa: Garde-Corps Ltda
- Ubicacion: Iquique
- Publicado: 20 de Octubre de 2026
- Score legacy: 77
- Cluster: ITO & Aseguramiento de Calidad
- Tags: calidad, instrumentación, pruebas

## Descripcion

OFERTA LABORAL INSPECTOR/A DE CALIDAD ELÉCTRICA E INSTRUMENTACIÓN

Garde-Corps Ltda. se encuentra en búsqueda de un/a Inspector/a de Calidad Eléctrica e Instrumentación para integrarse a proyecto en faena minera Teck Quebrada Blanca, Región de Tarapacá.

Cargo: Inspector/a de Calidad Eléctrica e Instrumentación

Lugar de trabajo: Faena minera Teck Quebrada Blanca

Sistema de turno: 7x7

Requisitos del cargo

Formación técnica o profesional en Electricidad, Electrónica, Instrumentación y Control, Automatización o carrera afín.

Experiencia mínima de 5 años en inspección y control de calidad eléctrica e instrumentación.

Experiencia acreditable en pruebas eléctricas, Loop Test y calibración de instrumentos.

Conocimiento en inspección de instalaciones eléctricas, cableado, conexionado y montaje de instrumentos.

Experiencia en revisión de planos, diagramas de lazo, procedimientos y protocolos de pruebas.

Manejo de registros de inspección, certificados de calibración y documentación de calidad.

Compromiso con los estándares de seguridad, calidad y procedimientos operacionales de la faena.

Salud compatible con trabajo en altura geográfica

Principales funciones

Inspeccionar y verificar la correcta ejecución de los trabajos eléctricos y de instrumentación conforme a planos, especificaciones técnicas y procedimientos vigentes.

Supervisar y documentar pruebas eléctricas, verificaciones de continuidad y aislamiento, según corresponda al alcance del proyecto.

Ejecutar o verificar pruebas Loop Test para comprobar la correcta conexión y comunicación entre instrumentos, señales y sistemas de control.

Verificar la calibración y el funcionamiento de instrumentos de campo, revisando sus certificados y registros asociados.

Controlar el montaje, cableado, conexionado e identificación de instrumentos y componentes eléctricos.

Revisar y completar protocolos de inspección, registros de pruebas y documentación de calidad.

Identificar desviaciones y no conformidades, coordinando su registro, seguimiento y cierre.

Apoyar la preparación del dossier de calidad y de los antecedentes de pruebas requeridos para la recepción de las instalaciones.
