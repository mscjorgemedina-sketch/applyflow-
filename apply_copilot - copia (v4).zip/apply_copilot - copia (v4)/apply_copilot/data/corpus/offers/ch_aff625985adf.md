---
offer_id: "ch_aff625985adf"
offer_key: "3890715"
portal: "ChileTrabajos"
title: "ASESOR INSPECTOR TÉCNICO DE OBRAS PORTUARIAS"
company: "Empresa Ingeniería e Inspección"
location: "Antofagasta"
published: "30 de Septiembre de 2026"
score_legacy: "73"
cluster_id: "C2_ITO"
cluster_name: "ITO & Aseguramiento de Calidad"
url: "https://www.chiletrabajos.cl/trabajo/asesor-inspector-tecnico-de-obras-portuarias-3890715"
apply_url: "https://www.chiletrabajos.cl/trabajo/postular/3890715"
tags: ["obras", "portuarias", "inspector"]
salary_text: "Interesados remitir CV y copia de certificado de título a postulantes@ankeringenieria.com indicando pretensiones de renta y adjuntando certificados de experiencia (excluyente)."
fetched_at: "2026-10-21T04:15:00"
fetch_status: "ok"
error: ""
---

# ASESOR INSPECTOR TÉCNICO DE OBRAS PORTUARIAS

- Empresa: Empresa Ingeniería e Inspección
- Ubicacion: Antofagasta
- Publicado: 30 de Septiembre de 2026
- Score legacy: 73
- Cluster: ITO & Aseguramiento de Calidad
- Tags: obras, portuarias, inspector

## Descripcion

ASESOR INSPECTOR TÉCNICO DE OBRAS PORTUARIAS

Se requiere profesional para proyecto en ciudad de Taltal; como “Asesor Inspector Técnico de Obras Portuarias”; Ingeniero Civil Obras Civiles, Constructor Civil o Ingeniero Constructor que cumpla además los siguientes requisitos:

• 5 años mínimos de experiencia profesional en construcción y/o inspección de proyectos de obras civiles.

• Debe estar titulado.

• 3 años de experiencia en proyectos de construcción y/o inspección de obras marítimas, portuarias, como hincado de tablestacas y muros de defensa costera.

• Experiencia en controles de terreno, cubicaciones, EP, informes técnicos y RCOP.

• Manejo a nivel avanzado de Office, Project y AutoCAD.

• Disponibilidad en jornada completa por 12 meses.

Interesados remitir CV y copia de certificado de título a postulantes@ankeringenieria.com indicando pretensiones de renta y adjuntando certificados de experiencia (excluyente).

## Renta publicada

Interesados remitir CV y copia de certificado de título a postulantes@ankeringenieria.com indicando pretensiones de renta y adjuntando certificados de experiencia (excluyente).
