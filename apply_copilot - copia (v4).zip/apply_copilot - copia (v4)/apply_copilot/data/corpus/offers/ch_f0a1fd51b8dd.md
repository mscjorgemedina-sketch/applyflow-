---
offer_id: "ch_f0a1fd51b8dd"
offer_key: "3882269"
portal: "ChileTrabajos"
title: "Ingeniero/a Civil Mención Hidráulica"
company: "FDA Ingenieros"
location: "Santiago"
published: "24 de Agosto de 2026"
score_legacy: "70"
cluster_id: "C5_AGUA"
cluster_name: "Agua, Riles & Sanitario"
url: "https://www.chiletrabajos.cl/trabajo/ingeniero-a-civil-mencion-hidraulica-3882269"
apply_url: "https://www.chiletrabajos.cl/trabajo/postular/3882269"
tags: ["ingeniero", "mención", "hidráulica"]
salary_text: ""
fetched_at: "2026-10-21T04:16:53"
fetch_status: "ok"
error: ""
---

# Ingeniero/a Civil Mención Hidráulica

- Empresa: FDA Ingenieros
- Ubicacion: Santiago
- Publicado: 24 de Agosto de 2026
- Score legacy: 70
- Cluster: Agua, Riles & Sanitario
- Tags: ingeniero, mención, hidráulica

## Descripcion

En FDA Ingenieros nos encontramos en búsqueda de un/a Ingeniero/a Civil con Mención en Hidráulica, con al menos 10 años de experiencia comprobada en proyectos mineros.

Principales responsabilidades:

- Liderazgo de equipos y control de proyecto en plazo y calidad de entregables.

- Desarrollo de diseños hidráulicos, memorias técnicas mediante software de modelación y planillas.

- Revisión de documentos técnicos multidisciplinario.

- Desarrollo de diagramas P&ID y revisar consistencia técnica con otras disciplinas involucradas en el proyecto.

Requisitos:

- Título profesional: Ingeniero/a Civil con mención en hidráulica.

- Experiencia: Desde 10 años.

- Experiencia en proyectos hidráulico memorias técnicas mediante softwares de modelación HEC-RAS o similar.

- Experiencia en proyectos relacionados con relaves.

Ofrecemos:

- Seguro complementario de Vida, Salud, Dental y Catastrófico.

- Medio día libre el viernes de tu cumpleaños.

- Beneficios Caja Los Andes.

- Desayuno de cortesía el día de tu cumpleaños.

Beneficios

Seguro de salud

La empresa paga o copaga una cobertura de salud adicional.

Trabajo 100% remoto

No es necesario ir a la oficina, puedes trabajar completamente desde tu casa.

Seguro de vida

¡La salud es lo más importante! La empresa paga el seguro de vida

Seguro dental

Paga o copaga un seguro dental.

Día de cumpleaños libre

El día de tu cumpleaños es canjeable por un día completo de vacaciones.

Mutual de Seguridad

La empresa esta adscrita a la mutual de seguridad

Caja de compensación

La empresa esta adscrita a una caja de compensación
