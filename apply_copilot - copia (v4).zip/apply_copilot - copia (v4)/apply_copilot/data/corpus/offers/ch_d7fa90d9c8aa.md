---
offer_id: "ch_d7fa90d9c8aa"
offer_key: "3879388"
portal: "ChileTrabajos"
title: "Inspector de Calidad Tipo B QAQC Minería EP91 Pelambre"
company: "confidencial"
location: "Coquimbo"
published: "07 de Agosto de 2026"
score_legacy: "77"
cluster_id: "C2_ITO"
cluster_name: "ITO & Aseguramiento de Calidad"
url: "https://www.chiletrabajos.cl/trabajo/inspector-de-calidad-tipo-b-qaqc-mineria-ep91-pelambre-3879388"
apply_url: "https://www.chiletrabajos.cl/trabajo/postular/3879388"
tags: ["calidad", "años", "minería"]
salary_text: ""
fetched_at: "2026-10-21T04:13:52"
fetch_status: "ok"
error: ""
---

# Inspector de Calidad Tipo B QAQC Minería EP91 Pelambre

- Empresa: confidencial
- Ubicacion: Coquimbo
- Publicado: 07 de Agosto de 2026
- Score legacy: 77
- Cluster: ITO & Aseguramiento de Calidad
- Tags: calidad, años, minería

## Descripcion

Buscamos Inspectores de Calidad para incorporarse a importante servicio QAQC para Minera Los Pelambres.

Principales funciones

Auditorías a sistemas de gestión.

Inspecciones en terreno.

Verificación documental y protocolización.

Seguimiento de hallazgos.

Control de estándares constructivos y de calidad.

Requisitos

Ingeniería de Ejecución o carrera afín.

10 años de experiencia general.

8 años de experiencia específica.

Mínimo 5 años en minería como Inspector Técnico o Jefe de Calidad.

Auditor Interno.

Auditor Líder ISO 9001.

Conocimiento en metrología, inspecciones y ensayos.

No dudes en postular con nosotros !!!
