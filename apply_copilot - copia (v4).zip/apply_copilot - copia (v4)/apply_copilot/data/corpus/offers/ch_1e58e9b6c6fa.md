---
offer_id: "ch_1e58e9b6c6fa"
offer_key: "3916904"
portal: "ChileTrabajos"
title: "SOLDADOR PIPING 6G (SMAW) - MAESTRANZA LAMPA"
company: "COMPLEX"
location: "Concepción"
published: "20 de Octubre de 2026"
score_legacy: "79"
cluster_id: "C4_PIPING"
cluster_name: "Piping, Montaje & Estructuras"
url: "https://www.chiletrabajos.cl/trabajo/soldador-piping-6g-smaw-maestranza-lampa-3916904"
apply_url: "https://www.chiletrabajos.cl/trabajo/postular/3916904"
tags: ["smaw", "piping", "lampa"]
salary_text: "Renta líquida: $1.200.000 + bono de asistencia de $100.000. | - Renta líquida de $1.200.000. | - Bono de asistencia de $100.000, sujeto a las condiciones establecidas por la empresa."
fetched_at: "2026-10-21T04:13:12"
fetch_status: "ok"
error: ""
---

# SOLDADOR PIPING 6G (SMAW) - MAESTRANZA LAMPA

- Empresa: COMPLEX
- Ubicacion: Concepción
- Publicado: 20 de Octubre de 2026
- Score legacy: 79
- Cluster: Piping, Montaje & Estructuras
- Tags: smaw, piping, lampa

## Descripcion

Soldador Calificado 6G – Proceso SMAW Maestranza Lampa

Ubicación: Lampa, Región Metropolitana.

Renta líquida: $1.200.000 + bono de asistencia de $100.000.

Jornada: Completa.

Descripción del cargo

En Complex, empresa dedicada a la construcción y montaje industrial, nos encontramos en búsqueda de un Soldador Calificado 6G en proceso SMAW (electrodo revestido) para desempeñarse en nuestra maestranza ubicada en Lampa.

Buscamos una persona con experiencia comprobable en soldadura de piping industrial, capaz de ejecutar trabajos de acuerdo con los estándares de calidad, seguridad y especificaciones técnicas requeridas.

Requisitos excluyentes:

- Contar con calificación 6G en proceso SMAW.

- Experiencia comprobable en soldadura de piping industrial.

- Experiencia de 4 a 5 años en funciones similares.

- Conocimiento en interpretación de procedimientos y especificaciones de soldadura.

- Compromiso con la seguridad, responsabilidad y orientación a la calidad.

Funciones principales:

- Ejecutar trabajos de soldadura en piping industrial mediante proceso SMAW.

- Realizar soldaduras conforme a planos, procedimientos y especificaciones técnicas.

- Verificar la calidad de las uniones soldadas y corregir defectos cuando corresponda.

- Cumplir con los procedimientos de seguridad y calidad establecidos por la empresa.

Jornada laboral:

- Lunes a miércoles: 08:00 a 18:00 hrs.

- Jueves: 08:00 a 17:00 hrs.

- Viernes: 08:00 a 16:00 hrs.

Condiciones de trabajo:

- Trabajo presencial en maestranza ubicada en Lampa.

- Renta líquida de $1.200.000.

- Bono de asistencia de $100.000, sujeto a las condiciones establecidas por la empresa.

Si cumples con los requisitos y cuentas con experiencia en soldadura de piping industrial, te invitamos a postular y formar parte del equipo Complex.

Beneficios

Mutual de Seguridad

La empresa esta adscrita a la mutual de seguridad

Caja de compensación

La empresa esta adscrita a una caja de compensación

Uniforme

La empresa provee el uniforme de trabajo

## Renta publicada

Renta líquida: $1.200.000 + bono de asistencia de $100.000. | - Renta líquida de $1.200.000. | - Bono de asistencia de $100.000, sujeto a las condiciones establecidas por la empresa.
