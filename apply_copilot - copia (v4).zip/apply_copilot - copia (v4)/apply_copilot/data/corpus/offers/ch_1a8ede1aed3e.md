---
offer_id: "ch_1a8ede1aed3e"
offer_key: "3907130"
portal: "ChileTrabajos"
title: "Especialista ITO Mecánico - Minería"
company: "DRS Ingeniería y Gestión"
location: "Antofagasta"
published: "01 de Octubre de 2026"
score_legacy: "86"
cluster_id: "C2_ITO"
cluster_name: "ITO & Aseguramiento de Calidad"
url: "https://www.chiletrabajos.cl/trabajo/especialista-ito-mecanico-mineria-3907130"
apply_url: "https://www.chiletrabajos.cl/trabajo/postular/3907130"
tags: ["mecánico", "años", "ito"]
salary_text: ""
fetched_at: "2026-10-21T04:12:49"
fetch_status: "ok"
error: ""
---

# Especialista ITO Mecánico - Minería

- Empresa: DRS Ingeniería y Gestión
- Ubicacion: Antofagasta
- Publicado: 01 de Octubre de 2026
- Score legacy: 86
- Cluster: ITO & Aseguramiento de Calidad
- Tags: mecánico, años, ito

## Descripcion

En DRS Ingeniería y Gestión estamos en búsqueda de ITO Mecánico para prestación de servicio en servicio minero en la cercanías de Antofagasta, II Región.

Turno 8x6

Requisitos:

Formación Ingeniería Civil de la Especialidad o Ingeniería de Ejecución

Ingeniero Civil con al menos 15 años de experiencia general. Al menos 8 años de experiencia específica en Inspección en Montaje Mecánico

o Ingeniero de Ejecución con con al menos 15 años de experiencia general 10 años de experiencia, ambos en proyectos en mediana o gran minería y habiendo participado en procesos de Construcción y PEM.

Sólidos conocimientos en los temas de especialidad contratada.

Ideal residencia en la II Región
