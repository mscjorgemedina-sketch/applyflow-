---
offer_id: "ch_e2f1cb138cec"
offer_key: "3904706"
portal: "ChileTrabajos"
title: "Ingeniero de Mantenimiento Industria de Alimentos/Lácteos/Bebidas - Viajes EEUU"
company: "PSC People Services Connection"
location: "Santiago"
published: "27 de Septiembre de 2026"
score_legacy: "71"
cluster_id: "C3_MECANICA"
cluster_name: "Mecánica, Maestranza & Mantenimiento"
url: "https://www.chiletrabajos.cl/trabajo/ingeniero-de-mantenimiento-industria-de-alimentos-lacteos-bebidas-viajes-eeuu-3904706"
apply_url: "https://www.chiletrabajos.cl/trabajo/postular/3904706"
tags: ["mantenimiento", "servicios", "alimentos"]
salary_text: "– Renta anual: USD 62.400."
fetched_at: "2026-10-21T04:15:37"
fetch_status: "ok"
error: ""
---

# Ingeniero de Mantenimiento Industria de Alimentos/Lácteos/Bebidas - Viajes EEUU

- Empresa: PSC People Services Connection
- Ubicacion: Santiago
- Publicado: 27 de Septiembre de 2026
- Score legacy: 71
- Cluster: Mecánica, Maestranza & Mantenimiento
- Tags: mantenimiento, servicios, alimentos

## Descripcion

Ingeniero/a de Mantenimiento – Industria de Alimentos, Lácteos y Bebidas Servicios en EE.UU.

Empresa internacional dedicada a la gestión de mantenimiento, servicios técnicos y soporte especializado para equipos industriales de alimentos, lácteos y bebidas se encuentra en búsqueda de Ingenieros/as de Mantenimiento (Field Service Engineers) con experiencia en terreno, capaces de ejecutar mantenimiento preventivo y correctivo, diagnóstico avanzado y resolución de fallas complejas, instalación, puesta en marcha y soporte técnico de equipos de procesamiento y/o envasado.

El puesto requiere alta disponibilidad para viajar a Estados Unidos por servicios y proyectos, sin necesidad de reubicación permanente.

**Funciones principales**

– Ejecutar actividades de mantenimiento preventivo, correctivo y avanzado en equipos industriales de procesamiento y/o envasado de la industria de alimentos, lácteos o bebidas.

– Realizar diagnóstico y resolución de fallas complejas de carácter mecánico, eléctrico, neumático, de instrumentación y automatización.

– Ejecutar calibraciones, ajustes y optimización del desempeño de equipos y sistemas industriales.

– Implementar mejoras orientadas a optimizar la eficiencia y continuidad operacional de equipos, líneas y procesos productivos.

– Actuar como referente técnico en terreno frente al cliente, entregando soporte especializado durante las intervenciones.

– Elaborar informes técnicos detallados de los servicios, diagnósticos, trabajos realizados y resultados obtenidos.

– Ejecutar los servicios asegurando el cumplimiento de los estándares de seguridad, calidad y procedimientos técnicos aplicables.

**Requisitos**

– Título profesional en Mecánica, Electricidad, Electrónica, Mecatrónica, Automatización y Control, Mantenimiento Industrial o carrera afín.

– Experiencia en mantenimiento o servicio técnico de equipos de procesamiento y/o líneas de llenado y envasado, en plantas de la industria de alimentos, lácteos, bebidas, jugos o alimentos líquidos.

– Experiencia con equipos de fabricantes como Tetra Pak, Elopak, Sidel, GEA, JBT, Stork, Evergreen, Krones, SPE, Meurer u otros fabricantes relacionados.

– Conocimientos en mantenimiento y diagnóstico de sistemas mecánicos, eléctricos, neumáticos, de instrumentación y automatización industrial.

– Inglés mínimo B1 para participar en conversaciones técnicas con clientes y comprender documentación técnica.

– Alta disponibilidad para realizar servicios y viajes frecuentes a Estados Unidos.

– Cumplir con los requisitos de nacionalidad chilena, aplicables para optar a una visa de trabajo H-1B1.

**Condiciones ofrecidas**

– Número de vacantes: 6.

– Modalidad de trabajo: trabajo en terreno, con viajes frecuentes a Estados Unidos de acuerdo con la programación de servicios.

– Ubicación base: no requiere reubicación.

– Tipo de contrato: contrato laboral directo con una empresa estadounidense, sujeto a la legislación laboral aplicable en Estados Unidos.

– Renta anual: USD 62.400.

– Pasajes aéreos, viáticos, alojamiento y movilización: cubiertos por la empresa para los traslados asociados a los servicios. Además, pago de hasta 10 horas de traslado asociadas a los viajes.

– Beneficios adicionales: seguro médico de cobertura internacional y en viaje.

– Visa de trabajo: la empresa ofrece empleo bajo visa H-1B1 para profesionales chilenos, de acuerdo con la normativa vigente en EE.UU. La empresa asumirá los gastos asociados a la gestión legal y migratoria que correspondan al empleador, incluyendo los honorarios profesionales relacionados con el proceso. Asimismo, los gastos en que deba incurrir el candidato para la tramitación y asistencia a su cita consular serán reembolsados por la empresa, conforme a la normativa aplicable y al procedimiento de reembolso establecido.

– Apoyo y acompañamiento al candidato: acompañamiento integral durante todo el proceso de contratación, que incluye apoyo en recopilación de documentos, orientación para el formulario DS-160 y coordinación para cita en la Embajada de EE.UU., además de acompañamiento previo al inicio laboral.

**Proceso de Selección:

1. Llamada telefónica inicial para validar experiencia técnica, disponibilidad de viajes y nivel de inglés.

2. Llamada telefónica para evaluar nivel de inglés.

3. Presentación del curriculum del candidato al cliente.

4. Coaching grupal previo a la entrevista para entregar tips y consejos previos.

5. Entrevista con equipo internacional / Hiring Manager para validar ajuste técnico y cultural.

*** El proceso podría incluir evaluaciones técnicas adicionales o entrevistas complementarias, dependiendo del cliente.

## Renta publicada

– Renta anual: USD 62.400.
