---
offer_id: "ch_19b1e7f7c2ea"
offer_key: "3901872"
portal: "ChileTrabajos"
title: "LICP-010926 - ITO Terreno - Temuco"
company: "SIGPRO"
location: "Temuco"
published: "22 de Septiembre de 2026"
score_legacy: "73"
cluster_id: "C2_ITO"
cluster_name: "ITO & Aseguramiento de Calidad"
url: "https://www.chiletrabajos.cl/trabajo/licp-010926-ito-terreno-temuco-3901872"
apply_url: "https://www.chiletrabajos.cl/trabajo/postular/3901872"
tags: ["temuco", "civil", "constructor"]
salary_text: ""
fetched_at: "2026-10-21T04:15:27"
fetch_status: "ok"
error: ""
---

# LICP-010926 - ITO Terreno - Temuco

- Empresa: SIGPRO
- Ubicacion: Temuco
- Publicado: 22 de Septiembre de 2026
- Score legacy: 73
- Cluster: ITO & Aseguramiento de Calidad
- Tags: temuco, civil, constructor

## Descripcion

SIGPRO Gestión de Proyectos, necesita un Ingeniero Civil, Constructor Civil, Ingeniero Constructor o Arquitecto, para el cargo de ITO Terreno, correspondiente a la licitación: SERVICIO DE INSPECCIÓN TÉCNICA PARA LA HABILITACIÓN DEL CENTRO DE JUSTICIA DE TEMUCO - TRIBUNAL DE FAMILIA CIVILES 1° 2° Y 3° JUZGADO DE LETRAS Y DE FAMILIA Y JUZGADO DE LETRAS DEL TRABAJO

Requisitos:

- Profesión: Ingeniero Civil, Constructor Civil, Ingeniero Constructor o Arquitecto.

- Experiencia excluyente: Solo se considerará como experiencia profesional, la ejecución de servicios de inspección técnica en los cuales dicho profesional haya participado como ITO, en labores de inspección técnica o bien como Jefe de terreno, Jefe de oficina técnica o administrador de proyectos de construcción de obra nueva, remodelaciones y/o ampliación de oficinas, retail, educacional, empresas públicas con una superficie mínima de 10.000 M2, en edificaciones individuales en altura (5 o más pisos, incluidos subterráneos ), que se hubieren prestado total o parcialmente en el período de los últimos 15 años, en al menos 7 obras.

- Excluyente: Debe posee Certificados de los empleadores, instituciones públicas y/o privadas que acredite la participación del profesional en los servicios prestados. En los certificados deberá señalarse el nombre del trabajo de inspección, su fecha de inicio y término, sus alcances, una breve descripción del trabajo que permita identificar la naturaleza de la contratación, número de pisos de la edificación y la superficie involucrada

- Residencia: Temuco (preferencia)

Interesados enviar antecedentes al correo rcarmillo@sigpro.cl

a) Cv actualizado

b) Certificado de título con código de verificación

c) Certificados de experiencia con las características solicitadas.

Si buscas estabilidad, desafío técnico y pertenecer a una empresa líder en el rubro de asesoría técnica ¡este es tu lugar!
