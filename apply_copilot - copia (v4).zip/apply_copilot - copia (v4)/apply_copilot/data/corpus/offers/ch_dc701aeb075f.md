---
offer_id: "ch_dc701aeb075f"
offer_key: "3897573"
portal: "ChileTrabajos"
title: "PROJECT MANAGER – PROYECTO EN OSORNO"
company: "EMPRESA CONFIDENCIAL"
location: "Osorno"
published: "11 de Septiembre de 2026"
score_legacy: "75"
cluster_id: "C1_GESTION"
cluster_name: "Gestión de Proyectos & Contratos"
url: "https://www.chiletrabajos.cl/trabajo/project-manager-proyecto-en-osorno-3897573"
apply_url: "https://www.chiletrabajos.cl/trabajo/postular/3897573"
tags: ["proyecto", "proyectos", "osorno"]
salary_text: ""
fetched_at: "2026-10-21T04:13:55"
fetch_status: "ok"
error: ""
---

# PROJECT MANAGER – PROYECTO EN OSORNO

- Empresa: EMPRESA CONFIDENCIAL
- Ubicacion: Osorno
- Publicado: 11 de Septiembre de 2026
- Score legacy: 75
- Cluster: Gestión de Proyectos & Contratos
- Tags: proyecto, proyectos, osorno

## Descripcion

Buscamos un/a Project Manager para liderar la gestión integral de un proyecto en Osorno, asegurando el cumplimiento de los objetivos de plazo, calidad, avance y coordinación de los distintos equipos involucrados.

Principales responsabilidades

Liderar y coordinar el desarrollo general del proyecto.

Gestionar equipos de ingeniería, terreno y áreas de apoyo.

Planificar, controlar y realizar seguimiento al avance del proyecto.

Asegurar el cumplimiento de hitos, plazos y objetivos definidos.

Elaborar y presentar reportes de avance, desviaciones, riesgos y principales indicadores.

Coordinar reuniones de seguimiento y gestionar compromisos.

Administrar los recursos asignados al proyecto y controlar el desempeño del equipo.

Identificar riesgos, restricciones y desviaciones, proponiendo acciones correctivas.

Mantener una adecuada coordinación entre las distintas disciplinas y partes involucradas.

Reportar periódicamente el estado del proyecto a la dirección de la empresa.

Requisitos

Ingeniero Civil Industrial o Ingeniero Civil Eléctrico.

Experiencia comprobable liderando proyectos de ingeniería, construcción, energía, industria o infraestructura.

Experiencia en conducción de equipos profesionales y multidisciplinarios.

Experiencia en planificación, control de avance y cumplimiento de objetivos.

Capacidad para generar reportería ejecutiva y realizar seguimiento de indicadores.

Manejo de herramientas de planificación y control de proyectos.

Disponibilidad para trabajar de manera presencial en Osorno.

Experiencia deseable

Experiencia en proyectos eléctricos o industriales.

Experiencia liderando equipos de ingeniería.

Conocimiento de proyectos de Media y Baja Tensión.

Experiencia en gestión de contratistas, control de costos y administración de proyectos.

Conocimiento de metodologías de gestión de proyectos y herramientas como Microsoft Project, Primavera, Excel o Power BI.

Competencias

Liderazgo y capacidad de gestión.

Orientación a resultados.

Planificación y organización.

Capacidad analítica y resolución de problemas.

Comunicación efectiva.

Proactividad y autonomía.

Capacidad para trabajar bajo presión y gestionar múltiples prioridades.

Si tienes experiencia liderando proyectos y te interesa asumir un rol de responsabilidad en un proyecto con presencia en Osorno, te invitamos a postular y ser parte de este desafío.
