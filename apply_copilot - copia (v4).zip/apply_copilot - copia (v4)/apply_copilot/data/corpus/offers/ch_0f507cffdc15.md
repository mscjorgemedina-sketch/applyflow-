---
offer_id: "ch_0f507cffdc15"
offer_key: "3913019"
portal: "ChileTrabajos"
title: "Solicitamos Operario para Planta de agua"
company: "RRHH"
location: "Santiago"
published: "13 de Octubre de 2026"
score_legacy: "70"
cluster_id: "C5_AGUA"
cluster_name: "Agua, Riles & Sanitario"
url: "https://www.chiletrabajos.cl/trabajo/solicitamos-operario-para-planta-de-agua-3913019"
apply_url: "https://www.chiletrabajos.cl/trabajo/postular/3913019"
tags: ["planta", "producción", "agua"]
salary_text: ""
fetched_at: "2026-10-21T04:16:55"
fetch_status: "ok"
error: ""
---

# Solicitamos Operario para Planta de agua

- Empresa: RRHH
- Ubicacion: Santiago
- Publicado: 13 de Octubre de 2026
- Score legacy: 70
- Cluster: Agua, Riles & Sanitario
- Tags: planta, producción, agua

## Descripcion

Solicitamos Operario para Planta de Agua

Objetivo del cargo

-Ejecutar las actividades operativas de la planta de agua, asegurando el correcto funcionamiento del proceso de producción, envasado y almacenamiento, cumpliendo con los estándares de calidad, inocuidad, seguridad y productividad establecidos por la empresa.

Principales funciones

-Operar equipos y maquinarias destinados al proceso de producción de agua.

-Realizar el lavado, sanitización y preparación de envases para su reutilización o llenado.

-Ejecutar el llenado, sellado, etiquetado y embalaje de botellas y bidones.

-Revisar que los productos cumplan con los estándares de calidad antes de su despacho.

-Mantener el orden y limpieza de la planta y de las áreas de trabajo.

-Cumplir con los procedimientos de higiene, seguridad e inocuidad establecidos.

-Informar oportunamente cualquier falla en equipos, maquinaria o anomalía detectada durante la operación.

-Apoyar en la carga, descarga y almacenamiento de productos terminados e insumos.

-Registrar información básica de producción cuando sea requerido.

-Colaborar con otras áreas de la planta para asegurar la continuidad operacional.

Requisitos

-Enseñanza media completa.

-Experiencia en plantas productivas o de alimentos (deseable, no excluyente).

-Conocimientos básicos en normas de higiene y seguridad.

-Capacidad para realizar trabajo físico y mantener un ritmo constante de producción.

Responsabilidad, compromiso y puntualidad.

Competencias

Orientación a la calidad.

Trabajo en equipo.

Responsabilidad y disciplina.

Organización y orden.

Atención al detalle.

Proactividad.

Adaptabilidad.

Condiciones del cargo:

Trabajo presencial en planta.

Cumplimiento de protocolos de higiene, seguridad y calidad.

Disponibilidad para realizar labores operativas de producción, envasado y almacenamiento.

Jornada labora: 5x2

Salario liquido: 650.000 mas bono de 90.000

Ubicación: Huechuraba, Región Metropolitana

Beneficios

Uniforme

La empresa provee el uniforme de trabajo
