---
offer_id: "ch_cf742c572caf"
offer_key: "3889990"
portal: "ChileTrabajos"
title: "Proyectista Mecánico-Piping Plantas de Agua"
company: "Confidencial"
location: "Santiago"
published: "27 de Agosto de 2026"
score_legacy: "86"
cluster_id: "C4_PIPING"
cluster_name: "Piping, Montaje & Estructuras"
url: "https://www.chiletrabajos.cl/trabajo/proyectista-mecanico-piping-plantas-de-agua-3889990"
apply_url: "https://www.chiletrabajos.cl/trabajo/postular/3889990"
tags: ["proyectos", "ingeniería", "piping"]
salary_text: ""
fetched_at: "2026-10-21T04:12:51"
fetch_status: "ok"
error: ""
---

# Proyectista Mecánico-Piping Plantas de Agua

- Empresa: Confidencial
- Ubicacion: Santiago
- Publicado: 27 de Agosto de 2026
- Score legacy: 86
- Cluster: Piping, Montaje & Estructuras
- Tags: proyectos, ingeniería, piping

## Descripcion

Importante empresa del rubro industrial busca incorporar a un/a Proyectista Mecánico-Piping, quien será responsable de desarrollar los entregables de diseño asociados a proyectos de plantas de tratamiento de agua, desde las etapas de oferta e ingeniería básica hasta la construcción y elaboración de planos as-built.

El desafío principal será transformar la ingeniería de procesos en soluciones técnicamente consistentes, construibles, montables y operables, generando la documentación necesaria para la fabricación y ejecución de los proyectos.

Principales funciones:

• Elaborar y actualizar diagramas P&ID, desde su versión de oferta hasta as-built.

• Desarrollar layouts y disposiciones generales de planta, considerando ubicación de equipos, rutas de cañerías y accesos para operación y mantenimiento.

• Preparar isométricos, detalles mecánicos, soportación y especificaciones de cañerías, fittings y válvulas.

• Generar listas de materiales (MTO) completas y oportunas para los procesos de compra.

• Preparar planos y esquemas para ofertas técnicas, respondiendo a los plazos del ciclo comercial.

• Revisar documentación de proveedores, maestranzas e ingenierías externas, detectando interferencias e inconsistencias.

• Apoyar la verificación dimensional y de montaje durante la fabricación e instalación de los proyectos.

• Mantener actualizados los estándares, plantillas, bloques y revisiones de la biblioteca CAD del área.

¿Qué buscamos?

• Título de Proyectista, Técnico/a de Nivel Superior en Diseño Mecánico o Industrial, Ingeniería de Ejecución Mecánica o formación afín.

• Entre 4 y 7 años de experiencia como Proyectista Mecánico-Piping en empresas de ingeniería, EPC, maestranzas o proyectos industriales.

• Experiencia participando en proyectos desde la etapa de oferta o ingeniería básica hasta su construcción y entrega as-built.

• Dominio avanzado de AutoCAD, requisito excluyente.

• Experiencia en lectura y elaboración de P&ID e isométricos.

• Conocimiento de normas de piping, como ASME B31.3 o equivalentes de aplicación industrial.

Será valorado:

• Manejo de Plant 3D, Inventor u otras herramientas similares.

• Experiencia en plantas modulares o skids.

• Conocimiento de materiales utilizados en proyectos de agua, como HDPE, PVC, acero inoxidable o FRP.

Buscamos a una persona rigurosa y detallista, capaz de organizar entregables simultáneos, colaborar con distintas especialidades y anticipar interferencias o dificultades constructivas antes de que lleguen a terreno.

Si cuentas con la experiencia y te interesa participar en proyectos industriales desde su diseño hasta su implementación, te invitamos a postular
