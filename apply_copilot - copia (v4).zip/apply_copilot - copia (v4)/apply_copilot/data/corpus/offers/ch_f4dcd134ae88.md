---
offer_id: "ch_f4dcd134ae88"
offer_key: "3913675"
portal: "ChileTrabajos"
title: "Ingeniero de Mantenimiento y Mejora Operacional – Chiloé"
company: "Camanchaca Cultivos Sur S.A."
location: "Castro"
published: "14 de Octubre de 2026"
score_legacy: "71"
cluster_id: "C3_MECANICA"
cluster_name: "Mecánica, Maestranza & Mantenimiento"
url: "https://www.chiletrabajos.cl/trabajo/ingeniero-de-mantenimiento-y-mejora-operacional-chiloe-3913675"
apply_url: "https://www.chiletrabajos.cl/trabajo/postular/3913675"
tags: ["mantenimiento", "mejora", "ingeniería"]
salary_text: ""
fetched_at: "2026-10-21T04:15:38"
fetch_status: "ok"
error: ""
---

# Ingeniero de Mantenimiento y Mejora Operacional – Chiloé

- Empresa: Camanchaca Cultivos Sur S.A.
- Ubicacion: Castro
- Publicado: 14 de Octubre de 2026
- Score legacy: 71
- Cluster: Mecánica, Maestranza & Mantenimiento
- Tags: mantenimiento, mejora, ingeniería

## Descripcion

Ingeniero de Mantenimiento y Mejora Operacional – Chiloé

¡Sé parte de Camanchaca Cultivos Sur y contribuye a alimentar al mundo desde el mar!

En Camanchaca Cultivos Sur, empresa vinculada a la industria acuícola y con operaciones en la provincia de Chiloé, nos encontramos en búsqueda de un(a) Ingeniero(a) de Mantenimiento y Mejora Operacional para integrarse a nuestro equipo de Cultivos.

Buscamos un profesional con orientación técnica, capacidad de análisis y una fuerte disposición al trabajo en terreno, que contribuya al desarrollo de soluciones para fortalecer la confiabilidad, seguridad y eficiencia de nuestros equipos y operaciones.

Principales funciones:

Desarrollar, implementar y controlar programas de mantenimiento preventivo, predictivo y correctivo de equipos e instalaciones.

Analizar fallas técnicas, identificar sus causas y proponer soluciones que permitan evitar su recurrencia.

Participar en la evaluación y mejora de flotas, motores, grúas, sistemas hidráulicos, equipos de apoyo y estructuras de cultivo.

Identificar oportunidades de mejora operacional, desarrollar soluciones técnicas y evaluar sus resultados.

Participar en proyectos de mecanización, automatización, renovación de equipos y optimización de procesos.

Apoyar la evaluación técnica de proveedores, cotizaciones, supervisión de trabajos y recepción de servicios.

Requisitos:

Título profesional de Ingeniería Mecánica, Ingeniería Civil Mecánica, Ingeniería en Mantenimiento, Ingeniería Naval, Ingeniería Industrial con orientación mecánica o carrera afín.

Experiencia ideal de 2 a 4 años en mantenimiento industrial, equipos móviles, flotas o áreas relacionadas.

Conocimientos en mecánica, hidráulica, motores, estructuras, análisis de fallas y gestión de mantenimiento.

Manejo avanzado de Excel.

Deseable conocimiento de SAP, sistemas de mantenimiento y herramientas de diseño técnico como AutoCAD o SolidWorks.

Deseable experiencia en industrias acuícolas, pesqueras, navales o entornos marítimos.

Disponibilidad para realizar visitas a centros de cultivo, talleres y operaciones en distintos sectores de Chiloé.

Competencias que valoramos:

Orientación a resultados, iniciativa, capacidad analítica, resolución de problemas, autonomía, trabajo colaborativo y compromiso con la mejora continua.

Lugar de trabajo: Provincia de Chiloé, Región de Los Lagos. Búsqueda orientada a profesionales de Castro y alrededores, con disponibilidad para desplazarse a nuestras operaciones.

¿Qué ofrecemos?

La oportunidad de integrarte a una empresa de la industria acuícola, participando en proyectos de mantenimiento, ingeniería y mejora operacional, con posibilidades de desarrollo profesional y crecimiento dentro de la organización.

Si buscas un desafío que combine conocimientos técnicos, innovación y trabajo en terreno, ¡queremos conocerte!

Postula y sé parte de Camanchaca Cultivos Sur.

Alimentando al mundo desde el mar.

Beneficios

Bus acercamiento

La empresa provee un bus de acercamiento

Seguro de vida

¡La salud es lo más importante! La empresa paga el seguro de vida

Mutual de Seguridad

La empresa esta adscrita a la mutual de seguridad

Caja de compensación

La empresa esta adscrita a una caja de compensación

Uniforme

La empresa provee el uniforme de trabajo
