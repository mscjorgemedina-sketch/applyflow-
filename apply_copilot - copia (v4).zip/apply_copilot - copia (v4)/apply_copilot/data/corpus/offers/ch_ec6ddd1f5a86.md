---
offer_id: "ch_ec6ddd1f5a86"
offer_key: "3903766"
portal: "ChileTrabajos"
title: "Jefe de Mantenimiento de Retail"
company: "Confidencial"
location: "Santiago"
published: "25 de Septiembre de 2026"
score_legacy: "71"
cluster_id: "C3_MECANICA"
cluster_name: "Mecánica, Maestranza & Mantenimiento"
url: "https://www.chiletrabajos.cl/trabajo/jefe-de-mantenimiento-de-retail-3903766"
apply_url: "https://www.chiletrabajos.cl/trabajo/postular/3903766"
tags: ["mantenimiento", "instalaciones", "tiendas"]
salary_text: ""
fetched_at: "2026-10-21T04:15:58"
fetch_status: "ok"
error: ""
---

# Jefe de Mantenimiento de Retail

- Empresa: Confidencial
- Ubicacion: Santiago
- Publicado: 25 de Septiembre de 2026
- Score legacy: 71
- Cluster: Mecánica, Maestranza & Mantenimiento
- Tags: mantenimiento, instalaciones, tiendas

## Descripcion

Estamos en búsqueda de un Jefe de Mantenimiento de Retail para liderar y coordinar las actividades de mantenimiento, reparación y conservación de tiendas, locales comerciales e infraestructura asociada a la operación.

La persona seleccionada será responsable de asegurar la continuidad operacional y el correcto funcionamiento de las instalaciones, coordinando equipos internos, proveedores y empresas contratistas para atender tanto trabajos programados como requerimientos correctivos y emergencias.

Buscamos un profesional con experiencia en mantenimiento de infraestructura y operaciones de Retail, con capacidad para gestionar múltiples requerimientos simultáneamente, priorizar intervenciones y asegurar una respuesta oportuna frente a las necesidades de las distintas tiendas.

Principales responsabilidades

• Planificar, coordinar y supervisar el mantenimiento preventivo y correctivo de tiendas, locales e instalaciones.

• Coordinar y supervisar trabajos de reparación y mantenimiento de infraestructura y obras civiles.

• Liderar y organizar equipos técnicos y empresas contratistas responsables de los distintos servicios.

• Gestionar requerimientos de mantenimiento provenientes de las diferentes tiendas y establecer prioridades según criticidad.

• Supervisar trabajos de gasfitería, electricidad, climatización, vidrios, cortinas metálicas, pintura, terminaciones y obras menores, entre otras especialidades.

• Coordinar la atención de fallas y emergencias que puedan afectar la operación de las tiendas.

• Realizar visitas e inspecciones en terreno para identificar necesidades de mantenimiento y reparación.

Requisitos

• Formación técnica o profesional en Construcción, Ingeniería en Construcción, Construcción Civil, Ingeniería Civil, Mantenimiento o carrera afín.

• Experiencia mínima de 5 años en mantenimiento de Retail, infraestructura, instalaciones comerciales u operaciones similares.

• Experiencia liderando equipos técnicos y/o coordinando personal en terreno.

• Experiencia en gestión y supervisión de proveedores y empresas contratistas.

• Conocimientos generales de obras civiles, infraestructura, mantenimiento de instalaciones y terminaciones.

• Deseable experiencia trabajando con múltiples locales o instalaciones.

• Manejo de Excel y herramientas de seguimiento y gestión de mantenimiento.

• Habilidades de liderazgo, comunicación, planificación y resolución de problemas.
