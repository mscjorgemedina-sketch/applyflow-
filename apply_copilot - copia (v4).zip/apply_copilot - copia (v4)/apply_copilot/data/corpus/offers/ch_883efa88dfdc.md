---
offer_id: "ch_883efa88dfdc"
offer_key: "3914511"
portal: "ChileTrabajos"
title: "18.956 ITO Civil - Proyecto Edificación educacional"
company: "DRS Ingeniería"
location: "Santiago"
published: "15 de Octubre de 2026"
score_legacy: "73"
cluster_id: "C2_ITO"
cluster_name: "ITO & Aseguramiento de Calidad"
url: "https://www.chiletrabajos.cl/trabajo/18956-ito-civil-proyecto-edificacion-educacional-3914511"
apply_url: "https://www.chiletrabajos.cl/trabajo/postular/3914511"
tags: ["proyecto", "civil", "construcción"]
salary_text: ""
fetched_at: "2026-10-21T04:14:55"
fetch_status: "ok"
error: ""
---

# 18.956 ITO Civil - Proyecto Edificación educacional

- Empresa: DRS Ingeniería
- Ubicacion: Santiago
- Publicado: 15 de Octubre de 2026
- Score legacy: 73
- Cluster: ITO & Aseguramiento de Calidad
- Tags: proyecto, civil, construcción

## Descripcion

En DRS Ingeniería y Gestión estamos en búsqueda de un ITO Civil para proyecto de Edificación Educacional, ubicada en Santiago.

Duración del proyecto: 6 meses

Funciones principales:

-Revisar los antecedentes técnicos del proyecto y verificar el cumplimiento de la normativa vigente.

-Supervisar y evaluar los aspectos técnicos y normativos asociados al proyecto.

-Revisar planos, especificaciones técnicas y documentación relacionada con las obras.

-Identificar observaciones, incompatibilidades y desviaciones, proponiendo soluciones técnicas.

-Evaluar y validar proyectos y soluciones constructivas, verificando su factibilidad técnica y normativa.

Requisitos:

-Título profesional relacionado con el área de la construcción, como Ingeniería Civil, Construcción Civil o Ingeniería en Construcción.

-Al menos 5 años de experiencia profesional en proyectos de construcción.
