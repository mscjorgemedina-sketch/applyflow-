---
offer_id: "ch_497d8fba93ae"
offer_key: "3916207"
portal: "ChileTrabajos"
title: "ITO Civil/Estaciones de Servicio"
company: "CGESTA"
location: "Punta Arenas"
published: "19 de Octubre de 2026"
score_legacy: "73"
cluster_id: "C2_ITO"
cluster_name: "ITO & Aseguramiento de Calidad"
url: "https://www.chiletrabajos.cl/trabajo/ito-civil-estaciones-de-servicio-3916207"
apply_url: "https://www.chiletrabajos.cl/trabajo/postular/3916207"
tags: ["civil", "ito", "estaciones"]
salary_text: ""
fetched_at: "2026-10-21T04:14:59"
fetch_status: "ok"
error: ""
---

# ITO Civil/Estaciones de Servicio

- Empresa: CGESTA
- Ubicacion: Punta Arenas
- Publicado: 19 de Octubre de 2026
- Score legacy: 73
- Cluster: ITO & Aseguramiento de Calidad
- Tags: civil, ito, estaciones

## Descripcion

INSPECTOR TÉCNICO DE OBRA

INGENIERO CIVIL / INGENIERO CONSTRUCTOR / CONSTRUCTOR CIVIL o Profesión afín.

- Se requiere ITO Civil con experiencia en estaciones de servicios.

- Manejo de herramientas Office, Autocad.

- Disponibilidad inmediata.

- Residencia Punta Arenas (no excluyente).
