---
offer_id: "ch_9ab6ddc9d3e2"
offer_key: "3888687"
portal: "ChileTrabajos"
title: "Jefe de Mantenimiento de Maquinaria Pesada"
company: "Naviera"
location: "Puerto Montt"
published: "05 de Octubre de 2026"
score_legacy: "71"
cluster_id: "C3_MECANICA"
cluster_name: "Mecánica, Maestranza & Mantenimiento"
url: "https://www.chiletrabajos.cl/trabajo/jefe-de-mantenimiento-de-maquinaria-pesada-3888687"
apply_url: "https://www.chiletrabajos.cl/trabajo/postular/3888687"
tags: ["mantenimiento", "maquinaria", "pesada"]
salary_text: ""
fetched_at: "2026-10-21T04:15:56"
fetch_status: "ok"
error: ""
---

# Jefe de Mantenimiento de Maquinaria Pesada

- Empresa: Naviera
- Ubicacion: Puerto Montt
- Publicado: 05 de Octubre de 2026
- Score legacy: 71
- Cluster: Mecánica, Maestranza & Mantenimiento
- Tags: mantenimiento, maquinaria, pesada

## Descripcion

Empresa del rubro logístico-portuario busca incorporar a su equipo a un/a Jefe/a de Mantenimiento de Maquinaria Pesada, responsable de planificar, coordinar y supervisar las actividades de mantenimiento, asegurando la disponibilidad, seguridad y correcto funcionamiento de los equipos utilizados en la operación.

Principales funciones:

- Planificar y supervisar las mantenciones preventivas y correctivas de la maquinaria pesada.

- Coordinar y distribuir las labores del equipo de mantenimiento.

- Diagnosticar fallas mecánicas, hidráulicas, eléctricas y de motores diésel, orientando técnicamente su reparación.

- Supervisar las inspecciones y pruebas de funcionamiento realizadas después de cada intervención.

- Controlar el cumplimiento del programa de mantenimiento y llevar registro de los trabajos ejecutados.

- Gestionar oportunamente los requerimientos de repuestos, herramientas e insumos.

- Informar fallas críticas, tiempos de detención y necesidades de reparación o reposición de equipos.

- Coordinar con las áreas operativas la disponibilidad y entrega de la maquinaria para mantenimiento.

-Velar por el cumplimiento de los procedimientos de seguridad, prevención de riesgos y cuidado de los equipos.

Requisitos:

- Formación técnica o profesional en Mecánica de Maquinaria Pesada, Mecánica Automotriz, Electromecánica, Ingeniería Mecánica o carrera afín.

- Experiencia mínima de 5 años en mantenimiento y reparación de maquinaria pesada, idealmente en contextos logísticos, portuarios, industriales o similares.

- Experiencia previa coordinando o supervisando equipos de mantenimiento.

- Conocimientos sólidos en sistemas mecánicos, hidráulicos, eléctricos y motores diésel.

- Capacidad para diagnosticar fallas, planificar trabajos y tomar decisiones técnicas.

- Habilidades de liderazgo, organización, comunicación y resolución de problemas.

- Licencia de conducir clase B y D vigentes.

- Disponibilidad para trabajar en Puerto Montt.

- Disponibilidad para incorporación inmediata.

Beneficios

Bus acercamiento

La empresa provee un bus de acercamiento

Casino

La empresa incluye casino para la alimentación

Uniforme

La empresa provee el uniforme de trabajo
