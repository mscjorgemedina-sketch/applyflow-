---
offer_id: "ch_1bbba216f7bd"
offer_key: "3911130"
portal: "ChileTrabajos"
title: "18.746 ITO Civil - Proyecto área de Salud - Rancagua"
company: "DRS Ingeniería"
location: "Rancagua"
published: "08 de Octubre de 2026"
score_legacy: "73"
cluster_id: "C2_ITO"
cluster_name: "ITO & Aseguramiento de Calidad"
url: "https://www.chiletrabajos.cl/trabajo/18746-ito-civil-proyecto-area-de-salud-rancagua-3911130"
apply_url: "https://www.chiletrabajos.cl/trabajo/postular/3911130"
tags: ["civil", "rancagua", "ito"]
salary_text: ""
fetched_at: "2026-10-21T04:14:23"
fetch_status: "ok"
error: ""
---

# 18.746 ITO Civil - Proyecto área de Salud - Rancagua

- Empresa: DRS Ingeniería
- Ubicacion: Rancagua
- Publicado: 08 de Octubre de 2026
- Score legacy: 73
- Cluster: ITO & Aseguramiento de Calidad
- Tags: civil, rancagua, ito

## Descripcion

En DRS Ingeniería y Gestión estamos en búsqueda de un ITO Civil para proyecto relacionado al rubro de la salud, ubicado en Rancagua.

Duración proyecto: 5 meses

Funciones principales:

-Supervisar y controlar en terreno la correcta ejecución de las obras.

-Realizar inspección técnica de los trabajos, verificando el cumplimiento de planos, especificaciones técnicas y estándares establecidos.

-Coordinar y supervisar las actividades ejecutadas por contratistas y equipos de obra.

-Revisar y gestionar observaciones, desviaciones y eventuales incumplimientos detectados durante la ejecución.

-Coordinar las actividades necesarias para asegurar la continuidad operacional de la sede durante las obras

Requisitos:

-Título profesional de Ingeniero Civil, Constructor Civil o Ingeniero en Construcción.

-Mínimo 8 años de experiencia profesional general.

-Experiencia como ITO en obras similares.
