---
offer_id: "ch_af4ece8f462d"
offer_key: "3909340"
portal: "ChileTrabajos"
title: "Operador planta de Riles - San Bernardo (reemplazo vacaciones)"
company: "Aguas Andinas S.A"
location: "Santiago"
published: "05 de Octubre de 2026"
score_legacy: "71"
cluster_id: "C5_AGUA"
cluster_name: "Agua, Riles & Sanitario"
url: "https://www.chiletrabajos.cl/trabajo/operador-planta-de-riles-san-bernardo-reemplazo-vacaciones-3909340"
apply_url: "https://www.chiletrabajos.cl/trabajo/postular/3909340"
tags: ["riles", "bernardo", "san"]
salary_text: ""
fetched_at: "2026-10-21T04:16:24"
fetch_status: "ok"
error: ""
---

# Operador planta de Riles - San Bernardo (reemplazo vacaciones)

- Empresa: Aguas Andinas S.A
- Ubicacion: Santiago
- Publicado: 05 de Octubre de 2026
- Score legacy: 71
- Cluster: Agua, Riles & Sanitario
- Tags: riles, bernardo, san

## Descripcion

En Ecoriles, una de las filiales de Aguas Andinas, queremos integrar a personas Operadoras de Plantas de Riles para San Bernardo!

Somos el principal operador de plantas de tratamiento de Riles en Chile, entregando soluciones integrales a la industria aprovechando la sinergia con multinacionales líderes en el mercado del agua. Además, ofrecemos un ambiente inclusivo, programas de formación para tu desarrollo continuo, y políticas flexibles para el equilibrio trabajo - vida personal.

Misión del cargo: Controlar y llevar a cabo las labores de operación de la planta, bajo los estándares y normativa vigente de seguridad establecida, a fin de brindar un servicio de calidad, orientada a la satisfacción de los requerimientos del cliente.

Funciones principales:

- Operar los distintos equipos que componen la planta, en concordancia con los lineamientos de seguridad y calidad establecidos.

- Efectuar reporte de procesos y novedades en cada uno de sus turnos y registrar los datos obtenidos como resultado de los distintos análisis.

Requisitos:

- Técnico nivel medio eléctrico, mecánico, ambiental, químico.

- Experiencia en procesos industriales.

- Experiencia y/o conocimiento en tratamiento de riles.

- Disponibilidad para trabajar en San Bernardo.

- Disponibilidad para trabajar en turnos rotativos día y noche.

- Disponibilidad para trabajar como reemplazo de vacaciones por 4 meses.

Como organización, valoramos la inclusión, por lo que todas nuestras vacantes están alineadas con la Ley 21.015 de Inclusión Laboral. Si te interesa ser parte de un equipo que valora cada contribución y el compromiso, postula con nosotros, ¡Queremos conocerte!
