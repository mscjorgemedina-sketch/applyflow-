---
offer_id: "ch_1fd1d01a6f9e"
offer_key: "3916350"
portal: "ChileTrabajos"
title: "ITO Civil/Ing. Eléctrico"
company: "CGESTA"
location: "Santiago"
published: "19 de Octubre de 2026"
score_legacy: "73"
cluster_id: "C2_ITO"
cluster_name: "ITO & Aseguramiento de Calidad"
url: "https://www.chiletrabajos.cl/trabajo/ito-civil-ing-electrico-3916350"
apply_url: "https://www.chiletrabajos.cl/trabajo/postular/3916350"
tags: ["civil", "ito", "ingeniero"]
salary_text: ""
fetched_at: "2026-10-21T04:15:29"
fetch_status: "ok"
error: ""
---

# ITO Civil/Ing. Eléctrico

- Empresa: CGESTA
- Ubicacion: Santiago
- Publicado: 19 de Octubre de 2026
- Score legacy: 73
- Cluster: ITO & Aseguramiento de Calidad
- Tags: civil, ito, ingeniero

## Descripcion

INSPECTOR TÉCNICO DE OBRA

INGENIERO CIVIL / INGENIERO MECÁNICO / INGENIERO ELÉCTRICO o Profesión afín.

- Se requiere ITO Civil - Experiencia en retail, centro comercial, supermercado - Excluyente.

- Manejo de herramientas Office, Autocad.

- Disponibilidad inmediata.

- Residencia Región Metropolitana.
