---
offer_id: "ch_32ed89ce88dd"
offer_key: "3911405"
portal: "ChileTrabajos"
title: "ITO - Supervisor de Calidad en Construcción"
company: "GrupoEuro"
location: "Santiago"
published: "08 de Octubre de 2026"
score_legacy: "77"
cluster_id: "C2_ITO"
cluster_name: "ITO & Aseguramiento de Calidad"
url: "https://www.chiletrabajos.cl/trabajo/ito-supervisor-de-calidad-en-construccion-3911405"
apply_url: "https://www.chiletrabajos.cl/trabajo/postular/3911405"
tags: ["calidad", "técnica", "construcción"]
salary_text: ""
fetched_at: "2026-10-21T04:13:50"
fetch_status: "ok"
error: ""
---

# ITO - Supervisor de Calidad en Construcción

- Empresa: GrupoEuro
- Ubicacion: Santiago
- Publicado: 08 de Octubre de 2026
- Score legacy: 77
- Cluster: ITO & Aseguramiento de Calidad
- Tags: calidad, técnica, construcción

## Descripcion

DESCRIPCIÓN DEL PUESTO

Importante empresa del rubro construcción se encuentra en búsqueda de un/a ITO Supervisor/a de Calidad para integrarse al equipo de Calidad y participar en proyectos de alta exigencia técnica.

El propósito del cargo será supervisar y controlar los procesos de calidad e inspección técnica en obra, verificando el cumplimiento de planos, especificaciones técnicas, procedimientos constructivos, normativa aplicable y estándares definidos, contribuyendo a la correcta ejecución de las partidas, la trazabilidad documental y la disminución de desviaciones durante el desarrollo del proyecto.

Principales responsabilidades

Supervisar controles e inspecciones de calidad en terreno, verificando el cumplimiento técnico de las partidas de obra.

Controlar la implementación del plan de calidad, protocolos, puntos de inspección y registros asociados al proyecto.

Coordinar con equipos de terreno, oficina técnica, subcontratos y especialidades la revisión de partidas críticas.

Revisar documentación técnica de calidad, incluyendo protocolos, ensayos, certificados, registros fotográficos y respaldos de inspección.

Monitorear no conformidades, observaciones técnicas y acciones correctivas, realizando seguimiento a responsables, plazos y recurrencias.

Reportar avances, riesgos, brechas e indicadores de calidad al Jefe de Calidad y equipos de obra.

REQUISITOS

Requisitos del perfil

Formación profesional en Construcción, Ingeniería en Construcción, Construcción Civil o carrera afín.

5 años en proyectos de construcción.

3 años de experiencia en Inspección Técnica de Obra

Experiencia deseable en edificación en altura, obras habitacionales, inmobiliarias, industriales o proyectos de alta exigencia técnica. Experiencia en coordinación con subcontratistas, equipos de terreno, oficina técnica y mandantes.

Conocimientos especificaos:

Lectura e interpretación de planos y especificaciones técnicas. Control de calidad en obra y procesos constructivos. Protocolos de inspección, recepción de partidas y control documental. Gestión de no conformidades y acciones correctivas. Normativa técnica aplicable a construcción. AutoCAD, Revit, BIM 360 u otras herramientas similares, deseable.

Si cuentas con experiencia en calidad, inspección técnica o supervisión de obra, y quieres ser parte de proyectos desafiantes en la industria de la construcción, te invitamos a postular.
