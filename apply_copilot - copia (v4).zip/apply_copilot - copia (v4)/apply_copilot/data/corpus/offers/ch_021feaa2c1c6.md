---
offer_id: "ch_021feaa2c1c6"
offer_key: "3889733"
portal: "ChileTrabajos"
title: "Inspector QA/QC de correas transportadoras – Minería"
company: "Confidencial"
location: "Calama"
published: "21 de Septiembre de 2026"
score_legacy: "73"
cluster_id: "C2_ITO"
cluster_name: "ITO & Aseguramiento de Calidad"
url: "https://www.chiletrabajos.cl/trabajo/inspector-qa-qc-de-correas-transportadoras-mineria-3889733"
apply_url: "https://www.chiletrabajos.cl/trabajo/postular/3889733"
tags: ["transportadoras", "correas", "confiabilidad"]
salary_text: ""
fetched_at: "2026-10-21T04:15:06"
fetch_status: "ok"
error: ""
---

# Inspector QA/QC de correas transportadoras – Minería

- Empresa: Confidencial
- Ubicacion: Calama
- Publicado: 21 de Septiembre de 2026
- Score legacy: 73
- Cluster: ITO & Aseguramiento de Calidad
- Tags: transportadoras, correas, confiabilidad

## Descripcion

Empresa del rubro de servicios para la minería, requiere incorporar de manera confidencial a un/a Inspector(a) QA/QC de correas transportadoras, quien será responsable de asegurar el cumplimiento de los estándares de calidad y confiabilidad asociados al mantenimiento de correas transportadoras.

Principales funciones:

Inspeccionar y controlar la correcta ejecución de servicios de mantenimiento, reparaciones y empalmes de correas transportadoras.

Ejecutar y documentar radiografías industriales (RX) de empalmes con cable de acero, de acuerdo con procedimientos técnicos y de seguridad radiológica.

Realizar inspecciones, pruebas y mediciones de confiabilidad de equipos y sistemas.

Elaborar informes técnicos y predictivos sobre el estado de las correas transportadoras.

Mantener registros de inspecciones, calibraciones, mediciones y trazabilidad de los servicios.

Verificar la calidad y certificación de materiales, herramientas y equipos utilizados en los trabajos.

Identificar condiciones de riesgo y verificar la implementación de medidas de control.

Participar en reuniones de coordinación con equipos internos y clientes.

Proponer mejoras orientadas a aumentar la confiabilidad, calidad y eficiencia de los servicios.

Alimentar sistemas y software de confiabilidad y mantenimiento.

Requisitos:

Formación como Ingeniero de Ejecución Mecánica, Industrial, Técnico Avanzado o carrera afín.

Mínimo 5 años de experiencia demostrable en cargos similares.

Experiencia en mantenimiento y empalmes de correas transportadoras de tela y cable de acero.

Conocimientos en interpretación de radiografías industriales de empalmes con cable de acero y criterios de aceptación/rechazo según normativa.

Conocimientos de metrología, confiabilidad, aplicaciones de polímeros y equipos transportadores.

Manejo de herramientas de control de riesgos y seguridad en minería.

Manejo de Office nivel intermedio.

Licencia de conducir clase B.

Psicosensotécnico riguroso.

Salud compatible con trabajo en faena.

Disponibilidad para trabajar bajo sistema de turnos/faena, según requerimientos del contrato.

Beneficios

Seguro de salud

La empresa paga o copaga una cobertura de salud adicional.

Seguro de vida

¡La salud es lo más importante! La empresa paga el seguro de vida

Seguro dental

Paga o copaga un seguro dental.

Mutual de Seguridad

La empresa esta adscrita a la mutual de seguridad

Caja de compensación

La empresa esta adscrita a una caja de compensación

Casino

La empresa incluye casino para la alimentación

Uniforme

La empresa provee el uniforme de trabajo
