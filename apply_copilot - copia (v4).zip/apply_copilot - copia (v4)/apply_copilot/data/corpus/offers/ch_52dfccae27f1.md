---
offer_id: "ch_52dfccae27f1"
offer_key: "3910430"
portal: "ChileTrabajos"
title: "INSPECTOR QA/QC – CONTROL DE CALIDAD PIPING"
company: "CONSORCIO DELGADO IBB MONTAJES SPA"
location: "Concepción"
published: "07 de Octubre de 2026"
score_legacy: "77"
cluster_id: "C2_ITO"
cluster_name: "ITO & Aseguramiento de Calidad"
url: "https://www.chiletrabajos.cl/trabajo/inspector-qa-qc-control-de-calidad-piping-3910430"
apply_url: "https://www.chiletrabajos.cl/trabajo/postular/3910430"
tags: ["montaje", "piping", "calidad"]
salary_text: ""
fetched_at: "2026-10-21T04:13:25"
fetch_status: "ok"
error: ""
---

# INSPECTOR QA/QC – CONTROL DE CALIDAD PIPING

- Empresa: CONSORCIO DELGADO IBB MONTAJES SPA
- Ubicacion: Concepción
- Publicado: 07 de Octubre de 2026
- Score legacy: 77
- Cluster: ITO & Aseguramiento de Calidad
- Tags: montaje, piping, calidad

## Descripcion

Empresa líder en montaje y servicios industriales se encuentra en la búsqueda de un(a) Inspector(a) QA/QC Piping, con sólida experiencia en control de calidad, aseguramiento de procesos técnicos y seguimiento de proyectos industriales de alta exigencia.

Residencia en Concepción o intercomuna (Chiguayante, San Pedro, Talcahuano, coronel)

Funciones principales

Responsable de asegurar y controlar que todas las etapas de fabricación, montaje, soldadura y pruebas de los sistemas de tuberías cumplan con las normas técnicas, planos y especificaciones del proyecto. Entre sus funciones se consideran:

• Ejecutar controles de calidad en campo sobre actividades de fabricación y montaje de piping.

• Controlar y verificar el cumplimiento de los Planes de Inspección y Ensayo (PIE).

• Supervisar soldaduras, ensayos no destructivos (END), trazabilidad de materiales y torqueo de uniones bridadas.

• Inspeccionar montaje de cañerías, soportes, accesorios y alineación de equipos asociados.

• Revisar e interpretar isométricos, P&ID, planos de taller y Procedimientos de Soldadura (WPS/PQR).

• Confeccionar, estructurar y mantener al día el Welding Book, dossiers de calidad y liberación de Pruebas Hidráulicas (PH).

• Detectar desviaciones, gestionar No Conformidades (NC) y participar en análisis de causa raíz y auditorías internas.

Requisitos

• Formación: Ingeniero Mecánico, Ingeniero Ejecución Mecánico o Técnico Nivel Superior Industrial.

• Experiencia de 2 a 3 años en Fabricación de spools, montaje de cañerías de proceso bajo códigos de presión, ensayos no destructivos (END), alineación de equipos rotatorios y pruebas de hermeticidad en empresas de construcción, montaje industrial, mantenimiento, minería, energía, petroquímica o servicios industriales.

• Inspección de prefabricado y montaje de piping, revestimientos y torqueo de uniones bridadas.

• Manejo de Microsoft Excel, Auto Cad a nivel intermedio/avanzado.

• Normativa de Dominio: ASME B31.3 (Process Piping), ASME BPVC Secc. VIII Div. 1, ASME Secc. IX (Soldadura), AWS D1.1 y API.

• Lectura e interpretación de planos, P&ID e isométricos.

• Manejo de documentación QA/QC.

• Disponibilidad para trabajar y realizar visitas a obras dentro y fuera de la zona, cuando sea requerido.

• Se valora certificaciones VT, PT, UT Nivel II.

• Conocimientos en inspección de revestimientos.

• Conocimientos en ejecución de tie-ins (incluyendo Hot Tapping)

Se ofrece

• Incorporación a empresa del rubro de montaje y servicios industriales.

• Contrato de trabajo con proyección de continuidad, sujeto a desempeño.

• Buen ambiente laboral.

• Posibilidades de desarrollo profesional.

• Capacitaciones técnicas.

• Seguro complementario de salud.

Beneficios

Seguro de salud

La empresa paga o copaga una cobertura de salud adicional.

Vestimenta informal

Utiliza lo que desees, sin dresscode.

Bus acercamiento

La empresa provee un bus de acercamiento

Día de cumpleaños libre

El día de tu cumpleaños es canjeable por un día completo de vacaciones.

Mutual de Seguridad

La empresa esta adscrita a la mutual de seguridad

Caja de compensación

La empresa esta adscrita a una caja de compensación

Casino

La empresa incluye casino para la alimentación
