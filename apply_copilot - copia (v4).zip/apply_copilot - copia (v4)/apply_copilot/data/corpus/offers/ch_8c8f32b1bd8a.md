---
offer_id: "ch_8c8f32b1bd8a"
offer_key: "3910075"
portal: "ChileTrabajos"
title: "ITO especialidad Eléctrica - Antofagasta"
company: "The Mind Cloud Company"
location: "Antofagasta"
published: "06 de Octubre de 2026"
score_legacy: "73"
cluster_id: "C2_ITO"
cluster_name: "ITO & Aseguramiento de Calidad"
url: "https://www.chiletrabajos.cl/trabajo/ito-especialidad-electrica-antofagasta-3910075"
apply_url: "https://www.chiletrabajos.cl/trabajo/postular/3910075"
tags: ["eléctricos", "proyecto", "técnica"]
salary_text: ""
fetched_at: "2026-10-21T04:15:17"
fetch_status: "ok"
error: ""
---

# ITO especialidad Eléctrica - Antofagasta

- Empresa: The Mind Cloud Company
- Ubicacion: Antofagasta
- Publicado: 06 de Octubre de 2026
- Score legacy: 73
- Cluster: ITO & Aseguramiento de Calidad
- Tags: eléctricos, proyecto, técnica

## Descripcion

DESCRIPCIÓN DEL PUESTO

Mindco, empresa especialista en consultoría en gestión de activos para grandes industrias, se encuentra en la búsqueda de una/o Especialista ITO Eléctrico para sumarse a nuestro equipo en un proyecto del rubro energético.

Para este cargo, se valorará experiencia en inspección técnica de obras eléctricas, supervisión de montaje eléctrico y validación de instalaciones en terreno, idealmente en proyectos industriales, energéticos, eléctricos, renovables o sistemas BESS. Buscamos un perfil con alta rigurosidad técnica, orientación al trabajo en terreno, capacidad de análisis y comunicación efectiva con equipos multidisciplinarios.

Principales funciones:

Inspeccionar sistemas eléctricos en terreno, verificando su correcta instalación, condición técnica y cumplimiento de los estándares del proyecto. Validar que las instalaciones eléctricas ejecutadas estén conforme a planos, especificaciones técnicas, ingeniería de detalle y documentación del proyecto. Identificar brechas técnicas, desviaciones o condiciones no conformes asociadas a los sistemas eléctricos del activo. Apoyar el levantamiento de desviaciones, No Conformidades y Punch List, contribuyendo al proceso de handover y transición del proyecto hacia operación.

Requisitos:

Profesional titulado/a de Ingeniería Eléctrica, Ingeniería de Ejecución Eléctrica, Técnico/a de Nivel Superior en Electricidad o carrera afín. Al menos 2 años de experiencia en inspección técnica, supervisión de obras eléctricas, montaje eléctrico o funciones similares. Experiencia en el rubro industrial, idealmente en el sector energético, proyectos eléctricos, subestaciones, plantas de generación, energías renovables o sistemas BESS. Conocimiento en interpretación de planos eléctricos, diagramas unilineales, especificaciones técnicas, datasheets y documentación de ingeniería. Experiencia en identificación de desviaciones, brechas técnicas, No Conformidades y elaboración o apoyo en Punch List. Licencia de conducir.

Modalidad:

Presencial - región de Antofagasta. Jornada: Lunes a jueves 08:30 a 18:00 y viernes 08:30 a 15:00 horas.

En Mindco estamos comprometidos con la equidad, diversidad e inclusión. Si necesitas adaptaciones en tu proceso de selección, avísanos para brindarte la mejor experiencia posible.

¡Si cumples con los requisitos y estás listo/a para un nuevo desafío dentro de un importante proyecto, postula ahora y únete a nuestro equipo!
