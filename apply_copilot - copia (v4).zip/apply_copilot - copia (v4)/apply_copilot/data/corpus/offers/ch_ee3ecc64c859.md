---
offer_id: "ch_ee3ecc64c859"
offer_key: "3889114"
portal: "ChileTrabajos"
title: "Planificador de Mantenimiento (Arica)"
company: "Coca-Cola Embonor"
location: "Arica"
published: "26 de Agosto de 2026"
score_legacy: "77"
cluster_id: "C3_MECANICA"
cluster_name: "Mecánica, Maestranza & Mantenimiento"
url: "https://www.chiletrabajos.cl/trabajo/planificador-de-mantenimiento-arica-3889114"
apply_url: "https://www.chiletrabajos.cl/trabajo/postular/3889114"
tags: ["mantenimiento", "ingeniería", "arica"]
salary_text: ""
fetched_at: "2026-10-21T04:13:21"
fetch_status: "ok"
error: ""
---

# Planificador de Mantenimiento (Arica)

- Empresa: Coca-Cola Embonor
- Ubicacion: Arica
- Publicado: 26 de Agosto de 2026
- Score legacy: 77
- Cluster: Mecánica, Maestranza & Mantenimiento
- Tags: mantenimiento, ingeniería, arica

## Descripcion

En Coca-Cola Embonor estamos en búsqueda de Planificador de Mantenimiento para desempeñarse en el área Industrial en su Planta de Arica.

¿Cuál será tu principal desafío?

Planificar y programar los procesos de mantenimiento de la planta y centros de distribución mediante la adecuada administración de los recursos disponibles, utilizando las herramientas administrativas, financieras y de recursos humanos para una correcta ejecución del mantenimiento. Además, cumplir con el plan de mantenimiento preventivo y correctivo de todas las instalaciones de la compañía (productivas y no productivas), asegurando su disponibilidad y minimizando las paradas no planificadas.

Requisitos:

-Título de Ingeniería Industrial, Ingeniería Mecánica, Ingeniería Eléctrica, Ingeniería Electrónica, Automatización o carrera afín.

-Al menos 3 años de experiencia en cargos similares (planificación).

-Idealmente contar con experiencia en industrias alimentarias o industriales.

-Conocimiento de Normas ISO 9001, 14001, 22000 + PAS 220, OSHAS 18000.

-Manejo de procesos industriales y control presupuestario.

-Ideal manejo de SAP (no excluyente)

Condiciones y Beneficios:

-Contrato a plazo fijo, luego indefinido.

-Casino.

-Beneficios área de bienestar.
