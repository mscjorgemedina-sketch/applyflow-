---
offer_id: "ch_53e3d0a3bfb0"
offer_key: "3907625"
portal: "ChileTrabajos"
title: "ITO Civil para Centro Comercial y Estación de Servicio - Puerto Montt"
company: "DFV Ingeniería y Gestión"
location: "Puerto Montt"
published: "06 de Octubre de 2026"
score_legacy: "73"
cluster_id: "C2_ITO"
cluster_name: "ITO & Aseguramiento de Calidad"
url: "https://www.chiletrabajos.cl/trabajo/ito-civil-para-centro-comercial-y-estacion-de-servicio-puerto-montt-3907625"
apply_url: "https://www.chiletrabajos.cl/trabajo/postular/3907625"
tags: ["puerto", "montt", "obra"]
salary_text: ""
fetched_at: "2026-10-21T04:14:18"
fetch_status: "ok"
error: ""
---

# ITO Civil para Centro Comercial y Estación de Servicio - Puerto Montt

- Empresa: DFV Ingeniería y Gestión
- Ubicacion: Puerto Montt
- Publicado: 06 de Octubre de 2026
- Score legacy: 73
- Cluster: ITO & Aseguramiento de Calidad
- Tags: puerto, montt, obra

## Descripcion

En DFV Ingeniería y Gestión nos encontramos en búsqueda de un(a) Inspector(a) Técnico(a) de Obras, para incorporarse a un importante proyecto de Centro Comercial y Estación de Servicio en Puerto Montt.

Buscamos profesionales con experiencia en proyectos de retail, idealmente con participación en obras vinculadas al rubro de combustibles o estaciones de servicio.

Objetivo del cargo:

Coordinar, supervisar y asegurar la correcta ejecución técnica y administrativa de las obras, garantizando el cumplimiento de los estándares de calidad, plazos, seguridad y normativas vigentes.

Principales funciones:

- Coordinar entre el Mandante y la empresa constructora las actividades técnicas y administrativas necesarias para la correcta ejecución del proyecto.

- Controlar, almacenar y respaldar la documentación oficial de la obra, incluyendo planos, permisos, certificados y contratos.

- Gestionar permisos de trabajo y trámites ante organismos municipales y entidades reguladoras.

- Revisar y validar Planes de Calidad, protocolos de recepción de partidas y procedimientos constructivos.

- Supervisar la ejecución de obras, ensayes y calibración de equipos.

- Coordinar reuniones de obra, registrar avances y elaborar informes periódicos para el Mandante.

- Controlar el avance físico de la obra mediante herramientas de planificación y programación.

- Revisar y aprobar estados de pago y modificaciones de obra presentadas por la constructora.

- Gestionar el proceso de cierre de obra, incluyendo actas de recepción, levantamiento de observaciones y documentación final.

- Apoyar en etapas previas a la ejecución mediante la revisión de antecedentes y propuestas técnicas.

Requisitos:

- Título profesional de Ingeniería Civil, Ingeniería en Construcción, Construcción Civil o carrera afín.

- Experiencia desempeñándose como ITO Civil en proyectos de retail, centros comerciales o infraestructura comercial.

- Deseable experiencia en proyectos asociados a estaciones de servicio o combustible.

- Conocimientos en normativas técnicas, gestión y control de proyectos de construcción.

- Manejo de herramientas de planificación y seguimiento de proyectos.

- Disponibilidad para desempeñarse en Puerto Montt.

Condiciones:

- Proyecto ubicado en Puerto Montt.

- Modalidad de trabajo 100% presencial.

Beneficios

Mutual de Seguridad

La empresa esta adscrita a la mutual de seguridad

Caja de compensación

La empresa esta adscrita a una caja de compensación
