---
offer_id: "ch_dcf4a74892cb"
offer_key: "3908461"
portal: "ChileTrabajos"
title: "OPERADOR PLANTA DE RILES"
company: "Nova Austral S.A."
location: "Porvenir"
published: "02 de Octubre de 2026"
score_legacy: "71"
cluster_id: "C5_AGUA"
cluster_name: "Agua, Riles & Sanitario"
url: "https://www.chiletrabajos.cl/trabajo/operador-planta-de-riles-3908461"
apply_url: "https://www.chiletrabajos.cl/trabajo/postular/3908461"
tags: ["planta", "riles", "operador"]
salary_text: ""
fetched_at: "2026-10-21T04:15:40"
fetch_status: "ok"
error: ""
---

# OPERADOR PLANTA DE RILES

- Empresa: Nova Austral S.A.
- Ubicacion: Porvenir
- Publicado: 02 de Octubre de 2026
- Score legacy: 71
- Cluster: Agua, Riles & Sanitario
- Tags: planta, riles, operador

## Descripcion

Empresa Nova Austral S.A. requiere contratar Operador para su Planta de riles en Porvenir, Tierra del Fuego.

Requisitos:

Enseñanza media completa

Deseable que tenga conocimientos en manejo de químicos y operación de planta de riles.

Competencias/habilidades requeridas: Seguimiento y respeto por instrucciones y procedimientos. Ser meticuloso. Capacidad de observación, análisis de la información. Mantención de atención y concentración.

Jornada de trabajo 6x1 en turnos rotativos.

Interesados adjuntar Cv actualizado.

¡Súmate a nuestro equipo de trabajo!

Beneficios

Estacionamiento de bicicletas

Cuidamos sus pertenencias y ofrecen un lugar para estacionar bicicletas.

Mutual de Seguridad

La empresa esta adscrita a la mutual de seguridad

Caja de compensación

La empresa esta adscrita a una caja de compensación

Casino

La empresa incluye casino para la alimentación

Uniforme

La empresa provee el uniforme de trabajo
