---
offer_id: "ch_fbe5a6701e4f"
offer_key: "3913903"
portal: "ChileTrabajos"
title: "IT Project Manager Senior Supply Chain & AI"
company: "BCTecnologia"
location: "Santiago"
published: "14 de Octubre de 2026"
score_legacy: "75"
cluster_id: "C1_GESTION"
cluster_name: "Gestión de Proyectos & Contratos"
url: "https://www.chiletrabajos.cl/trabajo/it-project-manager-senior-supply-chain-ai-3913903"
apply_url: "https://www.chiletrabajos.cl/trabajo/postular/3913903"
tags: ["supply", "chain", "herramientas"]
salary_text: ""
fetched_at: "2026-10-21T04:14:05"
fetch_status: "ok"
error: ""
---

# IT Project Manager Senior Supply Chain & AI

- Empresa: BCTecnologia
- Ubicacion: Santiago
- Publicado: 14 de Octubre de 2026
- Score legacy: 75
- Cluster: Gestión de Proyectos & Contratos
- Tags: supply, chain, herramientas

## Descripcion

IT Project Manager Senior Supply Chain & AI

Objetivo del cargo

Gestionar proyectos de tecnología de alcance global para el dominio de Supply Chain & Operations y/o iniciativas emergentes en las subsidiarias de Latam South (Perú, Ecuador, Brasil y Colombia).

El cargo requiere gestión de stakeholders internos y externos, y liderar a personal especializado en el desarrollo de soluciones tecnológicas apalancadas, en su mayoría, en Inteligencia Artificial.

Principales responsabilidades

Administrar el portafolio de proyectos asignados: alcance, cronograma, presupuesto, riesgos y recursos, con visibilidad diaria del estado.

Coordinar equipos multidisciplinarios, proveedores externos y stakeholders de distintas geografías en sesiones de steerco, seguimiento, dailies o bajo demanda.

Revisar el avance, los hitos, los entregables y los compromisos, reportando riesgos a tiempo y aplicando acciones correctivas.

Velar por la aplicación de metodologías, estándares, lineamientos de seguridad y gobierno corporativo definidos por Gobierno TI.

Participar en todo el ciclo de vida del proyecto, desde el kickoff hasta la implementación o el paso a continuidad operacional.

Participar en comités de proyecto, seguimiento ejecutivo y reuniones de coordinación con negocio y TI.

Mantener comunicación permanente con sponsors, usuarios clave y partes interesadas.

Requisitos

Formación: Ingeniería Civil Informática, Ingeniería Civil Industrial o carrera afín.

Experiencia laboral total: 5 a 10 años.

Experiencia específica: tecnología y/o Supply Chain.

Inglés intermedio, especialmente para lectura de documentación.

Conocimientos técnicos y herramientas

Microsoft Project, Planner, Azure DevOps o equivalentes.

Suite Microsoft 365 (Excel, Power BI, Teams, PowerPoint, Visio).

Ecosistema SAP y plataformas empresariales relacionadas.

Git y herramientas de control de versiones.

Herramientas colaborativas y de gestión de proyectos.

Soluciones cloud y plataformas de integración.

Herramientas de análisis de datos y reportería ejecutiva.

Deseable

Certificaciones en gestión de proyectos TI y equipos de desarrollo ágil (no excluyente).

Beneficios

Seguro de salud

La empresa paga o copaga una cobertura de salud adicional.

Seguro de vida

¡La salud es lo más importante! La empresa paga el seguro de vida

Día de cumpleaños libre

El día de tu cumpleaños es canjeable por un día completo de vacaciones.

Mutual de Seguridad

La empresa esta adscrita a la mutual de seguridad

Caja de compensación

La empresa esta adscrita a una caja de compensación

Trabajo Híbrido

Se trabaja en modalidad híbrida, puedes trabajar desde tu casa y en oficina.
