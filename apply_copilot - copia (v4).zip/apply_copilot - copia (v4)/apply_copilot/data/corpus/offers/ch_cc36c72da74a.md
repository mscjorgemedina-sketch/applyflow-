---
offer_id: "ch_cc36c72da74a"
offer_key: "3865844"
portal: "ChileTrabajos"
title: "Supervisor de Mantenimiento"
company: "Mr Joy"
location: "Santiago"
published: "04 de Octubre de 2026"
score_legacy: "71"
cluster_id: "C3_MECANICA"
cluster_name: "Mecánica, Maestranza & Mantenimiento"
url: "https://www.chiletrabajos.cl/trabajo/supervisor-de-mantenimiento-3865844"
apply_url: "https://www.chiletrabajos.cl/trabajo/postular/3865844"
tags: ["mantenimiento", "supervisor"]
salary_text: ""
fetched_at: "2026-10-21T04:16:04"
fetch_status: "ok"
error: ""
---

# Supervisor de Mantenimiento

- Empresa: Mr Joy
- Ubicacion: Santiago
- Publicado: 04 de Octubre de 2026
- Score legacy: 71
- Cluster: Mecánica, Maestranza & Mantenimiento
- Tags: mantenimiento, supervisor

## Descripcion

En MR. JOY estamos buscando al mejor talento!

Buscamos un Supervisor de Mantenimiento para liderar el área de mantenimiento de nuestros parques de entretención, asegurando la continuidad operativa de los juegos, equipos e infraestructura.

Principales funciones:

Supervisar mantenimientos preventivos y correctivos.

Liderar el equipo de mantenimiento.

Planificar y controlar cronogramas de trabajo.

Gestionar proveedores, compras y repuestos.

Controlar indicadores (KPIs), presupuesto e inventarios.

Elaborar informes de gestión.

Capacitar al equipo y velar por el cumplimiento de normas de seguridad.

Requisitos

Formación en Ingeniería Mecánica, Eléctrica, Electromecánica, Industrial o carrera afín.

Experiencia mínima de 3 años liderando áreas de mantenimiento.

Conocimientos en mantenimiento preventivo y correctivo, gestión de equipos e indicadores.

Manejo de Excel y ERP (deseable).

Disponibilidad para trasladarse entre nuestros centros.

Ofrecemos

Estabilidad laboral.

Desarrollo profesional.

Excelente ambiente de trabajo.

Beneficios corporativos.

Envía tu CV a: reclutamiento@mrjoy.cl
