---
offer_id: "ch_dd60f635ee8a"
offer_key: "3914718"
portal: "ChileTrabajos"
title: "18.914 ITO Sanitario - Proyecto Edificación"
company: "DRS Ingeniería"
location: "Santiago"
published: "15 de Octubre de 2026"
score_legacy: "77"
cluster_id: "C2_ITO"
cluster_name: "ITO & Aseguramiento de Calidad"
url: "https://www.chiletrabajos.cl/trabajo/18914-ito-sanitario-proyecto-edificacion-3914718"
apply_url: "https://www.chiletrabajos.cl/trabajo/postular/3914718"
tags: ["proyecto", "ito", "instalaciones"]
salary_text: ""
fetched_at: "2026-10-21T04:13:28"
fetch_status: "ok"
error: ""
---

# 18.914 ITO Sanitario - Proyecto Edificación

- Empresa: DRS Ingeniería
- Ubicacion: Santiago
- Publicado: 15 de Octubre de 2026
- Score legacy: 77
- Cluster: ITO & Aseguramiento de Calidad
- Tags: proyecto, ito, instalaciones

## Descripcion

En DRS Ingeniería y Gestión estamos en búsqueda de un ITO Sanitario para proyecto de Edificación, ubicada en Santiago.

Duración del proyecto: 3 meses

Funciones principales:

-Realizar visitas técnicas a obra para inspeccionar las instalaciones sanitarias.

-Verificar que los trabajos ejecutados cumplan con los planos, especificaciones técnicas y antecedentes aprobados del proyecto.

-Supervisar el cumplimiento de los requisitos técnicos y normativos aplicables a las instalaciones sanitarias.

-Identificar desviaciones, deficiencias e incumplimientos durante las inspecciones.

-Elaborar informes técnicos con las observaciones, recomendaciones y medidas correctivas correspondientes.

Requisitos:

-Título profesional de Ingeniero Civil, Ingeniero Constructor o Constructor Civil.

-Al menos 8 años de experiencia profesional general.

-Experiencia como ITO de instalaciones sanitarias en obras similares.
