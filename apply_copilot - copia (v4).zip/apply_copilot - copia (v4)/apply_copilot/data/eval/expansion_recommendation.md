# Recomendacion de expansion

Criterio: un mercado se amplia si el perfil ya tiene evidencia y hay al menos 8 avisos; se prueba si hay 3-7; se descarta si no hay fit o demanda.

| Mercado | Avisos | Fit | Decision | Comentario |
|---|---|---|---|---|
| Confiabilidad / RCA | >=30 | No | Gap: no ampliar sin evidencia de perfil | Datos observados en busqueda publica |
| Planificacion de mantenimiento | 15 | Si | Ampliar | Datos observados en busqueda publica |
| Commissioning / puesta en marcha | 12 | No | Gap: no ampliar sin evidencia de perfil | Datos observados en busqueda publica |
| Project controls / PMO | 10 | No | Gap: no ampliar sin evidencia de perfil | Datos observados en busqueda publica |
| Control de costos | >=30 | No | Gap: no ampliar sin evidencia de perfil | Datos observados en busqueda publica |
| Abastecimiento tecnico | 18 | No | Gap: no ampliar sin evidencia de perfil | Datos observados en busqueda publica |
| HVAC / climatizacion | >=30 | No | Gap: no ampliar sin evidencia de perfil | Datos observados en busqueda publica |
| Eficiencia energetica | >=30 | No | Gap: no ampliar sin evidencia de perfil | Datos observados en busqueda publica |
| Diseno mecanico | 10 | Si | Ampliar | Datos observados en busqueda publica |
| Asset management | 13 | No | Gap: no ampliar sin evidencia de perfil | Datos observados en busqueda publica |
| Administrador de contratos | >=30 | Si | Ampliar | Datos observados en busqueda publica |
| ITO mecanico | 17 | Si | Ampliar | Datos observados en busqueda publica |

## Decision

- **Ampliar ahora**: Planificacion de mantenimiento, Diseno mecanico, Administrador de contratos, ITO mecanico.
- **No ampliar sin cerrar gap**: Confiabilidad / RCA, Commissioning / puesta en marcha, Project controls / PMO, Control de costos, Abastecimiento tecnico, HVAC / climatizacion, Eficiencia energetica, Asset management.

La decision final debe cruzar esta senal con la conversion real (`opened/filled/submitted/skipped`), no solo con el conteo de avisos.