# Comparacion de ranking

Generado: 2026-10-21T10:24:18  
Etiquetas: proxies objetivos (`positive` / `negative`), no etiquetas humanas.  
Las metricas son indicativas: el `market_fit` comparte senales con el motor v2.

## Muestra

- Ofertas evaluadas: **125**
- Positivas: **64**
- Negativas: **61**
- Sin etiqueta: **18**

## Metricas

| Metrica | Legacy | V2 | Market fit |
|---|---|---|---|
| precision@10 | 0.700 | 1.000 | 1.000 |
| recall@10 | 0.109 | 0.156 | 0.156 |
| ndcg@10 | 0.656 | 1.000 | 1.000 |
| average_precision | 0.630 | 0.913 | 0.871 |
| auc | 0.590 | 0.906 | 0.873 |
| spearman | 0.161 | 0.703 | 0.646 |

## Lectura

- `precision@10`: v2 - legacy = **+0.300** (mejora).
- `recall@10`: v2 - legacy = **+0.047** (mejora).
- `ndcg@10`: v2 - legacy = **+0.344** (mejora).
- `average_precision`: v2 - legacy = **+0.283** (mejora).
- `auc`: v2 - legacy = **+0.316** (mejora).
- `spearman`: v2 - legacy = **+0.542** (mejora).

## Limites

- No existe `applied_registry.json` ni historial de envios; no hay etiqueta positiva real.
- Las etiquetas negativas incluyen expiradas, duplicadas, junior y claims que el perfil no puede sostener.
- Si el corpus esta sesgado por las busquedas de `job_hunter.py`, la comparacion tambien lo esta.
- La decision debe complementarse con conversion real (`opened/filled/submitted/skipped`) cuando exista.
