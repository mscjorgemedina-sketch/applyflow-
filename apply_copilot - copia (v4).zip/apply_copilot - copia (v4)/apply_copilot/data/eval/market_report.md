# Informe de mercado - Apply Copilot

Generado: 2026-10-21T05:01:29  
Corpus: `C:\Users\USUARIO1\Downloads\apply_copilot - copia (v4)\apply_copilot\data\corpus\offers`  
Metodo: lectura de descripciones publicas + motor de sinonimos + proxies. Sin etiquetas humanas.

## Resumen ejecutivo

- Ofertas en el corpus: **143**; con descripcion usable: **143**.
- Clusters representados: **6**.
- Proxies: **64** positivas, **61** negativas, **18** sin etiqueta.
- Renta publicada: **6** ofertas (4.2%). Solo lectura; nunca se autocompleta.
- Mayor palanca: Construccion y montaje (75), Inspeccion Tecnica de Obra (71), Industria y plantas (70), QA/QC y aseguramiento de calidad (70), Ingeniero Mecanico (65).
- Mayores gaps: Ingenieria Civil / obra civil (77), Lider / lead (28), Agua potable y saneamiento (24), Control de costos (22), Antofagasta (21).

> El `market_fit` es un proxy, no una probabilidad de contratacion. Sirve para ordenar y detectar gaps, no para afirmar exito.

## Top 15 por market_fit

| ID | Titulo | Cluster | Legacy | Fit | Proxy |
|---|---|---|---|---|---|
| ch_601e2f02117b | Mecánico de Mantenimiento Industrial Lampa | Mecánica, Maestranza & Mante | 79 | 0.985 | positive |
| ch_d1057f286997 | ITO Residente para Obra Industrial | ITO & Aseguramiento de Calid | 73 | 0.970 | positive |
| ch_9834f89d6fb5 | 18.358 ITO Mecánico – Proyectos Industriales / Plantas  | ITO & Aseguramiento de Calid | 81 | 0.910 | positive |
| ch_bf244f542595 | ITO Mecánica Piping - La Greda | Ing. Mecánica Especializada | 73 | 0.910 | positive |
| ch_8efff47672fc | Especialista Mecánico piping | Piping, Montaje & Estructura | 81 | 0.902 | positive |
| ch_233c45e7ed50 | Ingeniero/a ITO QA/QC – Proyecto Minero | ITO & Aseguramiento de Calid | 73 | 0.892 | positive |
| ch_32ed89ce88dd | ITO - Supervisor de Calidad en Construcción | ITO & Aseguramiento de Calid | 77 | 0.887 | positive |
| ch_610c4908f09d | Jefe de Mantenimiento | Mecánica, Maestranza & Mante | 71 | 0.887 | positive |
| ch_81b7d735d6bf | Project Manager - Área Operaciones Laboratorio Químico | Gestión de Proyectos & Contr | 75 | 0.887 | positive |
| ch_b26d237da208 | Planificador(a) de Estudios - Montaje Industrial | Piping, Montaje & Estructura | 71 | 0.885 | positive |
| ch_fb757406c72f | PLANIFICADOR DE MANTENIMIENTO PLANTA SAP y Datos Maestr | Mecánica, Maestranza & Mante | 83 | 0.885 | positive |
| ch_4538303aa8be | Inspector Técnico de Obra Mecánico - Copiapo 4x3 | ITO & Aseguramiento de Calid | 81 | 0.880 | positive |
| ch_78a90979cf21 | Jefe(a) de Proyecto / ITO Visitador(a) (Por Proyecto) - | ITO & Aseguramiento de Calid | 73 | 0.873 | positive |
| ch_b8633eb0493f | ITO MECÁNICO – PIPING PROYECTO INDUSTRIAL MEJILLONES | ITO & Aseguramiento de Calid | 89 | 0.868 | positive |
| ch_a15c464f32b4 | INSPECTOR TECNICO SEC 3 - OSORNO | ITO & Aseguramiento de Calid | 78 | 0.842 | positive |

Se excluyen de esta tabla las ofertas con proxy `negative` (brecha de titulo, claims que el perfil no sostiene, expiradas, duplicadas o junior).

## Demanda por rol

| Rol | Ofertas | % | Titulo | Perfil | Estado |
|---|---|---|---|---|---|
| Inspeccion Tecnica de Obra | 71 | 49.7% | 55 | Si | Leverage |
| Ingeniero Mecanico | 65 | 45.5% | 17 | Si | Leverage |
| Mantenimiento | 34 | 23.8% | 20 | Si | Leverage |
| Operaciones | 33 | 23.1% | 13 | Si | Leverage |
| Planificacion | 27 | 18.9% | 7 | Si | Leverage |
| Control de costos | 22 | 15.4% | 0 | No | Gap |
| Maestranza | 22 | 15.4% | 2 | Si | Leverage |
| Comisionamiento y puesta en marcha | 11 | 7.7% | 6 | No | Gap |
| Confiabilidad | 10 | 7.0% | 0 | No | Gap |
| Project Manager | 9 | 6.3% | 7 | Si | Leverage |
| Administrador de Contratos | 7 | 4.9% | 4 | Si | Niche |
| Project Controls / PMO | 7 | 4.9% | 0 | No | Weak |

## Demanda por skill / certificacion

| Skill | Ofertas | % | Perfil | Estado |
|---|---|---|---|---|
| Ingenieria Civil / obra civil | 77 | 53.8% | No | Gap |
| QA/QC y aseguramiento de calidad | 70 | 49.0% | Si | Leverage |
| Piping y tuberias | 23 | 16.1% | Si | Leverage |
| AutoCAD | 17 | 11.9% | Si | Leverage |
| SAP | 10 | 7.0% | Si | Leverage |
| Soldadura | 9 | 6.3% | No | Gap |
| HVAC y climatizacion | 8 | 5.6% | No | Gap |
| Sistemas de bombeo | 7 | 4.9% | Si | Niche |
| Power BI | 6 | 4.2% | Si | Niche |
| ASME | 5 | 3.5% | Si | Niche |
| SEC | 5 | 3.5% | Si | Niche |
| ISO 9001 | 4 | 2.8% | Si | Niche |
| GLP / gas licuado | 3 | 2.1% | Si | Niche |
| Ensayos no destructivos | 3 | 2.1% | No | Weak |
| NFPA | 3 | 2.1% | Si | Niche |

## Clusters

| Cluster | Ofertas | Legacy avg | Fit avg | Conceptos top |
|---|---|---|---|---|
| ITO & Aseguramiento de Calidad | 68 | 74.9 | 0.664 | ito, qa_qc, construction, civil |
| Agua, Riles & Sanitario | 21 | 70.8 | 0.401 | water_sanitary, operations, santiago, industrial |
| Mecánica, Maestranza & Mantenimiento | 20 | 73.2 | 0.771 | mechanical_engineer, maestranza, maintenance, industrial |
| Gestión de Proyectos & Contratos | 15 | 73.5 | 0.642 | industrial, civil, cost_control, planning |
| Piping, Montaje & Estructuras | 15 | 74.7 | 0.716 | construction, piping, mechanical_engineer, industrial |
| Ing. Mecánica Especializada | 4 | 73.0 | 0.581 | mechanical_engineer, industrial, piping, maintenance |

## Renta publicada

| Alcance | Grupo | Ofertas | Min | Mediana | Max | % del grupo |
|---|---|---|---|---|---|---|
| overall | Todas las ofertas | 6 | $650.000 | $675.000 | $1.360.000 | 4.2% |
| cluster | ITO & Aseguramiento de Calidad | 3 | $650.000 | $700.000 | $1.360.000 | 4.4% |
| cluster | Agua, Riles & Sanitario | 2 | $650.000 | $650.000 | $650.000 | 9.5% |
| cluster | Piping, Montaje & Estructuras | 1 | $1.200.000 | $1.200.000 | $1.200.000 | 6.7% |

Muestras de lineas de renta publicada (texto original, sin normalizar):

- Solicitamos Operario para Planta de agua: `Salario liquido: 650.000 mas bono de 90.000`
- SOLDADOR PIPING 6G (SMAW) - MAESTRANZA LAMPA: `Renta líquida: $1.200.000 + bono de asistencia de $100.000.`
- INSPECTOR TECNICO DE GAS - 10MA REGION: `$650.000 líquido + $50.000 bono de responsabilidad o RENTA LIQUIDA: $750.000.- con auto, la empresa se hará cargo de pago de bencina y peajes. CONVERSABLE`
- Inspector Tecnico de Obra (ITO) - Punta Arenas: `Renta: $1.360.000 Líquido`
- INSPECTOR TECNICO SEC 3 - OSORNO: `$650.000 líquido + $50.000 bono de responsabilidad`
- Solicitamos Operario para planta de agua: `Salario liquido: 650.000 mas bono de 90.000`

## Gaps y palancas

**Leverage** = alta demanda + perfil lo tiene. **Gap** = alta demanda + perfil no lo tiene.

| Concepto | Tipo | Ofertas | Perfil | Estado |
|---|---|---|---|---|
| Ingenieria Civil / obra civil | skill | 77 | No | Gap |
| Construccion y montaje | sector | 75 | Si | Leverage |
| Inspeccion Tecnica de Obra | role | 71 | Si | Leverage |
| Industria y plantas | sector | 70 | Si | Leverage |
| QA/QC y aseguramiento de calidad | skill | 70 | Si | Leverage |
| Ingeniero Mecanico | role | 65 | Si | Leverage |
| Santiago / Region Metropolitana | location | 49 | Si | Leverage |
| Mineria | sector | 35 | Si | Leverage |
| Mantenimiento | role | 34 | Si | Leverage |
| Operaciones | role | 33 | Si | Leverage |
| Lider / lead | seniority | 28 | No | Gap |
| Planificacion | role | 27 | Si | Leverage |
| Agua potable y saneamiento | sector | 24 | No | Gap |
| Piping y tuberias | skill | 23 | Si | Leverage |
| Control de costos | role | 22 | No | Gap |
| Maestranza | role | 22 | Si | Leverage |
| Antofagasta | location | 21 | No | Gap |
| Jefatura | seniority | 19 | Si | Leverage |
| AutoCAD | skill | 17 | Si | Leverage |
| FIFO / faena | location | 12 | No | Gap |
| Comisionamiento y puesta en marcha | role | 11 | No | Gap |
| Energia y eficiencia energetica | sector | 11 | No | Gap |
| Confiabilidad | role | 10 | No | Gap |
| SAP | skill | 10 | Si | Leverage |
| Project Manager | role | 9 | Si | Leverage |
| Soldadura | skill | 9 | No | Gap |
| HVAC y climatizacion | skill | 8 | No | Gap |
| Remoto / hibrido | location | 8 | No | Gap |
| Turno 5x2 | location | 8 | No | Gap |

## Expansion

Busqueda adyacente en ChileTrabajos (conteo de avisos unicos; no es el corpus):

| Mercado | Query | Avisos | Fit perfil | Recomendacion |
|---|---|---|---|---|
| Confiabilidad / RCA | confiabilidad mantenimiento | >=30 | No | Gap: no ampliar sin evidencia de perfil |
| Planificacion de mantenimiento | planificador de mantenimiento | 15 | Si | Ampliar |
| Commissioning / puesta en marcha | commissioning | 12 | No | Gap: no ampliar sin evidencia de perfil |
| Project controls / PMO | project controls | 10 | No | Gap: no ampliar sin evidencia de perfil |
| Control de costos | control de costos | >=30 | No | Gap: no ampliar sin evidencia de perfil |
| Abastecimiento tecnico | abastecimiento tecnico | 18 | No | Gap: no ampliar sin evidencia de perfil |
| HVAC / climatizacion | HVAC | >=30 | No | Gap: no ampliar sin evidencia de perfil |
| Eficiencia energetica | eficiencia energetica | >=30 | No | Gap: no ampliar sin evidencia de perfil |
| Diseno mecanico | diseno mecanico | 10 | Si | Ampliar |
| Asset management | asset management | 13 | No | Gap: no ampliar sin evidencia de perfil |
| Administrador de contratos | administrador de contratos | >=30 | Si | Ampliar |
| ITO mecanico | ITO mecanico | 17 | Si | Ampliar |

## Metodologia y limites

- El corpus se construyo solo con ofertas `PENDING` de ChileTrabajos con score legacy >= 70.
- Las descripciones son publicas; no se abrio el formulario de postulacion.
- La demanda se mide por presencia de conceptos, no por intencion de contratacion.
- El `market_fit` combina cobertura core, titulo, ubicacion, frescura y empresa, con penalizaciones.
- Las etiquetas son proxies objetivos; no reemplazan validacion humana ni conversion real.
- La renta publicada se parsea con regex y puede contener ruido; se reporta como referencia, nunca para autocompletar.
