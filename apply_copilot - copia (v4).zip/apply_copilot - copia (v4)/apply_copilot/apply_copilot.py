#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Apply Copilot — orquestador (Fase 7: integración con job_hunter.py).

    python apply_copilot.py doctor                      # revisa que todo esté listo
    python apply_copilot.py list [--limit 15] [--min-score 60] [--all]
    python apply_copilot.py prepare <offer_id> [--open] # deja lista la oferta para la extensión
    python apply_copilot.py status [--app app_...]      # qué falta en la postulación actual
    python apply_copilot.py mark <offer_id> APPLIED --nota "enviada"

job_hunter.py NO se mueve ni se modifica: su carpeta se lee de config/settings.json ("job_hunter_dir")
o de la variable de entorno JOB_HUNTER_DIR. Requiere la versión con `--mark` (job_hunter v2).
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import urllib.error
import urllib.request
import webbrowser
from pathlib import Path
from typing import Any, Dict, List, Optional

sys.path.insert(0, str(Path(__file__).resolve().parent / "tools"))
import ac_common as ac  # noqa: E402

VALID_STATES = ("PENDING", "APPLIED", "INTERVIEW", "REJECTED", "DISCARDED")


# --------------------------------------------------------------------------- job_hunter
def resolve_job_hunter_dir(paths: ac.Paths, settings: Dict[str, Any]) -> Optional[Path]:
    """Variable de entorno > settings.json > carpeta del proyecto/padre. Devuelve la carpeta con job_hunter.py."""
    candidates = [os.environ.get("JOB_HUNTER_DIR"), settings.get("job_hunter_dir"), str(paths.root), str(paths.root.parent)]
    for c in candidates:
        if c and (Path(c) / "job_hunter.py").exists():
            return Path(c)
    return None


def load_offers(jh_dir: Path) -> Dict[str, Dict[str, Any]]:
    db = jh_dir / "data" / "jobs_database.json"
    if not db.exists():
        raise FileNotFoundError(f"No existe {db}. Corre primero: python job_hunter.py")
    data = ac.read_json(db)
    if not isinstance(data, dict):
        raise ValueError(f"{db} no tiene el formato esperado")
    return data


def load_states(jh_dir: Path) -> Dict[str, Any]:
    reg = jh_dir / "data" / "applied_registry.json"
    try:
        data = ac.read_json(reg) if reg.exists() else {}
    except ValueError:
        return {}
    return data if isinstance(data, dict) else {}


def find_offer(offers: Dict[str, Dict[str, Any]], offer_id: str) -> Optional[Dict[str, Any]]:
    if offer_id in offers:
        return offers[offer_id]
    matches = [k for k in offers if k.startswith(offer_id)]
    return offers[matches[0]] if len(matches) == 1 else None


def setup(args) -> tuple:
    paths = ac.get_paths(args.root).ensure()
    settings = ac.load_settings(paths)
    return paths, settings


def need_job_hunter(paths: ac.Paths, settings: Dict[str, Any]) -> Path:
    jh = resolve_job_hunter_dir(paths, settings)
    if not jh:
        raise SystemExit("Error: no encuentro job_hunter.py. Pon su carpeta en config/settings.json (\"job_hunter_dir\") "
                         "o en la variable JOB_HUNTER_DIR.")
    return jh


# --------------------------------------------------------------------------- comandos
def cmd_list(args) -> int:
    paths, settings = setup(args)
    jh = need_job_hunter(paths, settings)
    try:
        offers, states = load_offers(jh), load_states(jh)
    except (FileNotFoundError, ValueError) as e:
        print(f"Error: {e}", file=sys.stderr)
        return 2
    rows = []
    for oid, o in offers.items():
        estado = states.get(oid, {}).get("estado", o.get("estado", "PENDING"))
        if not args.all and estado != "PENDING":
            continue
        if int(o.get("score", 0)) < args.min_score:
            continue
        rows.append((int(o.get("score", 0)), o.get("ultima_vez", ""), oid, o, estado))
    rows.sort(key=lambda r: r[1], reverse=True)   # más recientes primero...
    rows.sort(key=lambda r: -r[0])                 # ...y luego por score (orden estable)
    if not rows:
        print("No hay ofertas que cumplan el filtro. Prueba --min-score 0 o --all.")
        return 0
    print(f"{'ID':<18}{'Score':>5}  {'Portal':<14}{'Estado':<10}Cargo")
    for score, _, oid, o, estado in rows[: args.limit]:
        print(f"{oid:<18}{score:>5}  {str(o.get('portal', ''))[:13]:<14}{estado:<10}{str(o.get('titulo', ''))[:70]}")
    if len(rows) > args.limit:
        print(f"... y {len(rows) - args.limit} más (usa --limit)")
    print("\nSiguiente paso: python apply_copilot.py prepare <ID> --open")
    return 0


def cmd_prepare(args) -> int:
    paths, settings = setup(args)
    jh = need_job_hunter(paths, settings)
    try:
        offers = load_offers(jh)
    except (FileNotFoundError, ValueError) as e:
        print(f"Error: {e}", file=sys.stderr)
        return 2
    offer = find_offer(offers, args.offer_id)
    if not offer:
        print(f"Error: no encuentro la oferta '{args.offer_id}'. Usa: python apply_copilot.py list", file=sys.stderr)
        return 2
    url = str(offer.get("url", ""))
    ctx = {"offer_id": offer.get("id", args.offer_id), "url": url, "title": offer.get("titulo", ""),
           "portal": offer.get("portal", ""), "score": offer.get("score"), "prepared_at": ac.now_iso()}
    ac.atomic_write_json(paths.current_offer, ctx)
    print(f"✔ Oferta lista: {ctx['title']}  [{ctx['portal']}, score {ctx['score']}]")
    print(f"  ID: {ctx['offer_id']}\n  URL: {url}")
    if args.open:
        if url.lower().startswith(("http://", "https://")):
            webbrowser.open(url)
        else:
            print("  ⚠ La URL no es http(s); no se abrió automáticamente.")
        print("\nPasos (autofill v3):\n"
          "  1. Receiver v5 corriendo: python tools/receiver.py (escucha en 127.0.0.1:8766)\n"
          "  2. Abre la oferta y entra al formulario; inicia sesión tú si hace falta\n"
          "  3. La extensión rellena sola al cargar; si no, icono > 'Rellenar todas las pestañas'\n"
          "  4. Revisa carta/sueldo, adjunta el CV y ENVÍA TÚ\n"
          f"  5. python apply_copilot.py mark {ctx['offer_id']} APPLIED")
    return 0


def _count(path: Path, pattern: str) -> int:
    return len(list(path.glob(pattern))) if path.exists() else 0


def cmd_status(args) -> int:
    paths, _ = setup(args)
    if args.app:
        app = ac.safe_id(args.app)
        if not app:
            print("Error: ID inválido.", file=sys.stderr)
            return 2
    else:
        latest = ac.latest_file(paths.bundles, "*_questions.json")
        if not latest:
            print("Aún no hay postulaciones. Extrae preguntas con la extensión (¿está corriendo el receiver?).")
            return 0
        app = ac.app_id_from_name(latest, "_questions.json")

    bundle_p = paths.bundles / f"{app}_questions.json"
    prompt_p = paths.prompts / f"{app}_qwen_prompt.md"
    raw_p = paths.answers / f"{app}_answers_raw.json"
    appr_p = paths.answers / f"{app}_approved.json"
    ev_dir = paths.evidence / app
    done = lambda ok: "✔" if ok else "·"  # noqa: E731

    print(f"Postulación {app}")
    nfields = None
    if bundle_p.exists():
        try:
            b = ac.read_json(bundle_p)
            nfields = len(b.get("fields", []))
            print(f"  {done(True)} Bundle: {nfields} campos | {b.get('portal')} | {b.get('title')} | offer_id={b.get('offer_id')}")
        except ValueError:
            print("  ✖ Bundle ilegible")
    else:
        print(f"  {done(False)} Bundle (no existe)")
    print(f"  {done(prompt_p.exists())} Prompt para Qwen")
    print(f"  {done(raw_p.exists())} Respuesta cruda de Qwen")
    if appr_p.exists():
        try:
            s = ac.read_json(appr_p).get("summary", {})
            print(f"  ✔ Respuestas aprobadas: AUTO {s.get('AUTO', '?')} | REVIEW {s.get('REVIEW', '?')} | HUMAN {s.get('HUMAN', '?')}")
        except ValueError:
            print("  ✖ approved ilegible")
    else:
        print(f"  {done(False)} Respuestas aprobadas")
    shots = sorted(p.name for p in ev_dir.glob("*")) if ev_dir.exists() else []
    print(f"  {done(bool(shots))} Evidencia: {', '.join(shots) if shots else 'ninguna'}")

    if not bundle_p.exists():
        nxt = "Extraer preguntas con la extensión"
    elif not prompt_p.exists():
        nxt = "python tools/make_qwen_prompt.py --latest"
    elif not raw_p.exists():
        nxt = f"Pegar el prompt en Qwen y guardar su respuesta en data/answers/{app}_answers_raw.json"
    elif not appr_p.exists():
        nxt = "python tools/validate_answers.py --latest-bundle --latest-answers"
    elif not any("filled" in n for n in shots):
        nxt = "Extensión: '2. Cargar respuestas' y '3. Rellenar campos'"
    else:
        nxt = "Revisar la página, enviar TÚ y marcar con: python apply_copilot.py mark <offer_id> APPLIED"
    print(f"\nSiguiente paso: {nxt}")
    return 0


def cmd_mark(args) -> int:
    paths, settings = setup(args)
    jh = need_job_hunter(paths, settings)
    estado = args.estado.upper()
    if estado not in VALID_STATES:
        print(f"Error: estado inválido '{args.estado}'. Usa: {', '.join(VALID_STATES)}", file=sys.stderr)
        return 2
    if not ac.safe_id(args.offer_id):
        print("Error: offer_id inválido.", file=sys.stderr)
        return 2
    cmd = [sys.executable, str(jh / "job_hunter.py"), "--mark", args.offer_id, estado]
    if args.nota:
        cmd += ["--nota", args.nota]
    env = dict(os.environ)
    env.setdefault("PYTHONIOENCODING", "utf-8")
    r = subprocess.run(cmd, cwd=str(jh), capture_output=True, text=True, encoding="utf-8", errors="replace", env=env)
    if r.returncode != 0:
        msg = (r.stderr or r.stdout).strip()
        if "unrecognized arguments" in msg or "--mark" in msg:
            msg += "\nTu job_hunter.py es anterior a la v2 (no tiene --mark). Reemplázalo por la versión nueva."
        print(f"Error: job_hunter.py devolvió {r.returncode}: {msg}", file=sys.stderr)
        return r.returncode
    print((r.stdout or "").strip() or f"✔ {args.offer_id} → {estado}")
    return 0


def _receiver_up(host: str, port: int) -> bool:
    try:
        with urllib.request.urlopen(f"http://{host}:{port}/health", timeout=2) as r:
            return json.loads(r.read().decode("utf-8")).get("service") == ac.SERVICE_NAME
    except (urllib.error.URLError, OSError, ValueError):
        return False


def cmd_doctor(args) -> int:
    paths, settings = setup(args)
    problems = 0

    def line(ok: Optional[bool], text: str) -> None:
        nonlocal problems
        mark = "✔" if ok else ("⚠" if ok is None else "✖")
        if ok is False:
            problems += 1
        print(f"  {mark} {text}")

    print("Apply Copilot — diagnóstico")
    line(sys.version_info >= (3, 9), f"Python {sys.version.split()[0]}")
    rc = settings["receiver"]
    up = _receiver_up(rc["host"], int(rc["port"]))
    line(True if up else None, f"Receiver en {rc['host']}:{rc['port']}: " + ("responde" if up else "apagado (python tools/receiver.py)"))
    jh = resolve_job_hunter_dir(paths, settings)
    line(bool(jh), f"job_hunter.py: {jh or 'no encontrado (revisa job_hunter_dir en config/settings.json)'}")
    if jh:
        line(True if (jh / "data" / "jobs_database.json").exists() else None, "Base de ofertas de job_hunter: " + ("existe" if (jh / "data" / "jobs_database.json").exists() else "aún no (corre job_hunter.py)"))
    if paths.profile.exists():
        try:
            prof = ac.read_json(paths.profile)
            gaps = [k for k, v in (("email", (prof.get("contact") or {}).get("email")), ("teléfono", (prof.get("contact") or {}).get("phone")),
                                   ("LinkedIn", (prof.get("links") or {}).get("linkedin"))) if not v]
            line(True if not gaps else None, "profile.json: " + ("completo" if not gaps else f"sin {', '.join(gaps)} (esos campos quedarán en HUMAN)"))
            risky = [k for k in prof if ac.is_sensitive(k)]
            line(not risky, "profile.json sin claves sensibles" if not risky else f"profile.json tiene claves sensibles ({', '.join(risky)}): no se enviarán a Qwen")
        except ValueError as e:
            line(False, f"profile.json ilegible: {e}")
    else:
        line(False, "Falta config/profile.json")
    ext_ok = any(((base / ext) / "manifest.json").exists()
                 for base in (paths.root, paths.root.parent)
                 for ext in ("extension_v2", "extension"))
    line(ext_ok, "Extensión (Chrome > Extensiones > Cargar descomprimida): extension_v2/")
    print("\nTodo listo." if problems == 0 else f"\n{problems} problema(s) por resolver.")
    return 0 if problems == 0 else 1


def main(argv=None) -> int:
    ac.console_utf8()
    p = argparse.ArgumentParser(description="Orquestador de Apply Copilot (postulación asistida).")
    p.add_argument("--root", type=Path, default=None, help="Raíz del proyecto")
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("list", help="Ofertas pendientes de job_hunter ordenadas por score")
    s.add_argument("--limit", type=int, default=15)
    s.add_argument("--min-score", type=int, default=60)
    s.add_argument("--all", action="store_true", help="Incluye ofertas ya postuladas o descartadas")
    s.set_defaults(fn=cmd_list)

    s = sub.add_parser("prepare", help="Deja lista una oferta para la extensión")
    s.add_argument("offer_id")
    s.add_argument("--open", action="store_true", help="Abre la oferta en el navegador")
    s.set_defaults(fn=cmd_prepare)

    s = sub.add_parser("status", help="Estado de la postulación más reciente")
    s.add_argument("--app", default=None)
    s.set_defaults(fn=cmd_status)

    s = sub.add_parser("mark", help="Marca el estado de una oferta en job_hunter")
    s.add_argument("offer_id")
    s.add_argument("estado")
    s.add_argument("--nota", default="")
    s.set_defaults(fn=cmd_mark)

    s = sub.add_parser("doctor", help="Revisa que todo esté listo")
    s.set_defaults(fn=cmd_doctor)

    args = p.parse_args(argv)
    return args.fn(args)


if __name__ == "__main__":
    sys.exit(main())
