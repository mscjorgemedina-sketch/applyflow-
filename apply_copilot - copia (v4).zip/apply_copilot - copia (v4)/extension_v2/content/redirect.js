(() => {
  // Solo actúa en páginas de detalle de oferta, no en el formulario de postulación.
  if (location.pathname.includes("/trabajo/postular/")) return;

  const match = location.pathname.match(/-(\d{4,})\/?$/) || location.pathname.match(/\/(\d{4,})\/?$/);
  if (!match) return;
  const offerId = match[1];

  const send = (msg) => new Promise((resolve) => chrome.runtime.sendMessage(msg, resolve));
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  const goToForm = () => {
    const link = document.querySelector('a[href*="/trabajo/postular/"]');
    if (!link) return false;
    const href = link.getAttribute("href");
    if (!href) return false;
    location.href = new URL(href, location.href).href;
    return true;
  };

  (async () => {
    const state = await send({ type: "AC_GET_SITE", url: location.href, auto: true });
    if (!state || state.inactive) return;

    // Algunas ofertas activas redirigen al detalle: seguimos el enlace "Postular".
    if (goToForm()) return;
    await sleep(1500);
    if (goToForm()) return;

    // Sin formulario ni enlace de postulación: la oferta está expirada.
    await send({
      type: "AC_REPORT",
      report: {
        offer_id: offerId,
        status: "expired",
        filled: 0,
        url: location.href,
        title: document.title,
      },
    });
  })();
})();
