(() => {
  if (window.__AC2_AUTO_DONE__) return;
  window.__AC2_AUTO_DONE__ = true;

  const offerId = (location.pathname.match(/postular\/(\d{4,})/) || [])[1] || "";
  if (!offerId) return;

  const send = (msg) => new Promise((resolve) => chrome.runtime.sendMessage(msg, resolve));
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  (async () => {
    const res = await send({ type: "AC_GET_SITE", url: location.href, auto: true });
    if (!res || res.inactive) return;  // No hay corrida activa: no tocar la página.

    if (!res.ok) {
      await send({
        type: "AC_REPORT",
        report: {
          offer_id: offerId, status: "error", filled: 0,
          url: location.href, title: document.title,
        },
      });
      return;
    }

    // Espera el formulario (carga diferida) hasta ~12 s.
    for (let i = 0; i < 24; i += 1) {
      const hasForm = document.querySelector(
        "textarea, select, input:not([type=hidden]):not([type=submit]):not([type=button]):not([type=reset])",
      );
      if (hasForm) break;
      await sleep(500);
    }
    await sleep(600);

    let out = {};
    try {
      out = window.__AC2 ? window.__AC2.fill(res.site) : {};
    } catch (e) {
      out = { error: String(e && e.message ? e.message : e) };
    }

    const status = (out.filled || 0) > 0 ? "filled" : "no_form";
    await send({
      type: "AC_REPORT",
      report: {
        offer_id: offerId,
        status,
        filled: out.filled || 0,
        skipped: out.skipped || [],
        url: location.href,
        title: document.title,
      },
    });
  })();
})();
