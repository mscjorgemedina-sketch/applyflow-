(() => {
  if (window.__AC2) return;

  const ALWAYS_BLOCKED = ["password", "passwd", "clave", "contrasena", "banco", "tarjeta", "cvv", "linkedin"];
  const SENSITIVE = ["sueldo", "salario", "salary", "pretension", "renta", "remuneracion"];

  const norm = (s) => String(s || "").toLowerCase()
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, " ").trim();

  const digits = (s) => Number(String(s || "").replace(/[^\d]/g, "")) || 0;

  const fillable = () => Array.from(
    document.querySelectorAll("input, select, textarea")
  ).filter((el) => {
    if (el.disabled || el.readOnly) return false;
    if (el.tagName === "INPUT" && ["hidden", "file", "submit", "button", "reset", "image"].includes(el.type)) return false;
    const inButton = el.closest("button, [role=button]");
    if (inButton && el.tagName !== "INPUT") return false;
    return true;
  });

  const haystack = (el) => norm([
    el.name, el.id, el.getAttribute("aria-label"), el.placeholder,
    el.labels && el.labels[0] ? el.labels[0].innerText : "",
    el.getAttribute("title")
  ].join(" "));

  const blocked = (el, allowSensitive) => {
    const h = haystack(el);
    if (ALWAYS_BLOCKED.some((b) => h.includes(b))) return true;
    if (!allowSensitive && SENSITIVE.some((b) => h.includes(b))) return true;
    return false;
  };

  const setNative = (el, value) => {
    const proto = el.tagName === "TEXTAREA"
      ? HTMLTextAreaElement.prototype
      : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value").set;
    setter.call(el, value);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  };

  const mark = (el) => { el.style.outline = "2px solid #22c55e"; };

  const pickSelectOption = (el, value) => {
    const text = norm(value);
    const options = Array.from(el.options);
    const direct = options.find((o) => norm(o.text).includes(text) || norm(o.value) === text);
    if (direct) return direct;

    // Sueldo: si el select usa rangos ("$3.000.000 - $3.500.000"), elige el que contiene el monto.
    const salary = digits(value);
    if (salary >= 100000) {
      for (const o of options) {
        const nums = (o.text.match(/\d[\d.]*/g) || []).map(digits).filter((n) => n >= 100000);
        if (nums.length >= 2 && salary >= Math.min(...nums) && salary <= Math.max(...nums)) return o;
        if (nums.length === 1 && salary <= nums[0] && /menos|hasta|inferior|max/i.test(o.text)) return o;
        if (nums.length === 1 && salary >= nums[0] && /mas|sobre|superior|min/i.test(o.text)) return o;
      }
    }
    return null;
  };

  window.__AC2 = {
    fill(site) {
      const fields = (site && site.fields) || [];
      const allowSensitive = !!(site && site.allow_sensitive);
      const elements = fillable();
      const used = new Set();
      const names = [];
      const skipped = [];

      for (const f of fields) {
        const matchers = (f.match || []).map(norm).filter(Boolean);
        const excludes = (f.exclude || []).map(norm).filter(Boolean);
        if (!matchers.length || f.value === undefined || f.value === null || f.value === "") continue;

        const el = elements.find((c) => {
          if (used.has(c)) return false;
          if (blocked(c, allowSensitive)) return false;
          const h = haystack(c);
          if (excludes.some((e) => h.includes(e))) return false;
          return matchers.some((m) => h === m || h.includes(m));
        });
        if (!el) { skipped.push(f.match && f.match[0]); continue; }

        used.add(el);
        const value = String(f.value);

        if (el.tagName === "SELECT") {
          const opt = pickSelectOption(el, value);
          if (opt) {
            el.value = opt.value;
            el.dispatchEvent(new Event("change", { bubbles: true }));
          }
        } else if (el.type === "checkbox") {
          el.checked = !["0", "false", "no"].includes(value.toLowerCase());
          el.dispatchEvent(new Event("change", { bubbles: true }));
        } else if (el.type === "radio") {
          const group = Array.from(document.querySelectorAll(`input[type=radio][name="${CSS.escape(el.name)}"]`));
          const target = group.find((r) => norm(r.value) === norm(value) ||
            (r.labels && r.labels[0] && norm(r.labels[0].innerText).includes(norm(value))));
          if (target) {
            target.checked = true;
            target.dispatchEvent(new Event("change", { bubbles: true }));
          }
        } else if (el.type === "number") {
          setNative(el, String(digits(value) || value));
        } else {
          setNative(el, value);
        }
        mark(el);
        names.push((el.name || el.id || f.match[0] || "campo"));
      }

      return { ok: true, filled: names.length, names, skipped, allow_sensitive: allowSensitive };
    }
  };
})();
