(() => {
  if (sessionStorage.getItem("__AC_LOGIN_REPORTED__")) return;
  sessionStorage.setItem("__AC_LOGIN_REPORTED__", "1");

  const offerId = (location.search.match(/postular(?:%2F|\/)(\d{4,})/i) || [])[1] || "0000";
  chrome.runtime.sendMessage({
    type: "AC_REPORT",
    report: {
      offer_id: offerId,
      status: "login",
      filled: 0,
      url: location.href,
      title: document.title,
    },
  });
})();
