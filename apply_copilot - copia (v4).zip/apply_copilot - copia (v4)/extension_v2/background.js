const API = "http://127.0.0.1:8766";

async function api(path, options) {
  const res = await fetch(API + path, options);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const detail = (data && data.error && (data.error.message || data.error)) || `HTTP ${res.status}`;
    throw new Error(detail);
  }
  return data;
}

async function getRunState() {
  try {
    return await api("/api/run-state");
  } catch {
    return { active: false };
  }
}

async function getSite(url, auto) {
  if (auto) {
    const state = await getRunState();
    if (!state.active) return { ok: false, inactive: true };
  }
  return api("/api/site-answers?url=" + encodeURIComponent(url || ""));
}

async function report(data) {
  const state = await getRunState();
  const body = Object.assign({}, data, { run_id: data.run_id || state.run_id || "" });
  return api("/api/fill-report", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}

async function fillTab(tab, site) {
  await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content/fill.js"] });
  const out = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: (s) => window.__AC2.fill(s),
    args: [site],
  });
  return (out && out[0] && out[0].result) || {};
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    try {
      if (!msg) { sendResponse({ ok: false, error: "Mensaje vacío" }); return; }

      if (msg.type === "AC_GET_SITE") {
        sendResponse(await getSite(msg.url, !!msg.auto));
        return;
      }

      if (msg.type === "AC_REPORT") {
        sendResponse(await report(msg.report || {}));
        return;
      }

      if (msg.type === "AC_LOAD_ANSWERS") {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab || !tab.id) throw new Error("Sin pestaña activa");
        const data = await getSite(tab.url, false);
        const result = await fillTab(tab, data.site);
        if (data.offer_id) {
          await report({
            offer_id: data.offer_id,
            status: (result.filled || 0) > 0 ? "filled" : "no_form",
            filled: result.filled || 0,
            skipped: result.skipped || [],
            url: tab.url,
            title: tab.title || "",
          }).catch(() => {});
        }
        sendResponse({ ok: true, report: result });
        return;
      }

      if (msg.type === "AC_FILL_ALL") {
        const tabs = await chrome.tabs.query({ url: "https://www.chiletrabajos.cl/trabajo/postular/*" });
        const results = [];
        for (const tab of tabs) {
          try {
            const data = await getSite(tab.url, false);
            const result = await fillTab(tab, data.site);
            results.push(Object.assign({ tabId: tab.id, offer_id: data.offer_id }, result));
            if (data.offer_id) {
              await report({
                offer_id: data.offer_id,
                status: (result.filled || 0) > 0 ? "filled" : "no_form",
                filled: result.filled || 0,
                skipped: result.skipped || [],
                url: tab.url,
                title: tab.title || "",
              }).catch(() => {});
            }
          } catch (e) {
            results.push({ tabId: tab.id, error: String(e && e.message ? e.message : e) });
          }
        }
        sendResponse({ ok: true, tabs: tabs.length, results });
        return;
      }

      if (msg.type === "AC_GET_REGISTRY_COUNT") {
        const reg = await api("/api/fill-registry");
        sendResponse({ ok: true, total: reg.total_filled || 0 });
        return;
      }

      if (msg.type === "AC_CLOSE_VERIFIED") {
        const reg = await api("/api/fill-registry");
        const ids = new Set((reg.ids || []).map(String));
        const tabs = await chrome.tabs.query({ url: "https://www.chiletrabajos.cl/trabajo/postular/*" });
        const noMatch = [];
        let closed = 0;
        for (const tab of tabs) {
          const m = String(tab.url || "").match(/\/postular\/(\d+)/);
          if (m && ids.has(m[1])) {
            try { await chrome.tabs.remove(tab.id); closed += 1; } catch { /* ya cerrada */ }
          } else {
            noMatch.push(String(tab.url || "").slice(0, 90));
          }
        }
        sendResponse({ ok: true, closed, postular_tabs: tabs.length, total_filled: reg.total_filled || 0, no_match: noMatch });
        return;
      }

      sendResponse({ ok: false, error: "Mensaje desconocido: " + msg.type });
    } catch (e) {
      sendResponse({ ok: false, error: String(e && e.message ? e.message : e) });
    }
  })();
  return true;
});
