const btn = document.getElementById("load");
const btnAll = document.getElementById("all");
const btnClose = document.getElementById("close");
const status = document.getElementById("status");

function setBusy(busy) {
  btn.disabled = busy;
  btnAll.disabled = busy;
  btnClose.disabled = busy;
}

function describe(report) {
  const r = report || {};
  return `✔ ${r.filled || 0} campos cargados` +
    (r.names && r.names.length ? `\n${r.names.join(", ")}` : "") +
    (r.skipped && r.skipped.length ? `\n⏭ sin campo: ${r.skipped.join(", ")}` : "");
}

btn.addEventListener("click", () => {
  setBusy(true);
  status.textContent = "Buscando respuestas para esta pestaña...";
  chrome.runtime.sendMessage({ type: "AC_LOAD_ANSWERS" }, (res) => {
    setBusy(false);
    if (!res) { status.textContent = "Error: sin respuesta del service worker."; return; }
    if (!res.ok) { status.textContent = "⚠ " + res.error; return; }
    status.textContent = describe(res.report);
  });
});

btnAll.addEventListener("click", () => {
  setBusy(true);
  status.textContent = "Rellenando todas las pestañas abiertas de postulación...";
  chrome.runtime.sendMessage({ type: "AC_FILL_ALL" }, (res) => {
    setBusy(false);
    if (!res) { status.textContent = "Error: sin respuesta del service worker."; return; }
    if (!res.ok) { status.textContent = "⚠ " + res.error; return; }
    const ok = (res.results || []).filter((r) => (r.filled || 0) > 0).length;
    status.textContent = `✔ ${ok}/${res.tabs || 0} pestañas rellenadas.\nRevisa y envía tú.`;
  });
});

btnClose.addEventListener("click", () => {
  setBusy(true);
  status.textContent = "Buscando pestañas ya rellenadas (registro local)...";
  chrome.runtime.sendMessage({ type: "AC_CLOSE_VERIFIED" }, (res) => {
    setBusy(false);
    if (!res) { status.textContent = "Error: sin respuesta del service worker."; return; }
    if (!res.ok) { status.textContent = "⚠ " + res.error + "\nSi el receiver está desactualizado, reinícialo."; return; }
    status.textContent =
      `✔ ${res.closed} pestañas cerradas (de ${res.postular_tabs} abiertas) · ` +
      `${res.total_filled} rellenadas en el registro.\nLas no rellenadas quedaron abiertas.`;
  });
});

// Estado rápido al abrir el popup: cuántas ofertas hay en el registro ya rellenadas.
chrome.runtime.sendMessage({ type: "AC_GET_REGISTRY_COUNT" }, (res) => {
  if (res && res.ok && (res.total || 0) > 0) {
    const base = "Nunca se envía automáticamente.";
    status.textContent = `✔ ${res.total} ofertas rellenadas en el registro.\n${base}`;
  }
});
