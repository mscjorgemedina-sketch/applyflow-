---
name: Job Matching
description: Motor de sinónimos y ranking de ofertas para el perfil del usuario
---

# Job Matching

## Objetivo

Ordenar ofertas de ChileTrabajos con evidencia explicable, sin depender de un LLM para cada cálculo.

## Archivos

- `data/synonyms.json`: conceptos, aliases, pesos y contextos negativos.
- `tools/synonym_engine.py`: normalización, expansión y detección.
- `tools/match_engine.py`: scoring y `data/apply_queue.json`.
- `tools/search_offers.py`: búsqueda por sinónimos.
- `tools/eval_ranker.py`: comparación contra el score legacy con proxies.

## Reglas de sinónimos

1. Un concepto tiene un `id` estable y un `label` legible.
2. Los aliases se escriben en minúsculas, sin tildes y sin puntuación.
3. Un alias ambiguo se marca con `"ambiguous": true` y se resuelve por contexto.
4. Un concepto negativo (por ejemplo, líneas de transmisión) tiene `"negative": true` y no suma al match.
5. Los sinónimos nuevos se proponen, no se aplican sin revisión.

## Scoring

```text
match = 0.45*titulo + 0.25*skills + 0.10*descripcion
      + 0.10*frescura + 0.05*ubicacion + 0.05*empresa
score = 100*match + 10*graph_similarity - penalizaciones
```

Penalizaciones: junior/trainee, duplicado, expirado, requisito negativo del perfil.

## Validación

Sin etiquetas humanas se usan proxies:

- `market_fit` del rubric de perfil.
- Expiradas y duplicadas (objetivo).
- Conversión real: `opened`, `filled`, `submitted`, `skipped`.

No afirmar precisión absoluta. Reportar siempre el método y la limitación.

## Comandos

```powershell
python tools/match_engine.py rank --top 30 --portal chiletrabajos
python tools/search_offers.py "jefe de proyecto"
python tools/eval_ranker.py
```
