---
name: ChileTrabajos Form
description: Mapa real del formulario de postulación de ChileTrabajos y reglas de relleno seguro
---

# Formulario ChileTrabajos

## URL

`https://www.chiletrabajos.cl/trabajo/postular/{ID}`

Si redirige a `/trabajo/{ID}` sin formulario, la oferta está expirada o ya fue postulada.

## Campos reales

| Campo | Tipo | Acción |
|---|---|---|
| `app_letter` | textarea | Carta personalizada |
| `salary` | number | **Estimación de mercado** (la revisa el usuario antes de enviar) |
| `disp` | text | Disponibilidad, por ejemplo "Inmediata" |
| `dispoIn` | checkbox | Disponibilidad inmediata |
| `q2` | textarea | Formación y año de titulación |
| `q3` | textarea | Experiencia en construcción/PEM |
| `q4` | textarea | Experiencia en mediana/gran minería |
| `q5` | textarea | Experiencia específica (líneas de transmisión, etc.) |
| `att1` | file | **CV: lo adjunta el usuario** |
| `situacion_laboral` | select | Ambiguo; dejar al usuario si no hay label claro |
| submit | botón | **Nunca tocar** |

## Reglas duras

- Cero submit.
- Sueldo: solo la estimación de mercado que trae el receiver (nunca una cifra declarada ni pretensión del historial).
- LinkedIn, contraseñas y datos bancarios: nunca.
- RUT solo desde `profile.sensitive_local.rut`.
- No inventar experiencia.
- Si un campo no está en `data/site_answers.json`, dejarlo vacío y reportarlo.
- El checkbox `dispoIn` se marca solo si la disponibilidad es inmediata.

## Relleno automático (predeterminado en 2026: extensión v3 + receiver)

1. Receiver v5 arriba: `python tools/receiver.py` (escucha en `127.0.0.1:8766`; verifica con `GET /health` que responda `version: v5`).
2. Abrir `/trabajo/postular/{ID}`: `redirect.js` lleva al formulario y `fill.js` rellena solo, usando `data/site_answers.json` + el merge por oferta de `GET /api/site-answers` (carta + sueldo estimado).
3. Varias pestañas a la vez: icono de la extensión → **"Rellenar todas las pestañas"** (`AC_FILL_ALL`).
4. Cada pestaña reporta con `POST /api/fill-report` → `data/fill_reports.jsonl` + `data/fill_registry.json`.

## Relleno manual con Playwright (respaldo)

1. Navegar a la URL.
2. Verificar `textarea[name="app_letter"]`.
3. Inyectar `extension_v2/content/fill.js` si `window.__AC2` no existe.
4. Construir el sitio desde `data/site_answers.json`, con carta dinámica según el título.
5. Ejecutar `window.__AC2.fill(site)`.
6. Auditar: carta presente, sueldo vacío, LinkedIn vacío, sin submit.
7. Dejar la pestaña abierta para revisión humana.

## Relleno con extensión

Abrir la pestaña, pulsar **Cargar respuestas**, revisar y enviar manualmente. La extensión no envía.

## Auditoría mínima

```json
{
  "submit_clicked": false,
  "salary_market_estimate": true,
  "linkedin_empty": true,
  "letter_present": true,
  "cv_pending": true
}
```
