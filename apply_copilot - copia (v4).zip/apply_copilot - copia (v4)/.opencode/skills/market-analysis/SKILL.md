---
name: Market Analysis
description: Análisis de demanda, gaps, renta publicada y expansión de mercado para el perfil
---

# Market Analysis

## Objetivo

Responder con evidencia si el perfil calza con el mercado actual y si conviene ampliar a nuevos segmentos.

## Fuentes

- Ofertas de ChileTrabajos en `data/corpus/offers/`.
- `config/profile.json`.
- `data/synonyms.json`.
- Búsquedas adyacentes en ChileTrabajos (solo lectura).

## Métricas

- Demanda por concepto: cantidad y porcentaje de ofertas.
- Cobertura del perfil: concepto presente en el perfil.
- `Leverage`: alta demanda + perfil lo tiene.
- `Gap`: alta demanda + perfil no lo tiene.
- `Niche`: baja demanda + perfil lo tiene.
- Renta publicada: solo si la oferta la incluye; nunca autocompletar.
- Ubicación, empresa y frescura.

## Proxies

Sin etiquetas humanas, el `market_fit` es un proxy:

```text
market_fit = 0.55*cobertura_core + 0.20*ubicacion
           + 0.15*frescura + 0.10*empresa - penalizaciones
```

No presentarlo como probabilidad de contratación.

## Expansión

Escanear términos adyacentes:

```text
confiabilidad, planificación de mantenimiento, commissioning,
project controls, costos, abastecimiento técnico, HVAC,
eficiencia energética, diseño mecánico, asset management
```

Recomendación por mercado:

```text
Mercado | Demanda | Fit | Renta publicada | Recomendación
```

## Reglas

- No inventar cifras.
- Si no hay renta publicada, `N/D`.
- Distinguir dato observado, proxy y recomendación.
- No enviar postulaciones.
