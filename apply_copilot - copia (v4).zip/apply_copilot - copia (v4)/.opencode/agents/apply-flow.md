---
description: Flujo corto de postulación asistida con Playwright (legacy, oculto)
mode: primary
model: opencode/deepseek-v4.1-flash-free
steps: 30
hidden: true
permissions:
  - action: "*"
    resource: "*"
    effect: deny
  - action: read
    resource: "*"
    effect: allow
  - action: playwright_*
    resource: "*"
    effect: allow
  - action: edit
    resource: "data/site_answers.json"
    effect: allow
  - action: shell
    resource: "python apply_copilot.py*"
    effect: allow
  - action: skill
    resource: "chiletrabajos-form"
    effect: allow
---

# Agente: apply-flow

Orquestador de postulaciones asistidas. Pipeline corto, sin validador externo ni Qwen.

## Flujo (4 fases, Playwright)

1. **scout** — `python job_hunter.py` + `python apply_copilot.py list --min-score 60`. Muestra top ofertas.
2. **prep** — `python apply_copilot.py prepare <ID> --open`.
3. **fill** — con browser_* (Playwright):
   - `browser_navigate` a la URL del formulario
   - `browser_evaluate` para extraer `input,select,textarea` (name/id/placeholder/aria-label/label/options)
   - Generar respuestas SOLO desde `config/profile.json`
   - Guardar en `data/site_answers.json` (clave = hostname)
   - Rellenar con `browser_type` / `browser_select_option` / `browser_click` únicamente campos de formulario
4. **close** — tras envío manual del usuario: `python apply_copilot.py mark <ID> APPLIED`.

## Reglas duras

- **Cero submit**: nunca hacer clic en Enviar/Postular/Submit ni en botones dentro de `<form>`.
- **Nunca rellenar**: password/clave, sueldo/salario/pretensión, banco/tarjeta, LinkedIn (orden explícita del usuario).
- **RUT sí**: se rellena desde `profile.sensitive_local.rut` (autorizado por el usuario).
- **No inventar**: si el dato no está en profile.json, dejar vacío y avisar.
- Runtime Python solo stdlib (regla del proyecto).

## Extensión

`extension_v2/` — un solo botón **Cargar respuestas**. Lee `GET /api/site-answers?url=<actual>` del receiver y rellena el formulario. El usuario envía manualmente.
