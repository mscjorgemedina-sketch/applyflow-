---
description: Prepara el siguiente lote manual de postulaciones
agent: apply-orchestrator
---

Prepara exactamente $ARGUMENTS ofertas desde `data/apply_queue.json`.

Pasos:
1. Lee `data/apply_queue.json`.
2. Toma las primeras ofertas `QUEUED` o `RANKED`.
3. Delega el relleno en `form-filler`, en lotes pequeños.
4. Delega la auditoría en `application-auditor`.
5. Devuelve el resumen y recuerda que el usuario debe revisar, poner renta, adjuntar CV y enviar.

No envíes nada.
