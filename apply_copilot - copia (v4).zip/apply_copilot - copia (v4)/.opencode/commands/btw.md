---
description: "Loop autónomo v3: N ticks de selfcheck + 1 mejora del backlog por tick + compresión de sesión cada 3 ticks ($ARGUMENTS)"
agent: apply-orchestrator
---

$ARGUMENTS = número de ticks (default 5) o "loop" para ciclo de ~60 min.

## Reglas de guardianía (NO NEGOCIABLES — usuario ausente)

1. **Cero preguntas, cero interacción**: nunca pedir confirmación, nunca abrir
   pestañas nuevas, nunca correr rellenados ni `2-arrancar`/orquestador en modo
   mantenimiento. No matar procesos (receiver PID 8766, Chrome).
2. **Cero submit**: prohibido tocar lógica de envío o correr autocompletes.
3. **Puerta verde**: cada mejora termina con `python tools/selfcheck.py` en
   9/10 o mejor (ideal 10/10). Si baja tras una mejora → ROLLBACK del cambio
   (revertir el archivo editado) → marcar el item como `fallido` en
   `data/backlog.json` → revisar la siguiente tarea.
4. **Presupuesto**: código del repo ≤ 2MB (check 9 del selfcheck). Si algún
   fix añade peso, purgar lo innecesario al cierre del tick.

## Secuencia por tick (repetir N ticks)

1. `python tools/btw.py tick --reparar` (≤8 líneas). Fallo → diagnóstico con el
   mapa impreso y arreglos mecánicos; si sigue ✖ → STOP duro (log limpio).
2. Tomar el PRIMER item `estado=="pendiente"` y `safe==true` de
   `data/backlog.json` (los de prioridad del usuario primero). Implementar el
   cambio, compilar (`python -m py_compile` o build correspondiente), re-test
   del caso (llamada real del archivo tocado) y `selfcheck`. Marcar el item
   `hecho` (o `fallido`) con timestamp en el backlog.
3. Cada **3er tick**: escribir `data/session_state.json` — compresión de la
   sesión: decisiones, mejoras aplicadas/rollback, archivos tocados,
   pendientes, próximos pasos, y recordatorio: baseline_tabs=2, cero submits,
   no rellenar, no preguntas.
4. Al terminar el tick N o el minuto 60: `python tools/btw.py history -n 5`
   + purga de caches + resumen de 5 líneas máximo.

## Utilidades

- `python tools/btw.py repair` — solo arreglos mecánicos (sync, receiver, CLI).
- `python tools/btw.py history [-n N]` — tendencia de los últimos ticks.

Recuerda: el relleno de ofertas solo corre cuando el USUARIO lo pida después
(`/ir30`); mientras duerme el trabajo es revisión + mejoras con puerta verde.
