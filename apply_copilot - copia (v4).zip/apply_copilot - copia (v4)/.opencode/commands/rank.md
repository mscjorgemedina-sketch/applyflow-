---
description: Recalcula el orden de postulación de ChileTrabajos
agent: job-ranker
---

Ejecuta:

```powershell
python tools/match_engine.py rank --top 30 --portal chiletrabajos
```

Muestra el top 10 con `score`, `matched`, `missing`, `risk` y `reason`.
No envíes nada. Si el usuario pasó argumentos, úsalos como filtros o número de ofertas.

$ARGUMENTS
