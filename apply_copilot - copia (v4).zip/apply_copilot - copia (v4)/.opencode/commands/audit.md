---
description: Audita las pestañas o el lote preparado
agent: application-auditor
---

Audita el lote indicado: $ARGUMENTS

Si no se indica nada, audita las pestañas abiertas de ChileTrabajos que tengan formulario.

Comprueba:
- Carta presente.
- Sueldo = estimación de mercado (o vacío si la corrida bloqueó sensibles).
- LinkedIn vacío.
- Sin contraseñas ni datos bancarios.
- CV pendiente.
- Cero submit.

Devuelve el checklist por oferta.
