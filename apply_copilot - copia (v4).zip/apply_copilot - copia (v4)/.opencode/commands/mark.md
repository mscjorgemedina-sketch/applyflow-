---
description: Registra una postulación enviada manualmente
agent: apply-orchestrator
---

El usuario confirma que envió estas ofertas: $ARGUMENTS

Para cada ID:

```powershell
python apply_copilot.py mark <ID> APPLIED --nota "enviada manualmente por el usuario"
```

No marques nada si el usuario no confirma explícitamente el envío.
