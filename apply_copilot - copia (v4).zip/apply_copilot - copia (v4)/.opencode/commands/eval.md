---
description: Compara el ranking nuevo contra el legacy usando proxies
agent: job-ranker
---

Ejecuta:

```powershell
python tools/eval_ranker.py
```

Explica las métricas y aclara que son proxies, no etiquetas humanas.
Recomienda si adoptar, ajustar o descartar el motor nuevo.

$ARGUMENTS
