---
description: Busca ofertas por sinónimos, o encuentra similares a una oferta (agent: job-ranker)
agent: job-ranker
---

Para búsqueda por texto:

```powershell
python tools/search_offers.py "$ARGUMENTS"
```

Para ofertas **similares a una oferta dada** (pulido 2026): si `$ARGUMENTS`
empieza por `--similar` o es un `ch_...`/id numérico, corre:

```powershell
python tools/search_offers.py --similar <offer_id> --limit 10
```

Explica qué conceptos se expandieron y por qué las ofertas encontradas calzan
(modos: conceptos en el título pesan más, desempate por Jaccard de tokens,
mismos factores cluster/zona/empresa que `--similar`).
No envíes nada.
