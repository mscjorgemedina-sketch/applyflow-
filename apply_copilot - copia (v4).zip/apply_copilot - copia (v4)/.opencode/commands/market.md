---
description: Genera el informe de mercado y la recomendación de expansión
agent: market-analyst
---

Ejecuta:

```powershell
python tools/build_corpus.py --portal chiletrabajos --min-score 70 --max 60
python tools/market_analysis.py --scan-adjacent
```

Resume:
- Demanda por rol y skill.
- Cobertura del perfil y gaps.
- Renta publicada (solo lectura).
- Ubicación y empresas.
- Recomendación de ampliar o no a nuevos mercados.

$ARGUMENTS
