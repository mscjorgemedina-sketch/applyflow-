---
description: Self-check del sistema en ~9 segundos (10 validaciones)
agent: apply-orchestrator
---

Ejecuta y resume:

```powershell
python apply_copilot\tools\selfcheck.py --silencioso
```

Muestra el resultado en una línea compacta (10/10 ok o la lista de fallos con causa).
Para el detalle por check usa `python apply_copilot\tools\selfcheck.py` (verbose).

Los 10 checks: objetivo >=100 (registro), estado /progress, cero submit, datos
sensibles, ranking v2, eval vs legacy, CLI restaurada, receiver v5 en 8766,
presupuesto de código <=2MB y pestañas <=100 (estimado).

Si algo falla, propón el arreglo mínimo como siguiente paso y detente: no intentes
repararlo si toca relleno, playwright ni datos de perfil. Para fallos mecánicos
(receiver abajo, caches, CLI faltante) usa `python apply_copilot\tools\btw.py repair`.

No envíes nada.
