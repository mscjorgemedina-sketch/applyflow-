---
description: Muestra el avance de las ofertas y postulaciones
agent: apply-orchestrator
---

Lee `data/apply_state.json` y `data/apply_events.jsonl`.

Si no existen o quieres refrescarlos, ejecuta primero:

```powershell
python tools/apply_state.py sync
```

(y para un resumen inmediato: `python tools/apply_state.py summary`).

Resume:
- Ofertas por estado: RANKED, QUEUED, OPENED, FILLED, READY, APPLIED, EXPIRED.
- Postulaciones enviadas por día.
- Pendientes de revisión humana.
- Ofertas con auditoría fallida.

Si los archivos no existen, explica que aún no se ha ejecutado el pipeline y muestra el estado desde `jobs_database.json`.

$ARGUMENTS
